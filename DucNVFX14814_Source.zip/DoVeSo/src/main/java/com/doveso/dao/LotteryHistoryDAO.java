package com.doveso.dao;

import com.doveso.model.LotteryHistory;
import java.time.LocalDate;
import java.util.List;

/**
 * Interface tang truy xuat du lieu cho entity LotteryHistory (lich su do ve).
 * Chuc nang 3 - Thuc hien do ve so (chi ap dung cho USER da dang nhap).
 */
public interface LotteryHistoryDAO {

    /** Luu 1 lan do ve vao lich su. */
    Long insert(LotteryHistory history);

    /**
     * Lay lich su do ve cua 1 user, moi nhat truoc, co phan trang.
     * regionCode, companyCode = null hoac rong nghia la khong loc; companyCode uu tien hon regionCode.
     * fromDate, toDate loc theo checked_at (thoi diem do), null nghia la khong gioi han dau/cuoi.
     */
    List<LotteryHistory> findByUserId(Long userId, String regionCode, String companyCode,
                                       LocalDate fromDate, LocalDate toDate, int page, int pageSize);

    /** Dem tong so lan do ve cua 1 user thoa dieu kien loc (phuc vu tinh so trang). */
    long countByUserId(Long userId, String regionCode, String companyCode, LocalDate fromDate, LocalDate toDate);
}
