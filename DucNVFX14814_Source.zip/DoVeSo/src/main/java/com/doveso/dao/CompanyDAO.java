package com.doveso.dao;

import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryRegion;
import java.util.List;

/** Interface tang truy xuat du lieu cho mien (lottery_regions) va cong ty xo so (lottery_companies). */
public interface CompanyDAO {

    /** Tat ca cac mien theo thu tu Bac, Trung, Nam. */
    List<LotteryRegion> findAllRegions();

    /** Cac cong ty dang hoat dong (active = TRUE), sap theo mien roi theo ten. */
    List<LotteryCompany> findActiveCompanies();

    /** Tim cong ty theo ma (bat ke active), null neu khong co. */
    LotteryCompany findByCode(String companyCode);
}
