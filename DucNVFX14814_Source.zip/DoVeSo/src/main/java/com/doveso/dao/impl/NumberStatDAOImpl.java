package com.doveso.dao.impl;

import com.doveso.dao.NumberStatDAO;
import com.doveso.model.PrizeDrawRow;
import com.doveso.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Trien khai NumberStatDAO bang JDBC thuan (join lottery_ticket_items voi lottery_tickets). */
public class NumberStatDAOImpl implements NumberStatDAO {

    @Override
    public List<PrizeDrawRow> findAllPublishedPrizeNumbers(String companyCode) {
        String sql = "SELECT t.draw_date, p.prize_number "
                + "FROM lottery_ticket_items p JOIN lottery_tickets t ON t.id = p.ticket_id "
                + "WHERE t.status = 'PUBLISH' AND t.company_code = ? "
                + "ORDER BY t.draw_date DESC";
        List<PrizeDrawRow> result = new ArrayList<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, companyCode);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(new PrizeDrawRow(rs.getDate("draw_date").toLocalDate(), rs.getString("prize_number")));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi lay du lieu thong ke so: " + e.getMessage(), e);
        }
        return result;
    }
}
