package com.doveso.dao;

import java.util.Map;

/**
 * Interface tang truy xuat du lieu co cau giai thuong (bang lottery_prize_configs).
 */
public interface LotteryPrizeConfigDAO {

    /** Lay co cau giai thuong cua 1 mien, tra ve Map prize_code -> prize_amount (VND). */
    Map<String, Long> findAmountsByRegion(String regionCode);
}
