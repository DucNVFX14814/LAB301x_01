package com.doveso.dao.impl;

import com.doveso.dao.TicketDAO;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryTicket;
import com.doveso.util.DBConnectionUtil;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** Trien khai TicketDAO bang JDBC thuan tren MySQL (bang lottery_tickets, lottery_ticket_items). */
public class TicketDAOImpl implements TicketDAO {

    /** Truy van co ban: kem ten dai va ten mien de hien thi. */
    private static final String SELECT_TICKET = "SELECT t.*, c.company_name, c.region_code, r.region_name "
            + "FROM lottery_tickets t "
            + "JOIN lottery_companies c ON c.company_code = t.company_code "
            + "JOIN lottery_regions r ON r.region_code = c.region_code ";

    @Override
    public Long insertWithPrizes(LotteryTicket ticket, List<LotteryPrize> prizes, boolean publish) {
        String insertTicketSql = "INSERT INTO lottery_tickets (company_code, draw_date, status, created_by, created_at) "
                + "VALUES (?, ?, ?, ?, ?)";
        String insertPrizeSql = "INSERT INTO lottery_ticket_items (ticket_id, prize_code, prize_name, prize_number) "
                + "VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnectionUtil.getConnection()) {
            conn.setAutoCommit(false);
            try {
                Long ticketId;
                try (PreparedStatement ps = conn.prepareStatement(insertTicketSql, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, ticket.getCompanyCode());
                    ps.setDate(2, Date.valueOf(ticket.getDrawDate()));
                    ps.setString(3, publish ? LotteryTicket.STATUS_PUBLISH : LotteryTicket.STATUS_UNPUBLISH);
                    ps.setLong(4, ticket.getCreatedBy());
                    ps.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("Khong lay duoc id ve do vua tao");
                        }
                        ticketId = keys.getLong(1);
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement(insertPrizeSql)) {
                    for (LotteryPrize p : prizes) {
                        ps.setLong(1, ticketId);
                        ps.setString(2, p.getPrizeCode());
                        ps.setString(3, p.getPrizeName());
                        ps.setString(4, p.getPrizeNumber());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                conn.commit();
                return ticketId;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi them ve do kem cac giai: " + e.getMessage(), e);
        }
    }

    @Override
    public LotteryTicket findById(Long id) {
        String sql = SELECT_TICKET + "WHERE t.id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi truy van ve do theo id: " + e.getMessage(), e);
        }
    }

    @Override
    public LotteryTicket findByCompanyAndDate(String companyCode, LocalDate drawDate) {
        String sql = SELECT_TICKET + "WHERE t.company_code = ? AND t.draw_date = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, companyCode);
            ps.setDate(2, Date.valueOf(drawDate));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi tim ve do theo dai va ngay: " + e.getMessage(), e);
        }
    }

    @Override
    public LotteryTicket findPublishedByCompanyAndDate(String companyCode, LocalDate drawDate) {
        String sql = SELECT_TICKET + "WHERE t.company_code = ? AND t.draw_date = ? AND t.status = 'PUBLISH'";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, companyCode);
            ps.setDate(2, Date.valueOf(drawDate));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi tim ve do PUBLISH theo dai va ngay: " + e.getMessage(), e);
        }
    }

    @Override
    public List<LocalDate> listPublishedDrawDates(int limit) {
        String sql = "SELECT DISTINCT draw_date FROM lottery_tickets WHERE status = 'PUBLISH' "
                + "ORDER BY draw_date DESC LIMIT ?";
        List<LocalDate> result = new ArrayList<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(rs.getDate("draw_date").toLocalDate());
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi lay danh sach ngay da PUBLISH: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public void publish(Long ticketId) {
        // Chi cho phep UNPUBLISH -> PUBLISH, khong cho chieu nguoc (theo yeu cau du an)
        String sql = "UPDATE lottery_tickets SET status = 'PUBLISH' WHERE id = ? AND status = 'UNPUBLISH'";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, ticketId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Loi publish ve do: " + e.getMessage(), e);
        }
    }

    @Override
    public List<LotteryTicket> search(String regionCode, String companyCode, LocalDate fromDate, LocalDate toDate,
                                      String status, int page, int pageSize) {
        List<Object> params = new ArrayList<>();
        String sql = SELECT_TICKET + buildWhere(regionCode, companyCode, fromDate, toDate, status, params)
                + "ORDER BY t.draw_date DESC, c.company_name LIMIT ? OFFSET ?";
        params.add(pageSize);
        params.add(Math.max(0, (page - 1) * pageSize));
        List<LotteryTicket> result = new ArrayList<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi tim kiem ve do: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public long count(String regionCode, String companyCode, LocalDate fromDate, LocalDate toDate, String status) {
        List<Object> params = new ArrayList<>();
        String sql = "SELECT COUNT(*) FROM lottery_tickets t "
                + "JOIN lottery_companies c ON c.company_code = t.company_code "
                + buildWhere(regionCode, companyCode, fromDate, toDate, status, params);
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi dem ve do: " + e.getMessage(), e);
        }
    }

    @Override
    public long countDrawTimes(Long ticketId) {
        String sql = "SELECT COUNT(*) FROM lottery_history WHERE ticket_id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, ticketId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi dem luot do: " + e.getMessage(), e);
        }
    }

    /** Dieu kien WHERE dung chung cho search va count (bang t = lottery_tickets, c = lottery_companies). */
    private static String buildWhere(String regionCode, String companyCode, LocalDate from, LocalDate to,
                                     String status, List<Object> params) {
        StringBuilder where = new StringBuilder("WHERE t.draw_date BETWEEN ? AND ? ");
        params.add(Date.valueOf(from));
        params.add(Date.valueOf(to));
        if (companyCode != null && !companyCode.isBlank()) {
            where.append("AND t.company_code = ? ");
            params.add(companyCode);
        } else if (regionCode != null && !regionCode.isBlank()) {
            where.append("AND c.region_code = ? ");
            params.add(regionCode);
        }
        if (status != null && !status.isBlank()) {
            where.append("AND t.status = ? ");
            params.add(status);
        }
        return where.toString();
    }

    private static void bind(PreparedStatement ps, List<Object> params) throws SQLException {
        for (int i = 0; i < params.size(); i++) {
            ps.setObject(i + 1, params.get(i));
        }
    }

    private LotteryTicket mapRow(ResultSet rs) throws SQLException {
        LotteryTicket t = new LotteryTicket();
        t.setId(rs.getLong("id"));
        t.setCompanyCode(rs.getString("company_code"));
        t.setCompanyName(rs.getString("company_name"));
        t.setRegionCode(rs.getString("region_code"));
        t.setRegionName(rs.getString("region_name"));
        t.setDrawDate(rs.getDate("draw_date").toLocalDate());
        t.setStatus(rs.getString("status"));
        t.setCreatedBy(rs.getLong("created_by"));
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            t.setCreatedAt(createdAt.toLocalDateTime());
        }
        return t;
    }
}
