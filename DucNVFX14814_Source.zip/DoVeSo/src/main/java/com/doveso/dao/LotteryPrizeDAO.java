package com.doveso.dao;

import com.doveso.model.LotteryPrize;
import java.util.List;

/**
 * Interface tang truy xuat du lieu cho entity LotteryPrize (cac giai cua 1 ve do).
 */
public interface LotteryPrizeDAO {

    /** Lay danh sach cac giai cua 1 ve do. */
    List<LotteryPrize> findByTicketId(Long ticketId);
}
