package com.doveso.dao;

import com.doveso.model.LotteryPrize;
import java.util.List;

/**
 * Interface tang truy xuat du lieu cho entity LotteryPrize (cac giai cua 1 ve do).
 */
public interface LotteryPrizeDAO {

    /** Them toan bo cac giai (thuong 8 dong: DB, G1..G7) cho 1 ve do. */
    void insertAll(Long ticketId, List<LotteryPrize> prizes);

    /** Lay danh sach cac giai cua 1 ve do. */
    List<LotteryPrize> findByTicketId(Long ticketId);
}
