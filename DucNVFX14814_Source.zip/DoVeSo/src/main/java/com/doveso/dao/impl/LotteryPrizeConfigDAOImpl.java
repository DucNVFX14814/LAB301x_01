package com.doveso.dao.impl;

import com.doveso.dao.LotteryPrizeConfigDAO;
import com.doveso.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/** Trien khai LotteryPrizeConfigDAO bang JDBC thuan tren MySQL (bang lottery_prize_configs). */
public class LotteryPrizeConfigDAOImpl implements LotteryPrizeConfigDAO {

    @Override
    public Map<String, Long> findAmountsByRegion(String regionCode) {
        String sql = "SELECT prize_code, prize_amount FROM lottery_prize_configs WHERE region_code = ?";
        Map<String, Long> result = new LinkedHashMap<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, regionCode);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.put(rs.getString("prize_code"), rs.getLong("prize_amount"));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi lay co cau giai thuong theo mien: " + e.getMessage(), e);
        }
        return result;
    }
}
