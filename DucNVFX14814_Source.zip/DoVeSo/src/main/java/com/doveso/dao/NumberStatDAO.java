package com.doveso.dao;

import com.doveso.model.PrizeDrawRow;
import java.util.List;

/**
 * Interface tang truy xuat du lieu tho phuc vu Chuc nang 4 (*): De xuat so ve so nen mua.
 */
public interface NumberStatDAO {

    /**
     * Lay toan bo cac dong (ngay quay so, chuoi so trung) cua cac ve do da PUBLISH thuoc 1 cong ty xo so,
     * sap xep theo ngay quay so giam dan (moi nhat truoc).
     *
     * @param companyCode ma cong ty xo so, bat buoc (khong ho tro "tat ca cong ty")
     */
    List<PrizeDrawRow> findAllPublishedPrizeNumbers(String companyCode);
}
