package com.doveso.dao.impl;

import com.doveso.dao.CompanyDAO;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryRegion;
import com.doveso.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Trien khai CompanyDAO bang JDBC thuan (lottery_regions, lottery_companies). */
public class CompanyDAOImpl implements CompanyDAO {

    private static final String REGION_ORDER = "FIELD(r.region_code, 'BAC', 'TRUNG', 'NAM')";
    private static final String SELECT_COMPANY = "SELECT c.company_code, c.company_name, c.region_code, "
            + "c.active, r.region_name FROM lottery_companies c "
            + "JOIN lottery_regions r ON r.region_code = c.region_code ";

    @Override
    public List<LotteryRegion> findAllRegions() {
        String sql = "SELECT r.region_code, r.region_name FROM lottery_regions r ORDER BY " + REGION_ORDER;
        List<LotteryRegion> result = new ArrayList<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                result.add(new LotteryRegion(rs.getString("region_code"), rs.getString("region_name")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi lay danh sach mien: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public List<LotteryCompany> findActiveCompanies() {
        String sql = SELECT_COMPANY + "WHERE c.active = TRUE ORDER BY " + REGION_ORDER + ", c.company_name";
        List<LotteryCompany> result = new ArrayList<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                result.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi lay danh sach cong ty xo so: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public LotteryCompany findByCode(String companyCode) {
        String sql = SELECT_COMPANY + "WHERE c.company_code = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, companyCode);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi tim cong ty xo so: " + e.getMessage(), e);
        }
    }

    private LotteryCompany mapRow(ResultSet rs) throws SQLException {
        LotteryCompany c = new LotteryCompany();
        c.setCompanyCode(rs.getString("company_code"));
        c.setCompanyName(rs.getString("company_name"));
        c.setRegionCode(rs.getString("region_code"));
        c.setRegionName(rs.getString("region_name"));
        c.setActive(rs.getBoolean("active"));
        return c;
    }
}
