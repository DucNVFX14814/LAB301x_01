package com.doveso.dao;

import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryTicket;
import java.time.LocalDate;
import java.util.List;

/**
 * Interface tang truy xuat du lieu cho entity LotteryTicket (ve do).
 * Chuc nang 2 - Quan ly ve do. Moi ve do thuoc 1 cong ty xo so (company_code) va 1 ngay quay so.
 */
public interface TicketDAO {

    /**
     * Them 1 ve do cung toan bo cac giai trong 1 transaction (thanh cong tat ca hoac khong luu gi).
     * ticket phai co companyCode, drawDate, createdBy.
     *
     * @return id ve do vua tao
     */
    Long insertWithPrizes(LotteryTicket ticket, List<LotteryPrize> prizes, boolean publish);

    /** Tim ve do theo id (khong kem danh sach giai, co kem ten dai/mien). */
    LotteryTicket findById(Long id);

    /** Tim ve do theo dai + ngay quay so, bat ke trang thai (dung cho ADMIN kiem tra trung / xem / publish). */
    LotteryTicket findByCompanyAndDate(String companyCode, LocalDate drawDate);

    /** Tim 1 ve do da PUBLISH theo dai + ngay quay so (dung cho chuc nang do ve). */
    LotteryTicket findPublishedByCompanyAndDate(String companyCode, LocalDate drawDate);

    /** Danh sach ngay quay so cua cac ve da PUBLISH, moi nhat truoc, khong trung ngay, gioi han so luong. */
    List<LocalDate> listPublishedDrawDates(int limit);

    /** Chuyen trang thai ve do sang PUBLISH (UNPUBLISH -> PUBLISH, khong cho chieu nguoc lai). */
    void publish(Long ticketId);

    /**
     * Tim kiem ve do theo mien / dai / khoang ngay / trang thai, co phan trang.
     * regionCode, companyCode, status = null hoac rong nghia la khong loc.
     */
    List<LotteryTicket> search(String regionCode, String companyCode, LocalDate fromDate, LocalDate toDate,
                               String status, int page, int pageSize);

    /** Dem tong so ve do thoa dieu kien loc (phuc vu tinh so trang). */
    long count(String regionCode, String companyCode, LocalDate fromDate, LocalDate toDate, String status);

    /** Dem so lan ve do da duoc dung de do (tra cuu trong lottery_history). */
    long countDrawTimes(Long ticketId);
}
