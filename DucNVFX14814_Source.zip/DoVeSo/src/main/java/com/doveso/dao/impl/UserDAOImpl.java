package com.doveso.dao.impl;

import com.doveso.dao.UserDAO;
import com.doveso.model.User;
import com.doveso.util.DBConnectionUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Trien khai UserDAO bang JDBC thuan (PreparedStatement) tren MySQL.
 * Quy uoc dat ten: cac phuong thuc DAO chi thao tac CSDL, khong chua logic
 * nghiep vu (logic nghiep vu dat trong Controller/Service).
 */
public class UserDAOImpl implements UserDAO {

    @Override
    public User findByEmail(String email) {
        String sql = "SELECT * FROM users WHERE email = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi truy van findByEmail: " + e.getMessage(), e);
        }
    }

    @Override
    public User findById(Long id) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi truy van findById: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean existsByEmail(String email) {
        return findByEmail(email) != null;
    }

    @Override
    public boolean existsByPhone(String phone) {
        String sql = "SELECT COUNT(*) FROM users WHERE phone = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, phone);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi truy van existsByPhone: " + e.getMessage(), e);
        }
    }

    @Override
    public Long insert(User user) {
        String sql = "INSERT INTO users (full_name, email, phone, password_hash, role, active, created_at) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.setString(4, user.getPasswordHash());
            ps.setString(5, user.getRole());
            ps.setBoolean(6, user.isActive());
            ps.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getLong(1) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi them nguoi dung: " + e.getMessage(), e);
        }
    }

    @Override
    public void updatePassword(Long userId, String newPasswordHash) {
        String sql = "UPDATE users SET password_hash = ? WHERE id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPasswordHash);
            ps.setLong(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Loi doi mat khau: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateRoleAndStatus(Long userId, String role, boolean active) {
        String sql = "UPDATE users SET role = ?, active = ? WHERE id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, role);
            ps.setBoolean(2, active);
            ps.setLong(3, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Loi cap nhat role/trang thai nguoi dung: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateLastLogin(Long userId) {
        String sql = "UPDATE users SET last_login_at = ? WHERE id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
            ps.setLong(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Loi cap nhat lan dang nhap: " + e.getMessage(), e);
        }
    }

    /**
     * Chuyen tu khoa thanh id neu tu khoa chi gom chu so; nguoc lai tra ve -1 (khong khop id nao).
     */
    private static long toIdOrMinusOne(String keyword) {
        if (keyword == null || !keyword.trim().matches("\\d{1,18}")) {
            return -1L;
        }
        return Long.parseLong(keyword.trim());
    }

    @Override
    public List<User> search(String keyword, LocalDateTime lastLoginBefore, boolean neverLoggedIn, int page, int pageSize) {
        // neverLoggedIn: chi lay nguoi dung chua tung dang nhap (last_login_at rong)
        // lastLoginBefore != null: chi lay nguoi dung DA TUNG dang nhap va lan dang nhap cuoi som hon moc nay
        String sql = "SELECT * FROM users WHERE (id = ? OR full_name LIKE ? OR email LIKE ? OR phone LIKE ?)"
                + loginCondition(lastLoginBefore, neverLoggedIn)
                + " ORDER BY id ASC LIMIT ? OFFSET ?";
        List<User> result = new ArrayList<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + (keyword == null ? "" : keyword) + "%";
            int i = 1;
            ps.setLong(i++, toIdOrMinusOne(keyword));
            ps.setString(i++, like);
            ps.setString(i++, like);
            ps.setString(i++, like);
            if (!neverLoggedIn && lastLoginBefore != null) {
                ps.setTimestamp(i++, Timestamp.valueOf(lastLoginBefore));
            }
            ps.setInt(i++, pageSize);
            ps.setInt(i, Math.max(0, (page - 1) * pageSize));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi tim kiem nguoi dung: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public long count(String keyword, LocalDateTime lastLoginBefore, boolean neverLoggedIn) {
        String sql = "SELECT COUNT(*) FROM users WHERE (id = ? OR full_name LIKE ? OR email LIKE ? OR phone LIKE ?)"
                + loginCondition(lastLoginBefore, neverLoggedIn);
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + (keyword == null ? "" : keyword) + "%";
            int i = 1;
            ps.setLong(i++, toIdOrMinusOne(keyword));
            ps.setString(i++, like);
            ps.setString(i++, like);
            ps.setString(i++, like);
            if (!neverLoggedIn && lastLoginBefore != null) {
                ps.setTimestamp(i, Timestamp.valueOf(lastLoginBefore));
            }
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi dem so nguoi dung: " + e.getMessage(), e);
        }
    }

    /** Dieu kien loc theo lan dang nhap cuoi (them vao sau menh de WHERE). */
    private static String loginCondition(LocalDateTime lastLoginBefore, boolean neverLoggedIn) {
        if (neverLoggedIn) {
            return " AND last_login_at IS NULL";
        }
        return lastLoginBefore != null ? " AND last_login_at IS NOT NULL AND last_login_at < ?" : "";
    }

    @Override
    public void saveResetToken(Long userId, String tokenHash, LocalDateTime expireAt) {
        String sql = "UPDATE users SET reset_token = ?, reset_token_expire = ? WHERE id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tokenHash);
            ps.setTimestamp(2, Timestamp.valueOf(expireAt));
            ps.setLong(3, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Loi luu token dat lai mat khau: " + e.getMessage(), e);
        }
    }

    @Override
    public User findByValidResetToken(String tokenHash) {
        String sql = "SELECT * FROM users WHERE reset_token = ? AND reset_token_expire > ? AND active = TRUE";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tokenHash);
            ps.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi tim token dat lai mat khau: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean resetPasswordWithToken(String tokenHash, String newPasswordHash) {
        String sql = "UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expire = NULL "
                + "WHERE reset_token = ? AND reset_token_expire > ? AND active = TRUE";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPasswordHash);
            ps.setString(2, tokenHash);
            ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Loi dat lai mat khau: " + e.getMessage(), e);
        }
    }

    private User mapRow(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getLong("id"));
        u.setFullName(rs.getString("full_name"));
        u.setEmail(rs.getString("email"));
        u.setPhone(rs.getString("phone"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setRole(rs.getString("role"));
        u.setActive(rs.getBoolean("active"));
        Timestamp lastLogin = rs.getTimestamp("last_login_at");
        if (lastLogin != null) {
            u.setLastLoginAt(lastLogin.toLocalDateTime());
        }
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            u.setCreatedAt(createdAt.toLocalDateTime());
        }
        return u;
    }
}