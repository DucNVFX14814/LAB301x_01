package com.doveso.dao.impl;

import com.doveso.dao.LotteryHistoryDAO;
import com.doveso.model.LotteryHistory;
import com.doveso.util.DBConnectionUtil;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** Trien khai LotteryHistoryDAO bang JDBC thuan tren MySQL (bang lottery_history). */
public class LotteryHistoryDAOImpl implements LotteryHistoryDAO {

    @Override
    public Long insert(LotteryHistory history) {
        String sql = "INSERT INTO lottery_history (user_id, ticket_id, ticket_number, result_summary, "
                + "prize_amount, checked_at) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, history.getUserId());
            ps.setLong(2, history.getTicketId());
            ps.setString(3, history.getTicketNumber());
            ps.setString(4, history.getResultSummary());
            if (history.getPrizeAmount() != null) {
                ps.setLong(5, history.getPrizeAmount());
            } else {
                ps.setNull(5, Types.BIGINT);
            }
            ps.setTimestamp(6, Timestamp.valueOf(LocalDateTime.now()));
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getLong(1) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi luu lich su do ve: " + e.getMessage(), e);
        }
    }

    private static final String SELECT_HISTORY = "SELECT h.*, t.draw_date, t.company_code, "
            + "c.company_name, r.region_name FROM lottery_history h "
            + "JOIN lottery_tickets t ON h.ticket_id = t.id "
            + "JOIN lottery_companies c ON c.company_code = t.company_code "
            + "JOIN lottery_regions r ON r.region_code = c.region_code ";

    @Override
    public List<LotteryHistory> findByUserId(Long userId, String regionCode, String companyCode,
                                              LocalDate fromDate, LocalDate toDate, int page, int pageSize) {
        List<Object> params = new ArrayList<>();
        String sql = SELECT_HISTORY + buildWhere(userId, regionCode, companyCode, fromDate, toDate, params)
                + "ORDER BY h.checked_at DESC, h.id DESC LIMIT ? OFFSET ?";
        params.add(pageSize);
        params.add(Math.max(0, (page - 1) * pageSize));
        List<LotteryHistory> result = new ArrayList<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi lay lich su do ve: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public long countByUserId(Long userId, String regionCode, String companyCode,
                               LocalDate fromDate, LocalDate toDate) {
        List<Object> params = new ArrayList<>();
        String sql = "SELECT COUNT(*) FROM lottery_history h "
                + "JOIN lottery_tickets t ON h.ticket_id = t.id "
                + buildWhere(userId, regionCode, companyCode, fromDate, toDate, params);
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi dem lich su do ve: " + e.getMessage(), e);
        }
    }

    /**
     * Dieu kien WHERE dung chung cho danh sach va dem (bang h = lottery_history, t = lottery_tickets).
     * fromDate/toDate loc theo h.checked_at (thoi diem do), theo khoang [fromDate 00:00, toDate+1 00:00).
     */
    private static String buildWhere(Long userId, String regionCode, String companyCode,
                                      LocalDate fromDate, LocalDate toDate, List<Object> params) {
        StringBuilder where = new StringBuilder("WHERE h.user_id = ? ");
        params.add(userId);
        if (companyCode != null && !companyCode.isBlank()) {
            where.append("AND t.company_code = ? ");
            params.add(companyCode);
        } else if (regionCode != null && !regionCode.isBlank()) {
            where.append("AND t.company_code IN (SELECT company_code FROM lottery_companies WHERE region_code = ?) ");
            params.add(regionCode);
        }
        if (fromDate != null) {
            where.append("AND h.checked_at >= ? ");
            params.add(Timestamp.valueOf(fromDate.atStartOfDay()));
        }
        if (toDate != null) {
            where.append("AND h.checked_at < ? ");
            params.add(Timestamp.valueOf(toDate.plusDays(1).atStartOfDay()));
        }
        return where.toString();
    }

    private static void bind(PreparedStatement ps, List<Object> params) throws SQLException {
        for (int i = 0; i < params.size(); i++) {
            ps.setObject(i + 1, params.get(i));
        }
    }

    private LotteryHistory mapRow(ResultSet rs) throws SQLException {
        LotteryHistory h = new LotteryHistory();
        h.setId(rs.getLong("id"));
        h.setUserId(rs.getLong("user_id"));
        h.setTicketId(rs.getLong("ticket_id"));
        h.setTicketNumber(rs.getString("ticket_number"));
        h.setResultSummary(rs.getString("result_summary"));
        long amount = rs.getLong("prize_amount");
        h.setPrizeAmount(rs.wasNull() ? null : amount);
        Timestamp checkedAt = rs.getTimestamp("checked_at");
        if (checkedAt != null) {
            h.setCheckedAt(checkedAt.toLocalDateTime());
        }
        h.setDrawDate(rs.getDate("draw_date").toLocalDate());
        h.setCompanyCode(rs.getString("company_code"));
        h.setCompanyName(rs.getString("company_name"));
        h.setRegionName(rs.getString("region_name"));
        return h;
    }
}
