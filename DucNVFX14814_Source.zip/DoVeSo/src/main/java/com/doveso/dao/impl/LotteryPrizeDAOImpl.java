package com.doveso.dao.impl;

import com.doveso.dao.LotteryPrizeDAO;
import com.doveso.model.LotteryPrize;
import com.doveso.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Trien khai LotteryPrizeDAO bang JDBC thuan tren MySQL (bang lottery_ticket_items). */
public class LotteryPrizeDAOImpl implements LotteryPrizeDAO {

    @Override
    public List<LotteryPrize> findByTicketId(Long ticketId) {
        String sql = "SELECT * FROM lottery_ticket_items WHERE ticket_id = ?";
        List<LotteryPrize> result = new ArrayList<>();
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, ticketId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    LotteryPrize p = new LotteryPrize();
                    p.setId(rs.getLong("id"));
                    p.setTicketId(rs.getLong("ticket_id"));
                    p.setPrizeCode(rs.getString("prize_code"));
                    p.setPrizeName(rs.getString("prize_name"));
                    p.setPrizeNumber(rs.getString("prize_number"));
                    result.add(p);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Loi lay danh sach giai cua ve do: " + e.getMessage(), e);
        }
        return result;
    }
}
