package com.doveso.dao;

import com.doveso.model.User;
import java.util.List;
import java.time.LocalDateTime;

/**
 * Interface tang truy xuat du lieu cho entity User.
 * UC01, UC02, UC05, UC06, UC07, UC08, UC09 trong HV_SRS.
 */
public interface UserDAO {

    User findByEmail(String email);

    User findById(Long id);

    boolean existsByEmail(String email);

    boolean existsByPhone(String phone);

    Long insert(User user);

    void updatePassword(Long userId, String newPasswordHash);

    /** Cap nhat dong thoi ROLE va trang thai active cho 1 nguoi dung trong 1 lan UPDATE (dung cho luu hang loat tren bang admin). */
    void updateRoleAndStatus(Long userId, String role, boolean active);

    void updateLastLogin(Long userId);

    /** Tim kiem theo id, ho ten, email, so dien thoai, ho tro phan trang. */
    List<User> search(String keyword, LocalDateTime lastLoginBefore, boolean neverLoggedIn, int page, int pageSize);

    long count(String keyword, LocalDateTime lastLoginBefore, boolean neverLoggedIn);

    /**
     * Luu token dat lai mat khau (da bam SHA-256) va thoi diem het han cho nguoi dung.
     * Moi nguoi dung chi co 1 token con hieu luc (token moi ghi de token cu).
     */
    void saveResetToken(Long userId, String tokenHash, LocalDateTime expireAt);

    /** Tim nguoi dung co token khop, chua het han va tai khoan con hoat dong. Tra ve null neu khong co. */
    User findByValidResetToken(String tokenHash);

    /**
     * Dat mat khau moi va xoa token trong 1 cau UPDATE; chi thanh cong khi token con hop le
     * (nen moi token chi dung duoc 1 lan).
     *
     * @return true neu da cap nhat mat khau
     */
    boolean resetPasswordWithToken(String tokenHash, String newPasswordHash);
}