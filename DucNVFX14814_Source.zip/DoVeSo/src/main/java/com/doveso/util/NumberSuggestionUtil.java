package com.doveso.util;

import com.doveso.model.NumberStat;
import com.doveso.model.PrizeDrawRow;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Phan tich tan suat xuat hien cua so lo (2 chu so cuoi, "00".."99") tren cac ve do
 * da PUBLISH (toi da 50 ky quay so gan nhat), de xuat top so "nong" (ve nhieu nhat) va top so "nguội/gan" (lau chua ve nhat).
 * Chuc nang 4 (*): Phan tich va de xuat so ve so nen mua - CHI MANG TINH THAM KHAO THONG KE,
 * khong dam bao ket qua vi xo so la ngau nhien.
 */
public final class NumberSuggestionUtil {

    /** So ky quay so gan nhat toi da duoc dua vao thong ke (neu du lieu nhieu hon thi chi lay 50 ky moi nhat). */
    private static final int MAX_DRAWS = 50;

    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private NumberSuggestionUtil() {
    }

    /** Ket qua phan tich: top so ve nhieu/lau chua ve, va thong tin tong quan. */
    public static class Result {
        private final List<NumberStat> hotNumbers;
        private final List<NumberStat> coldNumbers;
        private final int totalDraws;
        private final String latestDrawDateFormatted;

        Result(List<NumberStat> hotNumbers, List<NumberStat> coldNumbers, int totalDraws,
               String latestDrawDateFormatted) {
            this.hotNumbers = hotNumbers;
            this.coldNumbers = coldNumbers;
            this.totalDraws = totalDraws;
            this.latestDrawDateFormatted = latestDrawDateFormatted;
        }

        public List<NumberStat> getHotNumbers() {
            return hotNumbers;
        }

        public List<NumberStat> getColdNumbers() {
            return coldNumbers;
        }

        public int getTotalDraws() {
            return totalDraws;
        }

        public String getLatestDrawDateFormatted() {
            return latestDrawDateFormatted;
        }

        public boolean isNoData() {
            return totalDraws == 0;
        }
    }

    /**
     * @param rows  du lieu tho (ngay quay so, chuoi so trung), da sap xep giam dan theo ngay
     * @param topN  so luong so muon lay cho moi danh sach (nong / nguoi)
     */
    public static Result analyze(List<PrizeDrawRow> rows, int topN) {
        if (rows.isEmpty()) {
            return new Result(Collections.emptyList(), Collections.emptyList(), 0, null);
        }

        // Danh sach cac ngay quay so khac nhau, giu nguyen thu tu moi nhat truoc
        // (rows da duoc DAO sap xep giam dan theo draw_date).
        List<LocalDate> distinctDatesDesc = new ArrayList<>();
        LocalDate lastAdded = null;
        for (PrizeDrawRow row : rows) {
            if (!row.getDrawDate().equals(lastAdded)) {
                distinctDatesDesc.add(row.getDrawDate());
                lastAdded = row.getDrawDate();
            }
        }
        // Chi lay MAX_DRAWS ky quay so gan nhat: cat bot danh sach ngay va loai cac dong cu hon ngay cuoi cung duoc giu lai.
        if (distinctDatesDesc.size() > MAX_DRAWS) {
            LocalDate oldestKept = distinctDatesDesc.get(MAX_DRAWS - 1);
            distinctDatesDesc = new ArrayList<>(distinctDatesDesc.subList(0, MAX_DRAWS));
            List<PrizeDrawRow> recentRows = new ArrayList<>();
            for (PrizeDrawRow row : rows) {
                if (!row.getDrawDate().isBefore(oldestKept)) {
                    recentRows.add(row);
                }
            }
            rows = recentRows;
        }
        int totalDraws = distinctDatesDesc.size();

        Map<String, Integer> frequency = new LinkedHashMap<>();
        Map<String, LocalDate> lastSeen = new LinkedHashMap<>();
        for (int i = 0; i <= 99; i++) {
            frequency.put(pad(i), 0);
        }

        for (PrizeDrawRow row : rows) {
            for (String token : row.getPrizeNumber().split("-")) {
                if (token.isBlank() || token.length() < 2) {
                    continue;
                }
                String twoDigit = token.substring(token.length() - 2);
                frequency.merge(twoDigit, 1, Integer::sum);
                // rows da sap giam dan theo ngay -> lan dau gap 1 so la lan xuat hien gan nhat cua no
                lastSeen.putIfAbsent(twoDigit, row.getDrawDate());
            }
        }

        List<NumberStat> all = new ArrayList<>();
        for (int i = 0; i <= 99; i++) {
            String number = pad(i);
            int freq = frequency.get(number);
            LocalDate seen = lastSeen.get(number);
            // gapDraws = so ky (tinh tu ky gan nhat) ma so nay chua xuat hien lai; so chua tung ve = totalDraws
            int gapDraws = (seen == null) ? totalDraws : distinctDatesDesc.indexOf(seen);
            all.add(new NumberStat(number, freq, seen == null ? "" : seen.format(DISPLAY_DATE), gapDraws));
        }

        List<NumberStat> hot = new ArrayList<>(all);
        hot.removeIf(n -> n.getFrequency() == 0);
        hot.sort(Comparator.comparingInt(NumberStat::getFrequency).reversed()
                .thenComparingInt(NumberStat::getGapDraws)
                .thenComparing(NumberStat::getNumber));
        List<NumberStat> hotTop = new ArrayList<>(hot.subList(0, Math.min(topN, hot.size())));

        List<NumberStat> cold = new ArrayList<>(all);
        cold.sort(Comparator.comparingInt(NumberStat::getGapDraws).reversed()
                .thenComparingInt(NumberStat::getFrequency)
                .thenComparing(NumberStat::getNumber));
        List<NumberStat> coldTop = new ArrayList<>(cold.subList(0, Math.min(topN, cold.size())));

        return new Result(hotTop, coldTop, totalDraws, distinctDatesDesc.get(0).format(DISPLAY_DATE));
    }

    private static String pad(int n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }
}
