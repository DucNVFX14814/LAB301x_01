package com.doveso.util;

import com.doveso.util.MinhNgocClient.RegionResult;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Bo nho dem ket qua da lay tu nguon trong 1 request cua ADMIN (khong dung chung giua cac request).
 *
 * Moi trang nguon tra ve nhieu ngay cung luc (trang mien: 7 ngay lien tiep, trang tinh: 6 ky gan nhat),
 * nen khi them hang loat chi can vai request thay vi 1 request cho moi ngay.
 * Moi "nguon" duoc phan biet bang key (vd "REGION:NAM" hoac "PROVINCE:da-nang").
 *
 * Quy uoc: 1 ngay duoc coi la "da phu" khi nam trong khoang [ngay cu nhat co tren trang, ngay da yeu cau]
 * cua 1 trang da tai. Ngay da phu ma khong co ket qua nghia la nguon khong co du lieu ngay do.
 */
public class LotteryResultCache {

    /** Ham lay 1 trang nguon tinh tu ngay date lui ve truoc. */
    public interface Fetcher {
        Map<LocalDate, RegionResult> fetch(LocalDate date) throws LotteryFetchException;
    }

    private static final int MAX_PAGES_PER_PREFETCH = 12;

    private final Map<String, TreeMap<LocalDate, RegionResult>> results = new HashMap<>();
    private final Map<String, List<LocalDate[]>> covered = new HashMap<>();
    private final Map<String, Map<LocalDate, String>> failed = new HashMap<>();

    /**
     * Tai truoc cac trang can thiet de phu khoang [from, to]: bat dau tu ngay moi nhat, moi trang cho biet
     * ngay cu nhat, roi tai tiep tu ngay truoc do. Loi tai trang duoc ghi nho, khong nem ra ngoai.
     */
    public void prefetch(String key, LocalDate from, LocalDate to, Fetcher fetcher) {
        LocalDate cursor = to;
        for (int i = 0; i < MAX_PAGES_PER_PREFETCH && !cursor.isBefore(from); i++) {
            LocalDate start = coveredStart(key, cursor);
            if (start == null) {
                try {
                    load(key, cursor, fetcher);
                } catch (LotteryFetchException e) {
                    markFailed(key, from, cursor, e.getMessage());
                    return;
                }
                start = coveredStart(key, cursor);
            }
            if (start == null || !start.isBefore(cursor)) {
                cursor = cursor.minusDays(1); // trang khong cho them ngay nao truoc do, tiep tuc lui tung ngay
            } else {
                cursor = start.minusDays(1);
            }
        }
    }

    /**
     * Lay ket qua cua ngay date tu nguon key (tai trang neu chua co).
     *
     * @return ket qua cua ngay do, hoac null neu trang da tai nhung khong co ngay nay
     * @throws LotteryFetchException neu khong tai duoc trang (loi da ghi nho cung duoc nem lai)
     */
    public RegionResult get(String key, LocalDate date, Fetcher fetcher) throws LotteryFetchException {
        String failure = failed.getOrDefault(key, Map.of()).get(date);
        if (failure != null) {
            throw new LotteryFetchException(failure);
        }
        if (coveredStart(key, date) == null) {
            try {
                load(key, date, fetcher);
            } catch (LotteryFetchException e) {
                markFailed(key, date, date, e.getMessage());
                throw e;
            }
        }
        TreeMap<LocalDate, RegionResult> byDate = results.get(key);
        return byDate == null ? null : byDate.get(date);
    }

    private void load(String key, LocalDate date, Fetcher fetcher) throws LotteryFetchException {
        Map<LocalDate, RegionResult> page = fetcher.fetch(date);
        TreeMap<LocalDate, RegionResult> byDate = results.computeIfAbsent(key, k -> new TreeMap<>());
        LocalDate oldest = date;
        for (Map.Entry<LocalDate, RegionResult> e : page.entrySet()) {
            byDate.putIfAbsent(e.getKey(), e.getValue());
            if (e.getKey().isBefore(oldest)) {
                oldest = e.getKey();
            }
        }
        covered.computeIfAbsent(key, k -> new ArrayList<>()).add(new LocalDate[]{oldest, date});
    }

    /** Ngay cu nhat cua khoang da phu chua date, null neu date chua duoc phu. */
    private LocalDate coveredStart(String key, LocalDate date) {
        LocalDate best = null;
        for (LocalDate[] range : covered.getOrDefault(key, List.of())) {
            if (!date.isBefore(range[0]) && !date.isAfter(range[1]) && (best == null || range[0].isBefore(best))) {
                best = range[0];
            }
        }
        return best;
    }

    private void markFailed(String key, LocalDate from, LocalDate to, String message) {
        Map<LocalDate, String> byDate = failed.computeIfAbsent(key, k -> new HashMap<>());
        for (LocalDate d = from; !d.isAfter(to); d = d.plusDays(1)) {
            if (coveredStart(key, d) == null) {
                byDate.put(d, message);
            }
        }
    }
}
