package com.doveso.util;

import com.doveso.model.LotteryPrize;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Lop tien ich doi chieu 1 so ve so (khong phu thuoc so chu so - dung chung cho ca 3 mien Bac/Trung/Nam)
 * voi cac giai cua 1 ve do.
 *
 * Quy tac doi chieu: voi moi so trong moi giai, lay N chu so cuoi cua so ve
 * (N = do dai so cua giai do) roi so sanh. Ve trung nhieu giai duoc linh du gia tri cac giai,
 * rieng giai Dac biet la ngoai le: neu trung Dac biet thi chi tinh Dac biet, khong cong don them giai khac.
 *
 * Muc thuong tung giai (VND) khong con fix cung ma duoc truyen vao tu bang lottery_prize_configs
 * (xem LotteryPrizeConfigDAO), theo dung mien cua ve do dang doi chieu.
 */
public final class LotteryCheckUtil {

    private LotteryCheckUtil() {
    }

    /** Mot lan trung giai cua so ve. */
    public static class PrizeMatch {
        private final String code;
        private final String name;
        private final long amount;

        private PrizeMatch(String code, String name, long amount) {
            this.code = code;
            this.name = name;
            this.amount = amount;
        }

        public String getCode() {
            return code;
        }

        public String getName() {
            return name;
        }

        public long getAmount() {
            return amount;
        }
    }

    /** Ket qua doi chieu 1 so ve so voi 1 ve do. */
    public static class CheckResult {
        private final String ticketNumber;
        private final List<PrizeMatch> matches;
        private final long totalAmount;

        private CheckResult(String ticketNumber, List<PrizeMatch> matches) {
            this.ticketNumber = ticketNumber;
            this.matches = Collections.unmodifiableList(matches);
            long sum = 0;
            for (PrizeMatch m : matches) {
                sum += m.getAmount();
            }
            this.totalAmount = sum;
        }

        public String getTicketNumber() {
            return ticketNumber;
        }

        public boolean isWon() {
            return !matches.isEmpty();
        }

        /** Cac giai trung (theo thu tu giai tu cao xuong thap). */
        public List<PrizeMatch> getMatches() {
            return matches;
        }

        /** Tong tien thuong cua tat ca cac giai trung (0 neu khong trung). */
        public long getTotalAmount() {
            return totalAmount;
        }

        /** Tong tien thuong de luu lich su: null neu khong trung giai. */
        public Long getPrizeAmount() {
            return isWon() ? totalAmount : null;
        }

        /** Co trung giai Dac biet (5 chu so) hay khong. */
        public boolean isSpecialMatched() {
            for (PrizeMatch m : matches) {
                if ("DB".equals(m.getCode())) {
                    return true;
                }
            }
            return false;
        }

        /** Tom tat ket qua, vd "Trúng Giải nhì, Giải bảy (2 lần)" hoac "Không trúng giải". */
        public String getSummary() {
            if (matches.isEmpty()) {
                return "Không trúng giải";
            }
            Map<String, Integer> counts = new LinkedHashMap<>();
            for (PrizeMatch m : matches) {
                counts.merge(m.getName(), 1, Integer::sum);
            }
            List<String> parts = new ArrayList<>();
            counts.forEach((name, n) -> parts.add(n > 1 ? name + " (" + n + " lần)" : name));
            return "Trúng " + String.join(", ", parts);
        }
    }

    /**
     * Doi chieu 1 so ve so voi danh sach cac giai cua 1 ve do.
     * Tra ve tat ca cac giai ma so ve khop (ve trung nhieu giai duoc linh du).
     * Rieng giai Dac biet: neu trung Dac biet thi chi tinh Dac biet, khong cong don them
     * cac giai khac du trung hop (vi du trung ca Dac biet lan Giai bay do trung 2 so cuoi).
     *
     * @param prizeAmounts co cau giai thuong (prize_code -> so tien VND) cua dung mien ve do,
     *                     lay tu LotteryPrizeConfigDAO#findAmountsByRegion.
     */
    public static CheckResult check(String ticketNumber, List<LotteryPrize> prizes, Map<String, Long> prizeAmounts) {
        String number = ticketNumber.trim();
        List<PrizeMatch> matches = new ArrayList<>();
        for (String code : LotteryPrize.PRIZE_ORDER) {
            LotteryPrize prize = findByCode(prizes, code);
            if (prize == null) {
                continue;
            }
            for (String prizeNumber : prize.getNumbers()) {
                if (!prizeNumber.isEmpty() && number.endsWith(prizeNumber)) {
                    matches.add(new PrizeMatch(code, prize.getPrizeName(), prizeAmounts.getOrDefault(code, 0L)));
                }
            }
        }
        boolean hasSpecial = false;
        for (PrizeMatch m : matches) {
            if ("DB".equals(m.getCode())) {
                hasSpecial = true;
                break;
            }
        }
        if (hasSpecial) {
            List<PrizeMatch> specialOnly = new ArrayList<>();
            for (PrizeMatch m : matches) {
                if ("DB".equals(m.getCode())) {
                    specialOnly.add(m);
                }
            }
            matches = specialOnly;
        }
        return new CheckResult(number, matches);
    }

    private static LotteryPrize findByCode(List<LotteryPrize> prizes, String code) {
        for (LotteryPrize p : prizes) {
            if (code.equals(p.getPrizeCode())) {
                return p;
            }
        }
        return null;
    }
}
