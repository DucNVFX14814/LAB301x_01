package com.doveso.util;

import java.util.Properties;

/**
 * Lop tien ich doc cau hinh nhay cam (mat khau CSDL, mat khau email) uu tien tu BIEN MOI TRUONG,
 * neu khong co moi dung gia tri trong file .properties.
 * Muc dich: khong bat buoc phai ghi mat khau that vao file nam trong ma nguon (tranh lo khi day len Git).
 */
public final class ConfigUtil {

    private ConfigUtil() {
        // Chi dung phuong thuc static
    }

    /** Gia tri bien moi truong, tra ve null neu khong dat hoac rong. */
    public static String env(String name) {
        String value = System.getenv(name);
        return (value == null || value.trim().isEmpty()) ? null : value.trim();
    }

    /** Neu bien moi truong envName co gia tri thi ghi de len khoa key trong props. */
    public static void overrideFromEnv(Properties props, String key, String envName) {
        String value = env(envName);
        if (value != null) {
            props.setProperty(key, value);
        }
    }
}
