package com.doveso.util;

import com.doveso.model.LotteryCompany;
import com.doveso.util.MinhNgocClient.RegionResult;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/** Nguon ket qua xo so lay tu trang minhngoc.net.vn (xem MinhNgocClient). */
public class MinhNgocResultSource implements LotteryResultSource {

    @Override
    public Map<LocalDate, RegionResult> fetchRegionPage(String regionCode, LocalDate drawDate,
                                                        List<LotteryCompany> companies)
            throws LotteryFetchException {
        return MinhNgocClient.fetchRegionPage(regionCode, drawDate, companies);
    }

    @Override
    public Map<LocalDate, RegionResult> fetchProvincePage(LotteryCompany company, LocalDate drawDate)
            throws LotteryFetchException {
        return MinhNgocClient.fetchProvincePage(company, drawDate);
    }
}
