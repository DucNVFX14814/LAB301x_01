package com.doveso.util;

import com.doveso.model.LotteryCompany;
import com.doveso.util.MinhNgocClient.RegionResult;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Nguon cung cap ket qua xo so (UC10: Them ve do). Tach thanh interface de tang BO khong phu thuoc truc tiep
 * vao mang/trang nguon: khi chay that dung MinhNgocResultSource, khi unit test dung mock.
 * Co the bo sung nguon du phong (vd nhap tay) bang cach viet them 1 lop cai dat interface nay.
 */
public interface LotteryResultSource {

    /**
     * Lay trang ket qua cua mien regionCode (tinh tu ngay drawDate lui ve truoc), tra ve ket qua cua tat ca
     * cac ngay co tren trang, moi ngay gom cac tinh co trong companies.
     *
     * @throws LotteryFetchException khi khong ket noi duoc hoac nguon tra ve loi
     */
    Map<LocalDate, RegionResult> fetchRegionPage(String regionCode, LocalDate drawDate,
                                                 List<LotteryCompany> companies) throws LotteryFetchException;

    /**
     * Lay trang ket qua rieng cua 1 tinh (chi mien Trung / Nam), tinh tu ngay drawDate lui ve truoc.
     *
     * @throws LotteryFetchException khi khong ket noi duoc hoac nguon tra ve loi
     */
    Map<LocalDate, RegionResult> fetchProvincePage(LotteryCompany company, LocalDate drawDate)
            throws LotteryFetchException;
}
