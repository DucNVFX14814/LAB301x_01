package com.doveso.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Tao va bam token dat lai mat khau (UC05).
 * Token goc chi gui qua email; CSDL chi luu ban bam SHA-256 (64 ky tu hex, vua cot reset_token VARCHAR(100)).
 */
public final class ResetTokenUtil {

    /** Thoi gian hieu luc cua lien ket dat lai mat khau (phut) - theo SRS UC05. */
    public static final int EXPIRE_MINUTES = 30;

    private static final SecureRandom RANDOM = new SecureRandom();

    private ResetTokenUtil() {
        // Chi dung phuong thuc static
    }

    /** Sinh token ngau nhien 256 bit, ma hoa Base64 URL-safe (43 ky tu, khong can encode tren URL). */
    public static String generateToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    /** Bam token bang SHA-256, tra ve chuoi hex 64 ky tu. */
    public static String hash(String token) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashed = digest.digest(token.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(hashed.length * 2);
            for (byte b : hashed) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 luon co san trong moi JVM
            throw new IllegalStateException("Khong ho tro SHA-256", e);
        }
    }
}
