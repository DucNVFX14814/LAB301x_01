package com.doveso.util;

/**
 * Loi khi lay hoac phan tich ket qua xo so tu nguon du lieu ben ngoai (Minh Ngoc).
 * Message la thong bao tieng Viet, co the hien thi truc tiep cho ADMIN.
 */
public class LotteryFetchException extends Exception {

    public LotteryFetchException(String message) {
        super(message);
    }

    public LotteryFetchException(String message, Throwable cause) {
        super(message, cause);
    }
}
