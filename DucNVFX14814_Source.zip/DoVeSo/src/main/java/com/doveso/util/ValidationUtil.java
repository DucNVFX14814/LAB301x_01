package com.doveso.util;

import java.util.regex.Pattern;

/**
 * Lop tien ich kiem tra dinh dang du lieu dau vao (email, so dien thoai, mat khau).
 */
public final class ValidationUtil {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^0\\d{9}$");
    private static final Pattern TICKET_NUMBER_PATTERN =
            Pattern.compile("^\\d{5}$");
    private static final Pattern TICKET_NUMBER_PATTERN_6 =
            Pattern.compile("^\\d{6}$");
    private static final Pattern FULL_NAME_PATTERN =
            Pattern.compile("^[\\p{L} ]{2,150}$");

    private ValidationUtil() {
    }

    /** Kiem tra ho ten hop le: 2-150 ky tu, chi gom chu cai (co dau) va khoang trang. */
    public static boolean isValidFullName(String fullName) {
        return fullName != null && FULL_NAME_PATTERN.matcher(fullName.trim()).matches();
    }

    /**
     * Kiem tra so ve so hop le theo so chu so yeu cau (5 - mien Bac, 6 - mien Nam/Trung).
     * expectedLength khac 5 va 6 se duoc coi nhu 6 (an toan, khong khop nham).
     */
    public static boolean isValidTicketNumber(String ticketNumber, int expectedLength) {
        if (ticketNumber == null) {
            return false;
        }
        Pattern pattern = (expectedLength == 5) ? TICKET_NUMBER_PATTERN : TICKET_NUMBER_PATTERN_6;
        return pattern.matcher(ticketNumber.trim()).matches();
    }

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && PHONE_PATTERN.matcher(phone.trim()).matches();
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= 6;
    }

    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    /** Trim null-safe, tra ve chuoi rong neu dau vao null (dung chung cho cac servlet doc parameter). */
    public static String trimToEmpty(String value) {
        return value == null ? "" : value.trim();
    }
}