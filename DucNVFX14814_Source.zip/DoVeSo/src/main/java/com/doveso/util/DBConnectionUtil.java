package com.doveso.util;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Lop tien ich cap ket noi den co so du lieu MySQL thong qua connection pool (HikariCP).
 * Thong tin ket noi doc tu tap tin classpath db.properties (src/main/resources/db.properties):
 * db.driver, db.url, db.username, db.password, db.pool.initialSize (so ket noi nhan roi toi thieu),
 * db.pool.maxSize (so ket noi toi da). Cac khoa url/username/password co the duoc ghi de bang bien moi truong
 * DOVESO_DB_URL, DOVESO_DB_USERNAME, DOVESO_DB_PASSWORD.
 *
 * Quy uoc: moi phuong thuc trong tang DAO phai dong Connection, Statement/PreparedStatement va ResultSet
 * bang try-with-resources. Voi connection pool, close() khong dong ket noi that ma tra no ve pool de tai su dung.
 */
public final class DBConnectionUtil {

    private static final int DEFAULT_INITIAL_SIZE = 5;
    private static final int DEFAULT_MAX_SIZE = 20;
    /** Thoi gian toi da cho lay 1 ket noi tu pool (ms), qua han thi nem SQLException nhu khi CSDL khong ket noi duoc. */
    private static final long CONNECTION_TIMEOUT_MS = 10_000L;

    private static final HikariDataSource DATA_SOURCE;

    static {
        Properties props = new Properties();
        try (InputStream is = DBConnectionUtil.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (is != null) {
                props.load(is);
            }
            ConfigUtil.overrideFromEnv(props, "db.url", "DOVESO_DB_URL");
            ConfigUtil.overrideFromEnv(props, "db.username", "DOVESO_DB_USERNAME");
            ConfigUtil.overrideFromEnv(props, "db.password", "DOVESO_DB_PASSWORD");
            Class.forName(props.getProperty("db.driver"));
        } catch (IOException | ClassNotFoundException | RuntimeException e) {
            throw new ExceptionInInitializerError("Khong the nap cau hinh/driver CSDL: " + e.getMessage());
        }

        int maxSize = readPositiveInt(props, "db.pool.maxSize", DEFAULT_MAX_SIZE);
        int initialSize = Math.min(readPositiveInt(props, "db.pool.initialSize", DEFAULT_INITIAL_SIZE), maxSize);

        HikariConfig config = new HikariConfig();
        config.setPoolName("doveso-pool");
        config.setDriverClassName(props.getProperty("db.driver"));
        config.setJdbcUrl(props.getProperty("db.url"));
        config.setUsername(props.getProperty("db.username"));
        config.setPassword(props.getProperty("db.password"));
        config.setMaximumPoolSize(maxSize);
        config.setMinimumIdle(initialSize);
        config.setConnectionTimeout(CONNECTION_TIMEOUT_MS);
        // Khong lam hong luc khoi dong khi CSDL chua bat: loi se hien ra khi goi getConnection() (nhu truoc day)
        config.setInitializationFailTimeout(-1);
        DATA_SOURCE = new HikariDataSource(config);
    }

    private DBConnectionUtil() {
        // Khong cho phep khoi tao instance - chi su dung phuong thuc static
    }

    /** Lay 1 ket noi tu pool. Nguoi goi phai dong (close) ket noi sau khi dung de tra ve pool. */
    public static Connection getConnection() throws SQLException {
        return DATA_SOURCE.getConnection();
    }

    /** Dong pool khi ung dung dung (goi tu DbPoolListener). */
    public static void shutdown() {
        if (!DATA_SOURCE.isClosed()) {
            DATA_SOURCE.close();
        }
    }

    private static int readPositiveInt(Properties props, String key, int defaultValue) {
        try {
            int value = Integer.parseInt(props.getProperty(key, "").trim());
            return value > 0 ? value : defaultValue;
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
}
