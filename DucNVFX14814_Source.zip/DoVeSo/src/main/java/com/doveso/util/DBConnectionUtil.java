package com.doveso.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Lop tien ich phu trach viec tao va dong ket noi den co so du lieu MySQL.
 * Thong tin ket noi duoc doc tu tap tin classpath: db.properties
 * (src/main/resources/db.properties).
 *
 * Quy uoc: moi phuong thuc trong tang DAO can tu dong dong Connection,
 * Statement/PreparedStatement va ResultSet trong khoi finally hoac try-with-resources.
 */
public final class DBConnectionUtil {

    private static final String DRIVER;
    private static final String URL;
    private static final String USERNAME;
    private static final String PASSWORD;

    static {
        Properties props = new Properties();
        try (InputStream is = DBConnectionUtil.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            props.load(is);
            Class.forName(props.getProperty("db.driver"));
        } catch (Exception e) {
            throw new ExceptionInInitializerError("Khong the nap cau hinh/driver CSDL: " + e.getMessage());
        }
        DRIVER = props.getProperty("db.driver");
        URL = props.getProperty("db.url");
        USERNAME = props.getProperty("db.username");
        PASSWORD = props.getProperty("db.password");
    }

    private DBConnectionUtil() {
        // Khong cho phep khoi tao instance - chi su dung phuong thuc static
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
