package com.doveso.util;

/** Cai dat ResetMailSender bang MailUtil (Jakarta Mail, cau hinh trong mail.properties). */
public class MailUtilResetMailSender implements ResetMailSender {

    @Override
    public boolean isConfigured() {
        return MailUtil.isConfigured();
    }

    @Override
    public String getConfiguredBaseUrl() {
        return MailUtil.getConfiguredBaseUrl();
    }

    @Override
    public void sendResetPasswordMail(String toEmail, String fullName, String resetLink, int expireMinutes)
            throws Exception {
        MailUtil.sendResetPasswordMail(toEmail, fullName, resetLink, expireMinutes);
    }
}
