package com.doveso.util;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Lop tien ich ma hoa va kiem tra mat khau bang thuat toan bam mot chieu BCrypt.
 * Ap dung cho yeu cau "Mat khau nguoi dung phai duoc ma hoa truoc khi luu"
 * trong tai lieu HV_SRS - Chuong 2, muc Yeu cau phi chuc nang.
 */
public final class PasswordUtil {

    private PasswordUtil() {
    }

    /** Ma hoa mat khau dang plain-text truoc khi luu vao CSDL. */
    public static String hash(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(12));
    }

    /** So sanh mat khau nguoi dung nhap voi mat khau da ma hoa trong CSDL. */
    public static boolean verify(String plainPassword, String hashedPassword) {
        if (plainPassword == null || hashedPassword == null) {
            return false;
        }
        return BCrypt.checkpw(plainPassword, hashedPassword);
    }
}
