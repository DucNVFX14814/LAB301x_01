package com.doveso.util;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * Gui email (UC05: Quen mat khau) qua SMTP, cau hinh trong file mail.properties (classpath).
 * Mac dinh dung Gmail SMTP voi App Password.
 */
public final class MailUtil {

    private static final String CONFIG_FILE = "mail.properties";
    /** Gia tri mau trong mail.properties - chua duoc thay bang tai khoan that. */
    private static final String PLACEHOLDER_USERNAME = "your.email@gmail.com";

    /** Cache noi dung mail.properties (doc 1 lan dau tien, tranh doc lai file cho moi loi goi). */
    private static volatile Properties cachedConfig;

    private MailUtil() {
        // Chi dung phuong thuc static
    }

    /** Doc mail.properties bang UTF-8 (Properties.load(InputStream) mac dinh dung ISO-8859-1 se loi tieng Viet). */
    private static Properties loadConfig() {
        Properties cached = cachedConfig;
        if (cached != null) {
            return cached;
        }
        try (InputStream in = MailUtil.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (in == null) {
                throw new IllegalStateException("Khong tim thay file " + CONFIG_FILE + " trong classpath");
            }
            Properties props = new Properties();
            props.load(new InputStreamReader(in, StandardCharsets.UTF_8));
            cachedConfig = props;
            return props;
        } catch (IOException e) {
            throw new IllegalStateException("Khong doc duoc " + CONFIG_FILE + ": " + e.getMessage(), e);
        }
    }

    private static String value(Properties props, String key, String defaultValue) {
        String v = props.getProperty(key);
        return (v == null || v.trim().isEmpty()) ? defaultValue : v.trim();
    }

    /**
     * Dia chi goc cua ung dung (vd http://localhost:8080/doveso) dung de tao lien ket trong email,
     * doc tu khoa app.base.url trong mail.properties. Tra ve null neu de trong (khi do lay theo request).
     */
    public static String getConfiguredBaseUrl() {
        try {
            String url = value(loadConfig(), "app.base.url", null);
            if (url == null) {
                return null;
            }
            return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
        } catch (IllegalStateException e) {
            return null;
        }
    }

    /** Kiem tra da dien mail.username / mail.password that trong mail.properties hay chua. */
    public static boolean isConfigured() {
        try {
            Properties cfg = loadConfig();
            String user = value(cfg, "mail.username", "");
            String password = value(cfg, "mail.password", "");
            return !user.isEmpty() && !user.equalsIgnoreCase(PLACEHOLDER_USERNAME) && !password.isEmpty();
        } catch (IllegalStateException e) {
            return false;
        }
    }

    /**
     * Gui email huong dan dat lai mat khau.
     *
     * @throws IllegalStateException neu chua cau hinh mail.properties
     * @throws MessagingException    neu khong gui duoc email
     */
    public static void sendResetPasswordMail(String toEmail, String fullName, String resetLink, int expireMinutes)
            throws MessagingException {
        Properties cfg = loadConfig();
        final String user = value(cfg, "mail.username", "");
        final String password = value(cfg, "mail.password", "").replace(" ", "");
        if (user.isEmpty() || user.equalsIgnoreCase(PLACEHOLDER_USERNAME) || password.isEmpty()) {
            throw new IllegalStateException("Chua cau hinh mail.username / mail.password trong " + CONFIG_FILE);
        }
        String auth = value(cfg, "mail.smtp.auth", "true");

        Properties smtp = new Properties();
        smtp.put("mail.smtp.host", value(cfg, "mail.smtp.host", "smtp.gmail.com"));
        smtp.put("mail.smtp.port", value(cfg, "mail.smtp.port", "587"));
        smtp.put("mail.smtp.auth", auth);
        smtp.put("mail.smtp.starttls.enable", value(cfg, "mail.smtp.starttls.enable", "true"));
        smtp.put("mail.smtp.connectiontimeout", "10000");
        smtp.put("mail.smtp.timeout", "10000");
        smtp.put("mail.smtp.writetimeout", "10000");

        Session session = "true".equalsIgnoreCase(auth)
                ? Session.getInstance(smtp, new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(user, password);
                    }
                })
                : Session.getInstance(smtp);

        String subject = "Đặt lại mật khẩu - Dò Vé Số";
        MimeMessage msg = new MimeMessage(session);
        try {
            msg.setFrom(new InternetAddress(user, value(cfg, "mail.from.name", "Dò Vé Số"), "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new MessagingException("Khong ma hoa duoc ten nguoi gui", e);
        }
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));
        msg.setSubject(subject, "UTF-8");

        MimeBodyPart textPart = new MimeBodyPart();
        textPart.setText(buildText(fullName, resetLink, expireMinutes), "UTF-8");
        MimeBodyPart htmlPart = new MimeBodyPart();
        htmlPart.setContent(buildHtml(fullName, resetLink, expireMinutes), "text/html; charset=UTF-8");
        MimeMultipart body = new MimeMultipart("alternative"); // phan cuoi la phan uu tien hien thi
        body.addBodyPart(textPart);
        body.addBodyPart(htmlPart);
        msg.setContent(body);

        Transport.send(msg);
    }

    private static String buildText(String fullName, String link, int expireMinutes) {
        return "Xin chào " + fullName + ",\n\n"
                + "Chúng tôi nhận được yêu cầu đặt lại mật khẩu cho tài khoản của bạn tại Dò Vé Số.\n"
                + "Mở liên kết sau để đặt mật khẩu mới (hiệu lực " + expireMinutes + " phút, chỉ dùng được một lần):\n\n"
                + link + "\n\n"
                + "Nếu bạn không yêu cầu, hãy bỏ qua email này - mật khẩu của bạn sẽ không thay đổi.\n";
    }

    private static String buildHtml(String fullName, String link, int expireMinutes) {
        String safeName = escapeHtml(fullName);
        String safeLink = escapeHtml(link);
        return "<div style=\"font-family:'Segoe UI',Arial,sans-serif;max-width:520px;margin:0 auto;color:#333;line-height:1.5\">"
                + "<h2 style=\"color:#0d6efd;margin-bottom:8px\">Đặt lại mật khẩu</h2>"
                + "<p>Xin chào <strong>" + safeName + "</strong>,</p>"
                + "<p>Chúng tôi nhận được yêu cầu đặt lại mật khẩu cho tài khoản của bạn tại website Dò Vé Số. "
                + "Nhấn nút bên dưới để đặt mật khẩu mới. Liên kết có hiệu lực trong <strong>" + expireMinutes
                + " phút</strong> và chỉ dùng được một lần.</p>"
                + "<p style=\"text-align:center;margin:28px 0\">"
                + "<a href=\"" + safeLink + "\" style=\"background:#0d6efd;color:#fff;text-decoration:none;"
                + "padding:12px 24px;border-radius:6px;font-weight:600;display:inline-block\">Đặt lại mật khẩu</a></p>"
//                + "<p style=\"font-size:13px;color:#666\">Nếu nút không hoạt động, hãy sao chép liên kết sau vào trình duyệt:<br>"
//                + "<a href=\"" + safeLink + "\">" + safeLink + "</a></p>"
                + "<p style=\"font-size:13px;color:#666\">Nếu bạn không yêu cầu, hãy bỏ qua email này - "
                + "mật khẩu của bạn sẽ không thay đổi.</p>"
                + "</div>";
    }

    private static String escapeHtml(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
