package com.doveso.util;

/**
 * Cong gui email dat lai mat khau (UC05). Tach thanh interface de tang BO khong phu thuoc truc tiep vao SMTP:
 * khi chay that dung MailUtilResetMailSender, khi unit test dung mock.
 */
public interface ResetMailSender {

    /** true neu da cau hinh tai khoan gui mail (mail.username / mail.password). */
    boolean isConfigured();

    /** Dia chi goc cau hinh san (app.baseUrl), null neu khong cau hinh. */
    String getConfiguredBaseUrl();

    /** Gui email chua lien ket dat lai mat khau. Co the nem Exception khi khong gui duoc. */
    void sendResetPasswordMail(String toEmail, String fullName, String resetLink, int expireMinutes)
            throws Exception;
}
