package com.doveso.util;

import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryPrize;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Lay ket qua xo so kien thiet (mien Bac, Trung, Nam) theo ngay tu trang minhngoc.net.vn.
 * UC10: Them ve do moi (ADMIN) - buoc lay du lieu de xem truoc.
 *
 * Nguon du lieu la trang HTML (khong co API JSON) nen dung Jsoup de phan tich.
 * Moi trang (mien + ngay) liet ke ngay duoc chon va vai ngay truoc do, vi vay phai chon
 * dung khoi (div.box_kqxs) co ngay khop voi ngay can lay.
 * - Mien Bac: 1 dai, bang table.bkqtinhmienbac, 8 giai (DB, G1..G7).
 * - Mien Trung / Nam: nhieu dai xo cung ngay, moi dai la 1 table.rightcl trong table.bkqmiennam, 9 giai (DB, G1..G8).
 *   Dai duoc nhan dien bang slug trong link (vd /xo-so-mien-trung/da-nang.html) hoac ten dai.
 */
public final class MinhNgocClient {

    private static final String BASE_URL = "https://www.minhngoc.net.vn/ket-qua-xo-so/";
    private static final DateTimeFormatter URL_DATE = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final DateTimeFormatter TITLE_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static final String REGION_BAC = "BAC";
    public static final String REGION_TRUNG = "TRUNG";
    public static final String REGION_NAM = "NAM";

    /** Dinh nghia 1 giai: ma giai, ten hien thi, class cua o (td) tren trang nguon, so luong so, so chu so moi so. */
    private record PrizeDef(String code, String name, String cssClass, int count, int digits) {
    }

    /** Co cau giai xo so mien Bac: DB, G1..G7. */
    private static final List<PrizeDef> PRIZE_DEFS_BAC = List.of(
            new PrizeDef("DB", "Đặc biệt", "giaidb", 1, 5),
            new PrizeDef("G1", "Giải nhất", "giai1", 1, 5),
            new PrizeDef("G2", "Giải nhì", "giai2", 2, 5),
            new PrizeDef("G3", "Giải ba", "giai3", 6, 5),
            new PrizeDef("G4", "Giải tư", "giai4", 4, 4),
            new PrizeDef("G5", "Giải năm", "giai5", 6, 4),
            new PrizeDef("G6", "Giải sáu", "giai6", 3, 3),
            new PrizeDef("G7", "Giải bảy", "giai7", 4, 2));

    /** Co cau giai xo so mien Trung / Nam: DB, G1..G8. */
    private static final List<PrizeDef> PRIZE_DEFS_TRUNG_NAM = List.of(
            new PrizeDef("DB", "Đặc biệt", "giaidb", 1, 6),
            new PrizeDef("G1", "Giải nhất", "giai1", 1, 5),
            new PrizeDef("G2", "Giải nhì", "giai2", 1, 5),
            new PrizeDef("G3", "Giải ba", "giai3", 2, 5),
            new PrizeDef("G4", "Giải tư", "giai4", 7, 5),
            new PrizeDef("G5", "Giải năm", "giai5", 1, 4),
            new PrizeDef("G6", "Giải sáu", "giai6", 3, 4),
            new PrizeDef("G7", "Giải bảy", "giai7", 1, 3),
            new PrizeDef("G8", "Giải tám", "giai8", 1, 2));

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private MinhNgocClient() {
        // Chi dung phuong thuc static
    }

    /**
     * Ket qua lay du lieu cua 1 mien trong 1 ngay.
     * prizes: ma dai -> danh sach giai (chi cac dai co trong danh sach cong ty duoc truyen vao).
     * errors: ma dai -> thong bao loi rieng cua dai do (du lieu chua day du / khong hop le).
     */
    public static final class RegionResult {
        private final Map<String, List<LotteryPrize>> prizes = new LinkedHashMap<>();
        private final Map<String, String> errors = new LinkedHashMap<>();

        public Map<String, List<LotteryPrize>> getPrizes() {
            return prizes;
        }

        public Map<String, String> getErrors() {
            return errors;
        }
    }

    /**
     * Tai trang ket qua cua mien regionCode (tinh tu ngay drawDate lui ve truoc) va tra ve ket qua cua
     * TAT CA cac ngay co tren trang (thuong 7 ngay lien tiep), moi ngay gom cac tinh co trong companies.
     *
     * @throws LotteryFetchException khi khong ket noi duoc hoac nguon tra ve loi
     */
    public static Map<LocalDate, RegionResult> fetchRegionPage(String regionCode, LocalDate drawDate,
                                                              List<LotteryCompany> companies)
            throws LotteryFetchException {
        String url = BASE_URL + regionPath(regionCode) + "/" + drawDate.format(URL_DATE) + ".html";
        return parseRegionPage(httpGet(url), regionCode, companies);
    }

    /**
     * Tai trang ket qua rieng cua 1 tinh (vd .../mien-trung/da-nang/23-09-2026.html): tra ve cac ky mo thuong
     * gan nhat tinh tu ngay drawDate (thuong 6 ky). Chi dung cho mien Trung / Nam; slug = company_code.
     */
    public static Map<LocalDate, RegionResult> fetchProvincePage(LotteryCompany company, LocalDate drawDate)
            throws LotteryFetchException {
        String url = BASE_URL + regionPath(company.getRegionCode()) + "/" + company.getCompanyCode() + "/"
                + drawDate.format(URL_DATE) + ".html";
        return parseProvincePage(httpGet(url), company);
    }

    private static String httpGet(String url) throws LotteryFetchException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(15))
                .header("User-Agent", "Mozilla/5.0 (compatible; DoVeSo-LAB301x/1.0)")
                .header("Accept-Language", "vi-VN,vi;q=0.9")
                .GET()
                .build();
        HttpResponse<String> response;
        try {
            response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new LotteryFetchException(
                    "Không kết nối được nguồn dữ liệu, vui lòng thử lại sau.", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new LotteryFetchException("Việc lấy dữ liệu bị gián đoạn, vui lòng thử lại.", e);
        }
        if (response.statusCode() != 200) {
            throw new LotteryFetchException("Nguồn dữ liệu trả về lỗi (mã " + response.statusCode()
                    + "), vui lòng thử lại sau.");
        }
        return response.body();
    }

    /**
     * Phan tich HTML trang ket qua cua 1 mien: moi khoi div.box_kqxs la 1 ngay.
     * Tach rieng (public) de co the viet unit test tren file HTML mau.
     */
    public static Map<LocalDate, RegionResult> parseRegionPage(String html, String regionCode,
                                                              List<LotteryCompany> companies) {
        Map<LocalDate, RegionResult> days = new LinkedHashMap<>();
        for (Element box : Jsoup.parse(html).select("div.box_kqxs")) {
            LocalDate date = boxDate(box);
            if (date == null) {
                continue;
            }
            String dateText = date.format(TITLE_DATE);
            try {
                days.put(date, REGION_BAC.equals(regionCode)
                        ? parseBac(box, dateText, companies)
                        : parseTrungNam(box, dateText, companies));
            } catch (LotteryFetchException e) {
                if (REGION_BAC.equals(regionCode) && !companies.isEmpty()) {
                    RegionResult failed = new RegionResult();
                    failed.errors.put(companies.get(0).getCompanyCode(), e.getMessage());
                    days.put(date, failed);
                }
                // mien Trung/Nam: khoi khong doc duoc thi bo qua ngay do (coi nhu nguon chua co ket qua)
            }
        }
        return days;
    }

    /** Phan tich HTML trang rieng cua 1 tinh: moi khoi div.box_kqxs la 1 ky mo thuong cua tinh do. */
    public static Map<LocalDate, RegionResult> parseProvincePage(String html, LotteryCompany company) {
        Map<LocalDate, RegionResult> days = new LinkedHashMap<>();
        for (Element box : Jsoup.parse(html).select("div.box_kqxs")) {
            LocalDate date = boxDate(box);
            Element table = box.selectFirst("table.bkqtinhmiennam");
            if (date == null || table == null) {
                continue;
            }
            RegionResult r = new RegionResult();
            try {
                r.prizes.put(company.getCompanyCode(),
                        readPrizes(table, PRIZE_DEFS_TRUNG_NAM, date.format(TITLE_DATE)));
            } catch (LotteryFetchException e) {
                r.errors.put(company.getCompanyCode(), e.getMessage());
            }
            days.put(date, r);
        }
        return days;
    }

    /** Ngay cua 1 khoi ket qua (link cuoi cung trong tieu de, dang dd/MM/yyyy), null neu khong doc duoc. */
    private static LocalDate boxDate(Element box) {
        Element dateLink = box.select("div.title a").last();
        if (dateLink == null) {
            return null;
        }
        try {
            return LocalDate.parse(dateLink.text().trim(), TITLE_DATE);
        } catch (java.time.format.DateTimeParseException e) {
            return null;
        }
    }

    /** Mien Bac chi co 1 dai: gan ket qua cho cong ty dau tien cua danh sach (mien-bac). */
    private static RegionResult parseBac(Element box, String dateText, List<LotteryCompany> companies)
            throws LotteryFetchException {
        Element table = box.selectFirst("table.bkqtinhmienbac");
        if (table == null) {
            throw new LotteryFetchException("Không đọc được bảng kết quả ngày " + dateText
                    + " (nguồn dữ liệu có thể đã đổi cấu trúc trang).");
        }
        List<LotteryPrize> prizes = readPrizes(table, PRIZE_DEFS_BAC, dateText);
        RegionResult result = new RegionResult();
        if (!companies.isEmpty()) {
            result.prizes.put(companies.get(0).getCompanyCode(), prizes);
        }
        return result;
    }

    /** Mien Trung / Nam: moi tinh la 1 table.rightcl, chi lay cac tinh co trong danh sach cong ty. */
    private static RegionResult parseTrungNam(Element box, String dateText, List<LotteryCompany> companies)
            throws LotteryFetchException {
        Element main = box.selectFirst("table.bkqmiennam");
        if (main == null) {
            throw new LotteryFetchException("Không đọc được bảng kết quả ngày " + dateText
                    + " (nguồn dữ liệu có thể đã đổi cấu trúc trang).");
        }
        RegionResult result = new RegionResult();
        for (Element table : main.select("table.rightcl")) {
            Element link = table.selectFirst("td.tinh a");
            if (link == null) {
                continue;
            }
            LotteryCompany company = matchCompany(companies, slugOf(link.attr("href")), link.text());
            if (company == null) {
                continue; // tinh xo hom nay nhung khong co trong danh sach cong ty cua he thong
            }
            try {
                result.prizes.put(company.getCompanyCode(), readPrizes(table, PRIZE_DEFS_TRUNG_NAM, dateText));
            } catch (LotteryFetchException e) {
                result.errors.put(company.getCompanyCode(), e.getMessage());
            }
        }
        return result;
    }

    private static List<LotteryPrize> readPrizes(Element table, List<PrizeDef> defs, String dateText)
            throws LotteryFetchException {
        List<LotteryPrize> prizes = new ArrayList<>();
        for (PrizeDef def : defs) {
            Elements cells = table.select("td." + def.cssClass() + " div");
            List<String> numbers = new ArrayList<>();
            for (Element cell : cells) {
                numbers.add(cell.text().trim());
            }
            validate(def, numbers, dateText);
            prizes.add(new LotteryPrize(def.code(), def.name(), String.join("-", numbers)));
        }
        return prizes;
    }

    /** Kiem tra so luong so va so chu so cua tung giai (tranh luu du lieu thieu khi dang quay so). */
    private static void validate(PrizeDef def, List<String> numbers, String dateText)
            throws LotteryFetchException {
        if (numbers.size() != def.count()) {
            throw new LotteryFetchException("Kết quả ngày " + dateText + " chưa đầy đủ ở " + def.name().toLowerCase()
                    + " (cần " + def.count() + " số, nguồn có " + numbers.size()
                    + " số). Vui lòng thử lại sau khi nguồn cập nhật xong.");
        }
        String pattern = "\\d{" + def.digits() + "}";
        for (String n : numbers) {
            if (!n.matches(pattern)) {
                throw new LotteryFetchException("Kết quả ngày " + dateText + " có số không hợp lệ ở "
                        + def.name().toLowerCase() + ": \"" + n + "\".");
            }
        }
    }

    /** Doi chieu dai tren trang nguon voi cong ty trong he thong: theo slug link hoac theo ten (khong dau, khong ky tu la). */
    private static LotteryCompany matchCompany(List<LotteryCompany> companies, String slug, String name) {
        String slugKey = normalize(slug);
        String nameKey = normalize(name);
        for (LotteryCompany c : companies) {
            if ((!slugKey.isEmpty() && slugKey.equals(normalize(c.getCompanyCode())))
                    || (!nameKey.isEmpty() && nameKey.equals(normalize(c.getCompanyName())))) {
                return c;
            }
        }
        return null;
    }

    /** "/xo-so-mien-trung/da-nang.html" -> "da-nang". */
    private static String slugOf(String href) {
        String s = href == null ? "" : href;
        int slash = s.lastIndexOf('/');
        if (slash >= 0) {
            s = s.substring(slash + 1);
        }
        return s.endsWith(".html") ? s.substring(0, s.length() - 5) : s;
    }

    /** Bo dau tieng Viet, chuyen chu thuong va chi giu chu/so ("TP. HCM" -> "tphcm"). */
    static String normalize(String s) {
        if (s == null) {
            return "";
        }
        String d = Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replace('đ', 'd').replace('Đ', 'D');
        return d.toLowerCase().replaceAll("[^a-z0-9]", "");
    }

    private static String regionPath(String regionCode) throws LotteryFetchException {
        return switch (regionCode == null ? "" : regionCode) {
            case REGION_BAC -> "mien-bac";
            case REGION_TRUNG -> "mien-trung";
            case REGION_NAM -> "mien-nam";
            default -> throw new LotteryFetchException("Miền không hợp lệ: " + regionCode);
        };
    }

    public static String regionLabel(String regionCode) {
        return switch (regionCode) {
            case REGION_BAC -> "miền Bắc";
            case REGION_TRUNG -> "miền Trung";
            case REGION_NAM -> "miền Nam";
            default -> regionCode;
        };
    }
}
