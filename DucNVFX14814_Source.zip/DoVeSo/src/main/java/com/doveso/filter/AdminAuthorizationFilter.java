package com.doveso.filter;

import com.doveso.model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Filter kiem soat truy cap cac chuc nang danh cho Actor = ADMIN
 * (Quan ly nguoi dung, Quan ly ve do).
 */
@WebFilter("/admin/*")
public class AdminAuthorizationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        HttpSession session = req.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser != null && "ADMIN".equals(currentUser.getRole())) {
            chain.doFilter(request, response);
        } else if (currentUser == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
        } else {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Ban khong co quyen truy cap chuc nang nay.");
        }
    }
}
