package com.doveso.filter;

import com.doveso.model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * [CN3] Filter chan ADMIN su dung chuc nang Thuc hien do ve so (theo SRS: Admin khong ho tro).
 * Ap dung cho /check-ticket (do ve), /user/history (lich su do ve) va /user/number-suggestion (goi y so).
 * ADMIN truy cap se bi chuyen im lang ve man hinh mac dinh cua admin (/admin/users), khong bao loi.
 * NO_USER va USER di qua binh thuong.
 *
 * Muon mo lai cho ADMIN: dat ADMIN_CHECK_ENABLED = true (va bo comment link tren sidebar admin-header.jsp).
 */
// dispatcherTypes gom ca FORWARD vi index.jsp (trang goc "/") dung jsp:forward sang /check-ticket
@WebFilter(urlPatterns = {"/check-ticket", "/user/history", "/user/number-suggestion"},
        dispatcherTypes = {DispatcherType.REQUEST, DispatcherType.FORWARD})
public class AdminCheckTicketBlockFilter implements Filter {

    private static final boolean ADMIN_CHECK_ENABLED = false;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        HttpSession session = req.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;
        boolean isAdmin = currentUser != null && "ADMIN".equals(currentUser.getRole());

        if (isAdmin && !ADMIN_CHECK_ENABLED) {
            // Chuyen im lang ve man hinh mac dinh cua admin (khong thong bao).
            // Truoc day: session.setAttribute("flashError", "Tài khoản ADMIN không được sử dụng chức năng dò vé số.");
            //            resp.sendRedirect(req.getContextPath() + "/admin/tickets");
            resp.sendRedirect(req.getContextPath() + "/admin/users");
            return;
        }
        chain.doFilter(request, response);
    }
}
