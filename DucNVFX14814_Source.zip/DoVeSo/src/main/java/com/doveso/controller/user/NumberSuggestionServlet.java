package com.doveso.controller.user;

import com.doveso.bo.NumberSuggestionBO;
import com.doveso.bo.NumberSuggestionBOImpl;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Chuc nang 4 (*): Phan tich va de xuat so ve so nen mua.
 * Thong ke tan suat xuat hien 2 chu so cuoi tren cac ve do da PUBLISH CUA 1 CONG TY XO SO (bat buoc chon),
 * chi mang tinh tham khao.
 * GET /user/number-suggestion            -> chi hien thi form chon mien/tinh, chua co ket qua
 * GET /user/number-suggestion?company=.. -> hien thi ket qua thong ke cho tinh da chon
 * Chi danh cho USER da dang nhap (kiem soat boi AuthenticationFilter cho /user/*).
 */
@WebServlet("/user/number-suggestion")
public class NumberSuggestionServlet extends HttpServlet {

    private final NumberSuggestionBO suggestionBO = NumberSuggestionBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("regions", suggestionBO.getRegions());
        req.setAttribute("companies", suggestionBO.getCompanies());

        String companyCode = ValidationUtil.trimToEmpty(req.getParameter("company"));
        req.setAttribute("selCompany", companyCode);

        NumberSuggestionBO.Suggestion suggestion = suggestionBO.suggest(companyCode);
        if (suggestion.getError() != null) {
            req.setAttribute("error", suggestion.getError());
        } else if (suggestion.getCompany() != null) {
            req.setAttribute("selRegion", suggestion.getCompany().getRegionCode());
            req.setAttribute("selCompanyName", suggestion.getCompany().getCompanyName());
            req.setAttribute("result", suggestion.getResult());
        }
        req.getRequestDispatcher("/WEB-INF/views/user/number-suggestion.jsp").forward(req, resp);
    }

}
