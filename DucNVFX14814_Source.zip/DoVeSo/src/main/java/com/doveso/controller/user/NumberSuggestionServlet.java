package com.doveso.controller.user;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.NumberStatDAO;
import com.doveso.dao.impl.CompanyDAOImpl;
import com.doveso.dao.impl.NumberStatDAOImpl;
import com.doveso.model.LotteryCompany;
import com.doveso.model.PrizeDrawRow;
import com.doveso.util.NumberSuggestionUtil;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Chuc nang 4 (*): Phan tich va de xuat so ve so nen mua.
 * Thong ke tan suat xuat hien 2 chu so cuoi tren cac ve do da PUBLISH CUA 1 CONG TY XO SO (bat buoc chon),
 * chi mang tinh tham khao.
 * GET /user/number-suggestion            -> chi hien thi form chon mien/tinh, chua co ket qua
 * GET /user/number-suggestion?company=.. -> hien thi ket qua thong ke cho tinh da chon
 * Chi danh cho USER da dang nhap (kiem soat boi AuthenticationFilter cho /user/*).
 */
@WebServlet("/user/number-suggestion")
public class NumberSuggestionServlet extends HttpServlet {

    private static final int TOP_N = 10;

    private final NumberStatDAO statDAO = new NumberStatDAOImpl();
    private final CompanyDAO companyDAO = new CompanyDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("regions", companyDAO.findAllRegions());
        req.setAttribute("companies", companyDAO.findActiveCompanies());

        String companyCode = ValidationUtil.trimToEmpty(req.getParameter("company"));
        req.setAttribute("selCompany", companyCode);

        if (!companyCode.isEmpty()) {
            LotteryCompany company = companyDAO.findByCode(companyCode);
            if (company == null || !company.isActive()) {
                req.setAttribute("error", "Vui lòng chọn tỉnh xổ số hợp lệ.");
            } else {
                req.setAttribute("selRegion", company.getRegionCode());
                req.setAttribute("selCompanyName", company.getCompanyName());
                List<PrizeDrawRow> rows = statDAO.findAllPublishedPrizeNumbers(companyCode);
                req.setAttribute("result", NumberSuggestionUtil.analyze(rows, TOP_N));
            }
        }
        req.getRequestDispatcher("/WEB-INF/views/user/number-suggestion.jsp").forward(req, resp);
    }

}
