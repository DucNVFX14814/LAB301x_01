package com.doveso.controller.admin;

import com.doveso.bo.TicketBO;
import com.doveso.bo.TicketBOImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.regex.Pattern;

/**
 * UC12: Publish ve do (UNPUBLISH -> PUBLISH). Ve do da PUBLISH khong duoc chuyen nguoc lai.
 * POST /admin/tickets/publish  (id, from = list | detail, query = query string cua trang danh sach)
 */
@WebServlet("/admin/tickets/publish")
public class TicketPublishServlet extends HttpServlet {

    /** Chi cho phep ky tu an toan trong query string quay lai trang danh sach. */
    private static final Pattern SAFE_QUERY = Pattern.compile("[A-Za-z0-9_=&%.\\-]*");

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        Long id = parseId(req.getParameter("id"));

        TicketBO.PublishResult result = TicketBOImpl.newDefault().publish(id);
        if (result.getSuccess() != null) {
            session.setAttribute("flashSuccess", result.getSuccess());
        }
        if (result.getError() != null) {
            session.setAttribute("flashError", result.getError());
        }

        String base = req.getContextPath() + "/admin/tickets";
        if (result.isTicketFound() && "detail".equals(req.getParameter("from"))) {
            resp.sendRedirect(base + "/detail?id=" + id);
            return;
        }
        String query = req.getParameter("query");
        if (query != null && !query.isEmpty() && SAFE_QUERY.matcher(query).matches()) {
            resp.sendRedirect(base + "?" + query);
        } else {
            resp.sendRedirect(base);
        }
    }

    private static Long parseId(String s) {
        try {
            return Long.valueOf(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
