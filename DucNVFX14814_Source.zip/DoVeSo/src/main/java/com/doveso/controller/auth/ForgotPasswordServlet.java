package com.doveso.controller.auth;

import com.doveso.bo.BoResult;
import com.doveso.bo.PasswordResetBO;
import com.doveso.bo.PasswordResetBOImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * UC05: Quen mat khau (buoc 1-3): nhap email -> tao token -> gui email chua lien ket dat lai mat khau.
 * GET  /forgot-password : hien thi form nhap email
 * POST /forgot-password : goi PasswordResetBO kiem tra email, luu token (da bam) va gui email
 */
@WebServlet("/forgot-password")
public class ForgotPasswordServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/auth/forgot-password.jsp";

    private final PasswordResetBO resetBO = PasswordResetBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email") == null ? "" : req.getParameter("email").trim();
        req.setAttribute("email", email);

        BoResult<Void> result = resetBO.requestReset(email, buildBaseUrl(req));
        if (!result.isOk()) {
            req.setAttribute("error", result.getError());
            req.getRequestDispatcher(VIEW).forward(req, resp);
            return;
        }

        // Luon tra ve cung 1 thong bao, bat ke email co ton tai/dang hoat dong hay khong.
        req.setAttribute("message", PasswordResetBO.GENERIC_MESSAGE);
        req.setAttribute("email", "");
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    /**
     * Dia chi goc theo request, vd http://localhost:8080/doveso (bo cong neu la cong mac dinh).
     */
    private static String buildBaseUrl(HttpServletRequest req) {
        String scheme = req.getScheme();
        int port = req.getServerPort();
        boolean defaultPort = ("http".equals(scheme) && port == 80) || ("https".equals(scheme) && port == 443);
        return scheme + "://" + req.getServerName() + (defaultPort ? "" : ":" + port) + req.getContextPath();
    }
}
