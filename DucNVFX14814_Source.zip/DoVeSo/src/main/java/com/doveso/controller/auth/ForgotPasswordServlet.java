package com.doveso.controller.auth;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;
import com.doveso.util.MailUtil;
import com.doveso.util.ResetTokenUtil;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

/**
 * UC05: Quen mat khau (buoc 1-3): nhap email -> tao token -> gui email chua lien ket dat lai mat khau.
 * GET  /forgot-password : hien thi form nhap email
 * POST /forgot-password : kiem tra email, luu token (da bam) va gui email
 */
@WebServlet("/forgot-password")
public class ForgotPasswordServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/auth/forgot-password.jsp";

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    /**
     * Thong bao chung, giong het nhau du email co ton tai/dang hoat dong hay khong, de tranh lo thong tin
     * ve viec 1 email co dang ky trong he thong hay khong (user enumeration). Chi log() ghi lai ly do
     * that (khong tim thay email, tai khoan bi khoa, chua cau hinh mail...) o phia server.
     */
    private static final String GENERIC_MESSAGE = "Nếu email tồn tại trong hệ thống, chúng tôi đã gửi hướng dẫn "
            + "đặt lại mật khẩu tới hộp thư của bạn (kiểm tra cả thư rác). Liên kết có hiệu lực "
            + ResetTokenUtil.EXPIRE_MINUTES + " phút.";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email") == null ? "" : req.getParameter("email").trim();
        req.setAttribute("email", email);

        if (ValidationUtil.isBlank(email) || !ValidationUtil.isValidEmail(email)) {
            fail(req, resp, "Email không hợp lệ.");
            return;
        }

        User user = userDAO.findByEmail(email);
        if (user == null) {
            log("Yeu cau quen mat khau voi email khong ton tai: " + email);
        } else if (!user.isActive()) {
            log("Yeu cau quen mat khau cho tai khoan da bi khoa, userId=" + user.getId());
        } else if (!MailUtil.isConfigured()) {
            log("Chua cau hinh mail.username / mail.password trong mail.properties");
        } else {
            try {
                sendResetEmail(req, user);
            } catch (RuntimeException e) {
                log("Loi xu ly yeu cau quen mat khau cho userId=" + user.getId(), e);
            }
        }

        // Luon tra ve cung 1 thong bao, bat ke email co ton tai/dang hoat dong hay khong.
        req.setAttribute("message", GENERIC_MESSAGE);
        req.setAttribute("email", "");
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    /** Tao token, luu (da bam) va gui email dat lai mat khau cho user o luong nen. */
    private void sendResetEmail(HttpServletRequest req, User user) {
        String token = ResetTokenUtil.generateToken();
        LocalDateTime expireAt = LocalDateTime.now().plusMinutes(ResetTokenUtil.EXPIRE_MINUTES);
        // CSDL chi luu ban bam cua token; token goc chi nam trong lien ket gui qua email
        userDAO.saveResetToken(user.getId(), ResetTokenUtil.hash(token), expireAt);

        String baseUrl = MailUtil.getConfiguredBaseUrl();
        if (baseUrl == null) {
            baseUrl = buildBaseUrl(req);
        }
        final String link = baseUrl + "/reset-password?token=" + token;
        final String toEmail = user.getEmail();
        final String fullName = user.getFullName();
        final Long userId = user.getId();

        // Gui email o luong nen: ket noi SMTP co the mat tu vai giay den vai chuc giay,
        // khong bat nguoi dung cho. Loi gui (sai App Password, mat mang...) duoc ghi vao log Tomcat.
        CompletableFuture.runAsync(() -> {
            try {
                MailUtil.sendResetPasswordMail(toEmail, fullName, link, ResetTokenUtil.EXPIRE_MINUTES);
            } catch (Exception e) {
                log("Loi gui email dat lai mat khau cho userId=" + userId, e);
            }
        });
    }

    private void fail(HttpServletRequest req, HttpServletResponse resp, String error)
            throws ServletException, IOException {
        req.setAttribute("error", error);
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    /**
     * Dia chi goc theo request, vd http://localhost:8080/doveso (bo cong neu la cong mac dinh).
     */
    private static String buildBaseUrl(HttpServletRequest req) {
        String scheme = req.getScheme();
        int port = req.getServerPort();
        boolean defaultPort = ("http".equals(scheme) && port == 80) || ("https".equals(scheme) && port == 443);
        return scheme + "://" + req.getServerName() + (defaultPort ? "" : ":" + port) + req.getContextPath();
    }
}
