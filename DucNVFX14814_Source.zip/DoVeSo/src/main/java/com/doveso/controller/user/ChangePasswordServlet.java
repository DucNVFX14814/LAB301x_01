package com.doveso.controller.user;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;
import com.doveso.util.PasswordUtil;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * UC04: Doi mat khau (USER/ADMIN da dang nhap - kiem soat boi AuthenticationFilter cho /user/*).
 * GET  /user/change-password : hien thi form
 * POST /user/change-password : kiem tra mat khau hien tai, luu mat khau moi (da ma hoa)
 */
@WebServlet("/user/change-password")
public class ChangePasswordServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/user/change-password.jsp";

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User sessionUser = (User) req.getSession().getAttribute("currentUser");
        // Doc lai tu CSDL de lay ma bam mat khau moi nhat (session co the cu)
        User user = userDAO.findById(sessionUser.getId());

        String current = req.getParameter("currentPassword");
        String newPassword = req.getParameter("newPassword");
        String confirm = req.getParameter("confirmPassword");

        String error = null;
        if (ValidationUtil.isBlank(current)) {
            error = "Vui lòng nhập mật khẩu hiện tại.";
        } else if (user == null || !PasswordUtil.verify(current, user.getPasswordHash())) {
            error = "Mật khẩu hiện tại không đúng";
        } else if (!ValidationUtil.isValidPassword(newPassword)) {
            error = "Mật khẩu mới phải có ít nhất 6 ký tự.";
        } else if (!newPassword.equals(confirm)) {
            error = "Mật khẩu xác nhận không khớp.";
        } else if (newPassword.equals(current)) {
            error = "Mật khẩu mới phải khác mật khẩu hiện tại.";
        }

        if (error != null) {
            req.setAttribute("error", error);
        } else {
            userDAO.updatePassword(user.getId(), PasswordUtil.hash(newPassword));
            req.setAttribute("message", "Đổi mật khẩu thành công");
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
