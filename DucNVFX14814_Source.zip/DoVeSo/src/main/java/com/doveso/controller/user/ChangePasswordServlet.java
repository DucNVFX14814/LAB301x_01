package com.doveso.controller.user;

import com.doveso.bo.BoResult;
import com.doveso.bo.UserBO;
import com.doveso.bo.UserBOImpl;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * UC04: Doi mat khau (USER/ADMIN da dang nhap - kiem soat boi AuthenticationFilter cho /user/*).
 * GET  /user/change-password : hien thi form
 * POST /user/change-password : goi UserBO kiem tra mat khau hien tai, luu mat khau moi (da ma hoa)
 */
@WebServlet("/user/change-password")
public class ChangePasswordServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/user/change-password.jsp";

    private final UserBO userBO = UserBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User sessionUser = (User) req.getSession().getAttribute("currentUser");

        BoResult<Void> result = userBO.changePassword(sessionUser.getId(),
                req.getParameter("currentPassword"),
                req.getParameter("newPassword"),
                req.getParameter("confirmPassword"));

        if (!result.isOk()) {
            req.setAttribute("error", result.getError());
        } else {
            req.setAttribute("message", "Đổi mật khẩu thành công");
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
