package com.doveso.controller.admin;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Servlet xu ly UC06 (tim kiem) + UC09 (xem danh sach, phan trang > 20).
 * Chi ADMIN duoc truy cap (kiem soat boi AdminAuthorizationFilter).
 */
@WebServlet("/admin/users")
public class UserListServlet extends HttpServlet {

    private static final int PAGE_SIZE = 20;
    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String keyword = req.getParameter("keyword");
        int page = 1;
        try {
            page = Integer.parseInt(req.getParameter("page"));
        } catch (NumberFormatException ignored) {
            // giu gia tri mac dinh page = 1
        }

        String noLoginFor = req.getParameter("noLoginFor");   // rong = tat ca; 1d / 1w / 1m / 1q / 1y / never
        boolean neverLoggedIn = "never".equals(noLoginFor);            // "never" = chua tung dang nhap
        LocalDateTime lastLoginBefore = toLastLoginBefore(noLoginFor);  // "never" hoac ma la -> null

        List<User> users = userDAO.search(keyword, lastLoginBefore, neverLoggedIn, page, PAGE_SIZE);
        long total = userDAO.count(keyword, lastLoginBefore, neverLoggedIn);
        int totalPages = (int) Math.ceil((double) total / PAGE_SIZE);

        req.setAttribute("users", users);
        req.setAttribute("total", total);
        req.setAttribute("keyword", keyword);
        req.setAttribute("noLoginFor", (neverLoggedIn || lastLoginBefore != null) ? noLoginFor : "");
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", totalPages);
        req.setAttribute("error", req.getParameter("error"));
        req.getRequestDispatcher("/WEB-INF/views/admin/user-list.jsp").forward(req, resp);
    }

    /** Doi ma loc (1d, 1w, 1m, 1q, 1y) thanh moc thoi gian; tra ve null neu khong loc hoac ma khong hop le. */
    private static LocalDateTime toLastLoginBefore(String code) {
        if (code == null) {
            return null;
        }
        LocalDateTime now = LocalDateTime.now();
        return switch (code) {
            case "1d" -> now.minusDays(1);
            case "1w" -> now.minusWeeks(1);
            case "1m" -> now.minusMonths(1);
            case "1q" -> now.minusMonths(3);
            case "1y" -> now.minusYears(1);
            default -> null;
        };
    }
}