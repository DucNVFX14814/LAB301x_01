package com.doveso.controller.admin;

import com.doveso.bo.UserBO;
import com.doveso.bo.UserBOImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet xu ly UC06 (tim kiem) + UC09 (xem danh sach, phan trang > 20).
 * Chi ADMIN duoc truy cap (kiem soat boi AdminAuthorizationFilter).
 *
 * Su dung phan trang phia server (SQL LIMIT/OFFSET qua UserBO/UserDAO) thay vi DataTables phia client:
 * moi lan chi tai 1 trang (20 nguoi dung), phu hop khi so luong nguoi dung lon, va de ket hop voi form luu
 * hang loat ROLE/trang thai cung bo loc (tu khoa, thoi gian khong dang nhap).
 */
@WebServlet("/admin/users")
public class UserListServlet extends HttpServlet {

    private final UserBO userBO = UserBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String keyword = req.getParameter("keyword");
        int page = 1;
        try {
            page = Integer.parseInt(req.getParameter("page"));
        } catch (NumberFormatException ignored) {
            // giu gia tri mac dinh page = 1
        }

        // rong = tat ca; 1d / 1w / 1m / 1q / 1y / never
        UserBO.UserPage result = userBO.search(keyword, req.getParameter("noLoginFor"), page);

        req.setAttribute("users", result.getUsers());
        req.setAttribute("total", result.getTotal());
        req.setAttribute("keyword", keyword);
        req.setAttribute("noLoginFor", result.getNoLoginFor());
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", result.getTotalPages());
        req.setAttribute("error", req.getParameter("error"));
        req.getRequestDispatcher("/WEB-INF/views/admin/user-list.jsp").forward(req, resp);
    }
}
