package com.doveso.controller.admin;

import com.doveso.dao.LotteryPrizeDAO;
import com.doveso.dao.TicketDAO;
import com.doveso.dao.impl.LotteryPrizeDAOImpl;
import com.doveso.dao.impl.TicketDAOImpl;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryTicket;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Xem lai ve do (cac giai) va UC13: xem so lan ve do duoc dung de do.
 * GET /admin/tickets/detail?id=n
 */
@WebServlet("/admin/tickets/detail")
public class TicketDetailServlet extends HttpServlet {

    private final TicketDAO ticketDAO = new TicketDAOImpl();
    private final LotteryPrizeDAO prizeDAO = new LotteryPrizeDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        Long id = parseId(req.getParameter("id"));
        LotteryTicket ticket = (id == null) ? null : ticketDAO.findById(id);
        if (ticket == null) {
            session.setAttribute("flashError", "Không tìm thấy vé dò.");
            resp.sendRedirect(req.getContextPath() + "/admin/tickets");
            return;
        }

        List<LotteryPrize> prizes = prizeDAO.findByTicketId(id);
        List<String> order = Arrays.asList(LotteryPrize.PRIZE_ORDER);
        prizes.sort(Comparator.comparingInt(p -> order.indexOf(p.getPrizeCode())));

        req.setAttribute("ticket", ticket);
        req.setAttribute("prizes", prizes);
        req.setAttribute("drawTimes", ticketDAO.countDrawTimes(id));

        // Chuyen thong bao (flash) sang request de hien thi 1 lan
        Object success = session.getAttribute("flashSuccess");
        if (success != null) {
            req.setAttribute("success", success);
            session.removeAttribute("flashSuccess");
        }
        Object error = session.getAttribute("flashError");
        if (error != null) {
            req.setAttribute("error", error);
            session.removeAttribute("flashError");
        }
        req.getRequestDispatcher("/WEB-INF/views/admin/ticket-detail.jsp").forward(req, resp);
    }

    private static Long parseId(String s) {
        try {
            return Long.valueOf(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
