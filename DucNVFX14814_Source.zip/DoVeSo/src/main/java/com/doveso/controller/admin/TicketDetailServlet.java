package com.doveso.controller.admin;

import com.doveso.bo.TicketBO;
import com.doveso.bo.TicketBOImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Xem lai ve do (cac giai) va UC13: xem so lan ve do duoc dung de do.
 * GET /admin/tickets/detail?id=n
 */
@WebServlet("/admin/tickets/detail")
public class TicketDetailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        Long id = parseId(req.getParameter("id"));
        TicketBO.TicketDetail detail = TicketBOImpl.newDefault().getDetail(id);
        if (detail == null) {
            session.setAttribute("flashError", "Không tìm thấy vé dò.");
            resp.sendRedirect(req.getContextPath() + "/admin/tickets");
            return;
        }

        req.setAttribute("ticket", detail.getTicket());
        req.setAttribute("prizes", detail.getPrizes());
        req.setAttribute("drawTimes", detail.getDrawTimes());

        // Chuyen thong bao (flash) sang request de hien thi 1 lan
        AdminTicketSupport.moveFlashMessages(req);
        req.getRequestDispatcher("/WEB-INF/views/admin/ticket-detail.jsp").forward(req, resp);
    }

    private static Long parseId(String s) {
        try {
            return Long.valueOf(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
