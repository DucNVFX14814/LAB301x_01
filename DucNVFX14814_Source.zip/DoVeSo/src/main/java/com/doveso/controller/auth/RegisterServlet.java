package com.doveso.controller.auth;

import com.doveso.bo.BoResult;
import com.doveso.bo.UserBO;
import com.doveso.bo.UserBOImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet xu ly UC01: Dang ky tai khoan.
 * GET  /register  -> hien thi form dang ky
 * POST /register  -> goi UserBO kiem tra va luu tai khoan moi voi ROLE = USER
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private static final String REGISTER_VIEW = "/WEB-INF/views/auth/register.jsp";

    private final UserBO userBO = UserBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(REGISTER_VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        BoResult<Void> result = userBO.register(
                req.getParameter("fullName"),
                req.getParameter("email"),
                req.getParameter("phone"),
                req.getParameter("password"),
                req.getParameter("confirmPassword"));

        if (!result.isOk()) {
            req.setAttribute("error", result.getError());
            req.getRequestDispatcher(REGISTER_VIEW).forward(req, resp);
            return;
        }

        req.setAttribute("message", "Đăng ký thành công! Vui lòng đăng nhập.");
        req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
    }
}
