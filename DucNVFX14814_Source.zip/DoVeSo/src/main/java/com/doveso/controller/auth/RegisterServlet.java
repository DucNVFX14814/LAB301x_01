package com.doveso.controller.auth;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;
import com.doveso.util.PasswordUtil;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet xu ly UC01: Dang ky tai khoan.
 * GET  /register  -> hien thi form dang ky
 * POST /register  -> xu ly dang ky, luu tai khoan moi voi ROLE = USER
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String fullName = req.getParameter("fullName");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");

        // Buoc 2 (UC01): kiem tra dinh dang du lieu dau vao - tra ve loi cu the theo tung truong
        String validationError = validate(fullName, email, phone, password, confirmPassword);
        if (validationError != null) {
            req.setAttribute("error", validationError);
            req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp);
            return;
        }

        // Buoc 3a (UC01): email da ton tai
        if (userDAO.existsByEmail(email)) {
            req.setAttribute("error", "Email đã được sử dụng.");
            req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp);
            return;
        }

        // Buoc 3b (UC01): so dien thoai da ton tai (tranh SQLIntegrityConstraintViolationException)
        if (userDAO.existsByPhone(phone)) {
            req.setAttribute("error", "Số điện thoại đã được sử dụng.");
            req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp);
            return;
        }

        User newUser = new User(fullName.trim(), email.trim(), phone.trim(), PasswordUtil.hash(password));
        try {
            userDAO.insert(newUser);
        } catch (RuntimeException e) {
            // Phong truong hop 2 nguoi dang ky trung email/sdt cung luc (vuot qua duoc buoc kiem tra
            // existsBy... o tren nhung insert vao CSDL lai dung luc nhau) - tranh loi 500.
            req.setAttribute("error", "Email hoặc số điện thoại đã được sử dụng. Vui lòng kiểm tra lại.");
            req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp);
            return;
        }

        req.setAttribute("message", "Đăng ký thành công! Vui lòng đăng nhập.");
        req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
    }

    /** Kiem tra tung truong va tra ve thong bao loi dau tien gap phai, null neu hop le. */
    private String validate(String fullName, String email, String phone, String password, String confirmPassword) {
        if (!ValidationUtil.isValidFullName(fullName)) {
            return "Họ và tên không hợp lệ (2-150 ký tự, chỉ gồm chữ cái và khoảng trắng).";
        }
        if (!ValidationUtil.isValidEmail(email)) {
            return "Email không đúng định dạng.";
        }
        if (!ValidationUtil.isValidPhone(phone)) {
            return "Số điện thoại phải bắt đầu bằng số 0 và có đúng 10 chữ số.";
        }
        if (!ValidationUtil.isValidPassword(password)) {
            return "Mật khẩu phải có ít nhất 6 ký tự.";
        }
        if (!password.equals(confirmPassword)) {
            return "Mật khẩu xác nhận không khớp.";
        }
        return null;
    }
}