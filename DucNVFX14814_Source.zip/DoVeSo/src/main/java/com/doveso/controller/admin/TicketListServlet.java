package com.doveso.controller.admin;

import com.doveso.bo.TicketBO;
import com.doveso.bo.TicketBOImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * UC11: Tim kiem ve do (theo mien, dai, khoang ngay), UC02 phan trang toi da 10 ve/trang.
 * GET /admin/tickets?region=&company=&fromDate=yyyy-MM-dd&toDate=yyyy-MM-dd&page=n
 * region / company rong = tat ca.
 *
 * Su dung phan trang phia server (SQL LIMIT/OFFSET qua TicketBO/TicketDAO) thay vi DataTables phia client:
 * dung yeu cau "moi trang toi da 10 ve do", chi tai du lieu cua trang dang xem, va ket hop truc tiep voi bo loc
 * mien / dai / trang thai / khoang ngay.
 */
@WebServlet("/admin/tickets")
public class TicketListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        AdminTicketSupport.moveFlashMessages(req);
        TicketBO bo = TicketBOImpl.newDefault();

        TicketBO.TicketSearchResult result = bo.search(req.getParameter("region"), req.getParameter("company"),
                req.getParameter("status"), req.getParameter("fromDate"), req.getParameter("toDate"),
                req.getParameter("page"));

        AdminTicketSupport.putFilterData(req, bo, result.getRegion(), result.getCompany(), true, "");
        req.setAttribute("selStatus", result.getStatus());
        req.setAttribute("tickets", result.getTickets());
        req.setAttribute("total", result.getTotal());
        req.setAttribute("fromDate", result.getFromDate());
        req.setAttribute("toDate", result.getToDate());
        req.setAttribute("currentPage", result.getPage());
        req.setAttribute("totalPages", result.getTotalPages());
        if (result.getError() != null) {
            req.setAttribute("error", result.getError());
            req.setAttribute("filterInvalid", true);
        }
        req.getRequestDispatcher("/WEB-INF/views/admin/ticket-list.jsp").forward(req, resp);
    }
}
