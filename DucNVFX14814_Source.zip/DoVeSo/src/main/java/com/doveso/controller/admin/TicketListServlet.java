package com.doveso.controller.admin;

import com.doveso.dao.TicketDAO;
import com.doveso.dao.impl.TicketDAOImpl;
import com.doveso.model.LotteryTicket;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static com.doveso.controller.admin.AdminTicketSupport.*;

/**
 * UC11: Tim kiem ve do (theo mien, dai, khoang ngay), UC02 phan trang toi da 10 ve/trang.
 * GET /admin/tickets?region=&company=&fromDate=yyyy-MM-dd&toDate=yyyy-MM-dd&page=n
 * region / company rong = tat ca.
 */
@WebServlet("/admin/tickets")
public class TicketListServlet extends HttpServlet {

    private static final int PAGE_SIZE = 10;
    private static final LocalDate MIN_DATE = LocalDate.of(2000, 1, 1);
    private static final LocalDate MAX_DATE = LocalDate.of(9999, 12, 31);

    private final TicketDAO ticketDAO = new TicketDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        moveFlashMessages(req);
        AdminTicketSupport support = new AdminTicketSupport();

        String region = trim(req.getParameter("region"));
        String company = trim(req.getParameter("company"));
        String status = trim(req.getParameter("status"));
        String fromParam = trim(req.getParameter("fromDate"));
        String toParam = trim(req.getParameter("toDate"));
        boolean firstVisit = req.getParameter("region") == null && req.getParameter("company") == null
                && fromParam.isEmpty() && toParam.isEmpty();
        if (fromParam.isEmpty() && toParam.isEmpty()) {
            LocalDate today = LocalDate.now();
            fromParam = today.withDayOfMonth(1).toString();
            toParam = today.toString();
        }
        if (firstVisit) {
            region = "";
            company = "";
        }

        LocalDate from = parseDate(fromParam);
        LocalDate to = parseDate(toParam);
        String error = null;
        if ((!fromParam.isEmpty() && from == null) || (!toParam.isEmpty() && to == null)) {
            error = "Ngày tìm kiếm không hợp lệ.";
        } else if (from != null && to != null && from.isAfter(to)) {
            error = "Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.";
        } else if (!region.isEmpty() && !support.isValidRegion(region)) {
            error = "Miền không hợp lệ.";
        } else if (!company.isEmpty() && support.findCompany(company) == null) {
            error = "Tỉnh không hợp lệ.";
        } else if (!status.isEmpty() && !LotteryTicket.STATUS_PUBLISH.equals(status)
                && !LotteryTicket.STATUS_UNPUBLISH.equals(status)) {
            error = "Trạng thái không hợp lệ.";
        }

        List<LotteryTicket> tickets = new ArrayList<>();
        long total = 0;
        int totalPages = 0;
        int page = 1;
        if (error == null) {
            LocalDate searchFrom = (from != null) ? from : MIN_DATE;
            LocalDate searchTo = (to != null) ? to : MAX_DATE;
            total = ticketDAO.count(region, company, searchFrom, searchTo, status);
            totalPages = (int) Math.ceil((double) total / PAGE_SIZE);
            page = parsePage(req.getParameter("page"));
            page = Math.min(Math.max(page, 1), Math.max(totalPages, 1));
            tickets = ticketDAO.search(region, company, searchFrom, searchTo, status, page, PAGE_SIZE);
        }

        support.putFilterData(req, region, company, true, "");
        req.setAttribute("selStatus", status);
        req.setAttribute("tickets", tickets);
        req.setAttribute("total", total);
        req.setAttribute("fromDate", fromParam);
        req.setAttribute("toDate", toParam);
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", totalPages);
        if (error != null) {
            req.setAttribute("error", error);
            req.setAttribute("filterInvalid", true);
        }
        req.getRequestDispatcher("/WEB-INF/views/admin/ticket-list.jsp").forward(req, resp);
    }

    /** Chuyen thong bao (flash) luu tam trong session sang request de hien thi 1 lan. */
    private static void moveFlashMessages(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session == null) {
            return;
        }
        Object success = session.getAttribute("flashSuccess");
        if (success != null) {
            req.setAttribute("success", success);
            session.removeAttribute("flashSuccess");
        }
        Object error = session.getAttribute("flashError");
        if (error != null) {
            req.setAttribute("error", error);
            session.removeAttribute("flashError");
        }
    }

    private static int parsePage(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 1;
        }
    }
}
