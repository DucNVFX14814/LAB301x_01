package com.doveso.controller.user;

import com.doveso.bo.UserHistoryBO;
import com.doveso.bo.UserHistoryBOImpl;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * UC16: Xem lich su do ve (USER da dang nhap - kiem soat boi AuthenticationFilter cho /user/*).
 * Sap xep theo thoi gian do giam dan, phan trang 10 dong/trang.
 * Co the loc them theo mien/cong ty xo so (tuy chon, khong bat buoc chon).
 * GET /user/history?page=n&region=..&company=..
 */
@WebServlet("/user/history")
public class UserHistoryServlet extends HttpServlet {

    private final UserHistoryBO historyBO = UserHistoryBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;
        // AuthenticationFilter da dam bao currentUser != null, kiem tra lai cho chac chan
        if (currentUser == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        UserHistoryBO.HistoryPage result = historyBO.getHistory(currentUser.getId(), req.getParameter("region"),
                req.getParameter("company"), req.getParameter("from"), req.getParameter("to"),
                req.getParameter("page"));

        req.setAttribute("regions", historyBO.getRegions());
        req.setAttribute("companies", historyBO.getCompanies());
        req.setAttribute("selRegion", result.getRegion());
        req.setAttribute("selCompany", result.getCompany());
        req.setAttribute("allowAllCompany", true);
        req.setAttribute("maxDate", result.getToday().toString());
        req.setAttribute("fromDate", result.getFromDate().toString());
        req.setAttribute("toDate", result.getToDate().toString());

        req.setAttribute("history", result.getHistory());
        req.setAttribute("total", result.getTotal());
        req.setAttribute("currentPage", result.getPage());
        req.setAttribute("totalPages", result.getTotalPages());
        req.getRequestDispatcher("/WEB-INF/views/user/history.jsp").forward(req, resp);
    }
}
