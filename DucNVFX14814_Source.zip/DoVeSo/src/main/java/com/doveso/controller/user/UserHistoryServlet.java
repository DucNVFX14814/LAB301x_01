package com.doveso.controller.user;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryHistoryDAO;
import com.doveso.dao.impl.CompanyDAOImpl;
import com.doveso.dao.impl.LotteryHistoryDAOImpl;
import com.doveso.model.LotteryHistory;
import com.doveso.model.User;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * UC16: Xem lich su do ve (USER da dang nhap - kiem soat boi AuthenticationFilter cho /user/*).
 * Sap xep theo thoi gian do giam dan, phan trang 10 dong/trang.
 * Co the loc them theo mien/cong ty xo so (tuy chon, khong bat buoc chon).
 * GET /user/history?page=n&region=..&company=..
 */
@WebServlet("/user/history")
public class UserHistoryServlet extends HttpServlet {

    private static final int PAGE_SIZE = 10;

    private final LotteryHistoryDAO historyDAO = new LotteryHistoryDAOImpl();
    private final CompanyDAO companyDAO = new CompanyDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;
        // AuthenticationFilter da dam bao currentUser != null, kiem tra lai cho chac chan
        if (currentUser == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        int page = 1;
        try {
            page = Integer.parseInt(req.getParameter("page"));
        } catch (NumberFormatException ignored) {
            // giu gia tri mac dinh page = 1
        }

        // Bo loc mien/cong ty: tuy chon, khong bat buoc chon (rong = xem tat ca).
        String region = ValidationUtil.trimToEmpty(req.getParameter("region"));
        String company = ValidationUtil.trimToEmpty(req.getParameter("company"));

        LocalDate today = LocalDate.now();
        LocalDate fromDate = parseDate(req.getParameter("from"), today.withDayOfMonth(1));
        LocalDate toDate = parseDate(req.getParameter("to"), today);
        if (toDate.isAfter(today)) {
            toDate = today;
        }
        if (fromDate.isAfter(toDate)) {
            fromDate = toDate;
        }

        req.setAttribute("regions", companyDAO.findAllRegions());
        req.setAttribute("companies", companyDAO.findActiveCompanies());
        req.setAttribute("selRegion", region);
        req.setAttribute("selCompany", company);
        req.setAttribute("allowAllCompany", true);
        req.setAttribute("maxDate", today.toString());
        req.setAttribute("fromDate", fromDate.toString());
        req.setAttribute("toDate", toDate.toString());

        long total = historyDAO.countByUserId(currentUser.getId(), region, company, fromDate, toDate);
        int totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        // Dua so trang ve khoang hop le (tranh trang rong khi ?page vuot qua so trang)
        page = Math.min(Math.max(page, 1), totalPages);

        List<LotteryHistory> history = historyDAO.findByUserId(currentUser.getId(), region, company,
                fromDate, toDate, page, PAGE_SIZE);

        req.setAttribute("history", history);
        req.setAttribute("total", total);
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", totalPages);
        req.getRequestDispatcher("/WEB-INF/views/user/history.jsp").forward(req, resp);
    }

    /** Parse ngay dang yyyy-MM-dd, tra ve gia tri mac dinh neu rong hoac khong hop le. */
    private static LocalDate parseDate(String value, LocalDate defaultValue) {
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        try {
            return LocalDate.parse(value.trim());
        } catch (DateTimeParseException e) {
            return defaultValue;
        }
    }
}
