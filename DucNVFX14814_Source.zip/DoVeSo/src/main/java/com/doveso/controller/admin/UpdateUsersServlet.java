package com.doveso.controller.admin;

import com.doveso.bo.BoResult;
import com.doveso.bo.UserBO;
import com.doveso.bo.UserBOImpl;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * Servlet xu ly luu hang loat thay doi ROLE + trang thai (active) cua nhieu
 * nguoi dung cung luc, thuc hien tu trang Quan ly nguoi dung (UC06/UC09).
 * Form gui len cac cap tham so role_{userId} va active_{userId} cho tung
 * dong dang hien thi tren trang.
 *
 * Servlet chi doc tham so request va chuyen huong; cac quy tac nghiep vu (khong khoa/ha quyen ADMIN,
 * khong doi ROLE khi tai khoan dang bi khoa, chi ADMIN chinh moi cap quyen ADMIN, huy toan bo neu vi pham)
 * nam o UserBO#updateRoleAndStatus.
 */
@WebServlet("/admin/users/update")
public class UpdateUsersServlet extends HttpServlet {

    private final UserBO userBO = UserBOImpl.newDefault();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<UserBO.RoleChange> pendingChanges = parsePendingChanges(req);
        User requester = (User) req.getSession().getAttribute("currentUser");

        BoResult<Void> result = userBO.updateRoleAndStatus(requester, pendingChanges);
        redirectBack(req, resp, result.isOk() ? null : result.getError());
    }

    private List<UserBO.RoleChange> parsePendingChanges(HttpServletRequest req) {
        List<UserBO.RoleChange> result = new ArrayList<>();
        Enumeration<String> paramNames = req.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String name = paramNames.nextElement();
            if (!name.startsWith("role_")) {
                continue;
            }
            String userIdStr = name.substring("role_".length());
            try {
                Long userId = Long.parseLong(userIdStr);
                String newRole = req.getParameter(name);
                boolean newActive = "true".equals(req.getParameter("active_" + userIdStr));
                result.add(new UserBO.RoleChange(userId, newRole, newActive));
            } catch (NumberFormatException ignored) {
                // Tham so khong dung dinh dang, bo qua dong nay
            }
        }
        return result;
    }

    private void redirectBack(HttpServletRequest req, HttpServletResponse resp, String errorMessage)
            throws IOException {
        String keyword = req.getParameter("keyword");
        String page = req.getParameter("page");
        StringBuilder redirectUrl = new StringBuilder(req.getContextPath()).append("/admin/users?");
        if (keyword != null && !keyword.isBlank()) {
            redirectUrl.append("keyword=").append(URLEncoder.encode(keyword, StandardCharsets.UTF_8)).append("&");
        }
        String noLoginFor = req.getParameter("noLoginFor");
        if (noLoginFor != null && !noLoginFor.isBlank()) {
            redirectUrl.append("noLoginFor=").append(URLEncoder.encode(noLoginFor, StandardCharsets.UTF_8)).append("&");
        }
        if (page != null && !page.isBlank()) {
            redirectUrl.append("page=").append(page).append("&");
        }
        if (errorMessage != null) {
            redirectUrl.append("error=").append(URLEncoder.encode(errorMessage, StandardCharsets.UTF_8));
        }
        resp.sendRedirect(redirectUrl.toString());
    }
}