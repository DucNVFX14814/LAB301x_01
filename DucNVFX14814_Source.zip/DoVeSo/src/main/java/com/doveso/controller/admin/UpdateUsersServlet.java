package com.doveso.controller.admin;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * Servlet xu ly luu hang loat thay doi ROLE + trang thai (active) cua nhieu
 * nguoi dung cung luc, thuc hien tu trang Quan ly nguoi dung (UC06/UC09).
 * Form gui len cac cap tham so role_{userId} va active_{userId} cho tung
 * dong dang hien thi tren trang.
 *
 * Business rule bo sung:
 * 1) KHONG cho phep khoa (active=false) hoac ha quyen (doi ROLE tu ADMIN
 *    sang USER) bat ky tai khoan ADMIN nao qua man hinh nay - bao gom ca
 *    truong hop admin tu thao tac len chinh tai khoan cua minh, de tranh
 *    tinh trang khong con ADMIN nao truy cap duoc he thong.
 * 2) Tai khoan DANG BI KHOA (active=false trong CSDL) thi chi duoc phep doi
 *    trang thai (mo khoa); KHONG duoc doi ROLE trong cung luc do - phai mo
 *    khoa truoc, sau do doi ROLE o mot lan luu khac.
 * 3) Chi ADMIN CHINH (id = MASTER_ADMIN_ID) moi duoc thang mot nguoi dung
 *    thanh ADMIN. ADMIN thuong khac khong duoc gan ROLE ADMIN cho bat ky ai.
 *
 * Ca 3 kiem tra deu doi chieu voi du lieu THUC TE trong CSDL (khong tin du
 * lieu client gui len, vi nguoi dung co the sua truc tiep gia tri select
 * bang DevTools), va deu theo nguyen tac: neu co BAT KY vi pham nao thi HUY
 * TOAN BO thao tac luu (khong ghi thay doi nao), bao loi ro rang cho admin.
 */
@WebServlet("/admin/users/update")
public class UpdateUsersServlet extends HttpServlet {

    /** Chi tai khoan ADMIN nay moi duoc thang cap nguoi khac len ADMIN. */
    private static final long MASTER_ADMIN_ID = 10000000L;

    private final UserDAO userDAO = new UserDAOImpl();

    /** 1 thay doi duoc yeu cau cho 1 dong (1 nguoi dung) tren form. */
    private static class PendingChange {
        Long userId;
        String newRole;
        boolean newActive;
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<PendingChange> pendingChanges = parsePendingChanges(req);
        User requester = (User) req.getSession().getAttribute("currentUser");
        boolean requesterIsMasterAdmin = requester != null && requester.getId() != null
                && requester.getId() == MASTER_ADMIN_ID;

        // Buoc 1: doi chieu voi du lieu THUC TE trong CSDL, gom danh sach vi pham theo tung loai (neu co)
        List<String> lockedOrDemotedAdminNames = new ArrayList<>();
        List<String> roleChangedWhileLockedNames = new ArrayList<>();
        List<String> unauthorizedPromoteNames = new ArrayList<>();
        for (PendingChange change : pendingChanges) {
            User current = userDAO.findById(change.userId);
            if (current == null) {
                continue;
            }
            boolean isCurrentlyAdmin = "ADMIN".equals(current.getRole());
            boolean isRoleChanged = !current.getRole().equals(change.newRole);
            boolean isBeingDemoted = isCurrentlyAdmin && !"ADMIN".equals(change.newRole);
            boolean isBeingLocked = !change.newActive;

            if (isCurrentlyAdmin && (isBeingDemoted || isBeingLocked)) {
                lockedOrDemotedAdminNames.add(current.getFullName());
                continue; // da bi chan boi quy tac 1, khong can kiem tra tiep dong nay
            }
            if (!current.isActive() && isRoleChanged) {
                roleChangedWhileLockedNames.add(current.getFullName());
                continue;
            }
            if (!requesterIsMasterAdmin && "ADMIN".equals(change.newRole) && !isCurrentlyAdmin) {
                unauthorizedPromoteNames.add(current.getFullName());
            }
        }

        // Buoc 2: neu co vi pham, HUY TOAN BO thao tac luu (khong ghi bat ky thay doi nao), bao loi ro rang
        List<String> violationMessages = new ArrayList<>();
        if (!lockedOrDemotedAdminNames.isEmpty()) {
            violationMessages.add("không thể khóa hoặc hạ quyền tài khoản ADMIN: "
                    + String.join(", ", lockedOrDemotedAdminNames));
        }
        if (!roleChangedWhileLockedNames.isEmpty()) {
            violationMessages.add("tài khoản đang bị khóa nên không thể đổi ROLE, hãy mở khóa trước: "
                    + String.join(", ", roleChangedWhileLockedNames));
        }
        if (!unauthorizedPromoteNames.isEmpty()) {
            violationMessages.add("chỉ ADMIN chính mới được cấp quyền ADMIN cho: "
                    + String.join(", ", unauthorizedPromoteNames));
        }
        if (!violationMessages.isEmpty()) {
            String message = "Không thể lưu thay đổi (" + String.join("; ", violationMessages)
                    + "). Không có thay đổi nào được lưu, vui lòng bỏ chọn các thay đổi này rồi thử lại.";
            redirectBack(req, resp, message);
            return;
        }

        // Buoc 3: khong co vi pham, tien hanh luu toan bo thay doi
        for (PendingChange change : pendingChanges) {
            userDAO.updateRoleAndStatus(change.userId, change.newRole, change.newActive);
        }
        redirectBack(req, resp, null);
    }

    private List<PendingChange> parsePendingChanges(HttpServletRequest req) {
        List<PendingChange> result = new ArrayList<>();
        Enumeration<String> paramNames = req.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String name = paramNames.nextElement();
            if (!name.startsWith("role_")) {
                continue;
            }
            String userIdStr = name.substring("role_".length());
            try {
                PendingChange change = new PendingChange();
                change.userId = Long.parseLong(userIdStr);
                change.newRole = req.getParameter(name);
                change.newActive = "true".equals(req.getParameter("active_" + userIdStr));
                result.add(change);
            } catch (NumberFormatException ignored) {
                // Tham so khong dung dinh dang, bo qua dong nay
            }
        }
        return result;
    }

    private void redirectBack(HttpServletRequest req, HttpServletResponse resp, String errorMessage)
            throws IOException {
        String keyword = req.getParameter("keyword");
        String page = req.getParameter("page");
        StringBuilder redirectUrl = new StringBuilder(req.getContextPath()).append("/admin/users?");
        if (keyword != null && !keyword.isBlank()) {
            redirectUrl.append("keyword=").append(URLEncoder.encode(keyword, StandardCharsets.UTF_8)).append("&");
        }
        String noLoginFor = req.getParameter("noLoginFor");
        if (noLoginFor != null && !noLoginFor.isBlank()) {
            redirectUrl.append("noLoginFor=").append(URLEncoder.encode(noLoginFor, StandardCharsets.UTF_8)).append("&");
        }
        if (page != null && !page.isBlank()) {
            redirectUrl.append("page=").append(page).append("&");
        }
        if (errorMessage != null) {
            redirectUrl.append("error=").append(URLEncoder.encode(errorMessage, StandardCharsets.UTF_8));
        }
        resp.sendRedirect(redirectUrl.toString());
    }
}