package com.doveso.controller.admin;

import com.doveso.bo.TicketBO;
import com.doveso.bo.TicketBOImpl;
import com.doveso.model.TicketPreviewItem;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static com.doveso.controller.admin.AdminTicketSupport.*;

/**
 * UC10: Them ve do moi (ADMIN) theo mien / dai / ngay.
 * GET  /admin/tickets/create                             : form chon mien, dai, ngay
 * GET  /admin/tickets/create?region=&company=&date=...   : lay du lieu tu nguon va hien thi xem truoc
 * POST /admin/tickets/create                             : action = save | savePublish (lay lai du lieu tu nguon roi luu)
 * company = "ALL": tat ca cac dai cua mien xo hom do.
 */
@WebServlet("/admin/tickets/create")
public class TicketCreateServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/admin/ticket-create.jsp";
    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_PUBLISH = "savePublish";
    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        moveFlashMessages(req);
        TicketBO bo = TicketBOImpl.newDefault();
        String region = trim(req.getParameter("region"));
        String company = trim(req.getParameter("company"));
        String dateParam = trim(req.getParameter("date"));
        req.setAttribute("maxDate", LocalDate.now().toString());

        if (region.isEmpty() && company.isEmpty() && dateParam.isEmpty()) {
            region = DEFAULT_REGION;
            company = DEFAULT_COMPANY;
            dateParam = LocalDate.now().toString();
            putFilterData(req, bo, region, company, false, ALL_COMPANIES);
            req.setAttribute("dateValue", dateParam);
            forward(req, resp);
            return;
        }

        putFilterData(req, bo, region, company, false, ALL_COMPANIES);
        req.setAttribute("dateValue", dateParam);
        String problem = bo.validateSingleDay(region, company, dateParam);
        if (problem != null) {
            req.setAttribute("error", problem);
            forward(req, resp);
            return;
        }

        LocalDate date = LocalDate.parse(dateParam);
        List<TicketPreviewItem> items = bo.previewDay(region, company, date);
        req.setAttribute("drawDateFormatted", date.format(DISPLAY_DATE));
        putPreviewCounts(req, items);
        forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        TicketBO bo = TicketBOImpl.newDefault();
        String region = trim(req.getParameter("region"));
        String company = trim(req.getParameter("company"));
        String dateParam = trim(req.getParameter("date"));
        String action = req.getParameter("action");
        if (!(ACTION_SAVE.equals(action) || ACTION_SAVE_PUBLISH.equals(action))
                || bo.validateSingleDay(region, company, dateParam) != null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Yêu cầu không hợp lệ.");
            return;
        }

        LocalDate date = LocalDate.parse(dateParam);
        boolean publish = ACTION_SAVE_PUBLISH.equals(action);
        List<TicketPreviewItem> items = bo.previewDay(region, company, date);

        User admin = (User) req.getSession().getAttribute("currentUser");
        List<Long> savedIds = new ArrayList<>();
        List<String> failed = new ArrayList<>();
        bo.saveOkItems(items, admin, publish, savedIds, failed);

        if (savedIds.isEmpty()) {
            putFilterData(req, bo, region, company, false, ALL_COMPANIES);
            req.setAttribute("maxDate", LocalDate.now().toString());
            req.setAttribute("dateValue", dateParam);
            req.setAttribute("drawDateFormatted", date.format(DISPLAY_DATE));
            putPreviewCounts(req, items);
            req.setAttribute("error", failed.isEmpty()
                    ? "Không có vé dò nào được lưu (vé dò đã tồn tại hoặc nguồn chưa có kết quả)."
                    : "Không thể lưu vé dò, vui lòng thử lại.");
            forward(req, resp);
            return;
        }

        String dateText = date.format(DISPLAY_DATE);
        String message = "Đã lưu" + (publish ? " và công bố " : " ") + savedIds.size() + " vé dò ngày " + dateText
                + (publish ? "." : " (chưa công bố).");
        if (!failed.isEmpty()) {
            req.getSession().setAttribute("flashError", "Không lưu được: " + String.join(", ", failed));
        }
        req.getSession().setAttribute("flashSuccess", message);
        // Quay lai chinh trang nay (khong sang trang chi tiet / danh sach) de admin xem lai ngay vua luu
        resp.sendRedirect(req.getContextPath() + "/admin/tickets/create?region="
                + URLEncoder.encode(region, StandardCharsets.UTF_8)
                + "&company=" + URLEncoder.encode(company, StandardCharsets.UTF_8)
                + "&date=" + dateParam);
    }

    private void forward(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
