package com.doveso.controller.auth;

import com.doveso.bo.BoResult;
import com.doveso.bo.UserBO;
import com.doveso.bo.UserBOImpl;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * Servlet xu ly UC02: Dang nhap.
 * GET  /login  -> hien thi form dang nhap
 * POST /login  -> goi UserBO xac thuc, tao session, chuyen huong theo ROLE
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/auth/login.jsp";

    private final UserBO userBO = UserBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        BoResult<User> result = userBO.login(email, password);
        if (!result.isOk()) {
            req.setAttribute("error", result.getError());
            req.getRequestDispatcher(VIEW).forward(req, resp);
            return;
        }

        User user = result.getValue();
        HttpSession session = req.getSession(true);
        session.setAttribute("currentUser", user);

        if ("ADMIN".equals(user.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/admin/users");
        } else {
            resp.sendRedirect(req.getContextPath() + "/");
        }
    }
}
