package com.doveso.controller.auth;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;
import com.doveso.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * Servlet xu ly UC02: Dang nhap.
 * GET  /login  -> hien thi form dang nhap
 * POST /login  -> xac thuc, tao session, chuyen huong theo ROLE
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        User user = userDAO.findByEmail(email);

        // Buoc 3a: sai email/mat khau
        if (user == null || !PasswordUtil.verify(password, user.getPasswordHash())) {
            req.setAttribute("error", "Sai tên đăng nhập hoặc mật khẩu.");
            req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
            return;
        }

        // Buoc 3b: tai khoan bi khoa
        if (!user.isActive()) {
            req.setAttribute("error", "Tài khoản của bạn đã bị khóa, vui lòng liên hệ quản trị viên.");
            req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
            return;
        }

        HttpSession session = req.getSession(true);
        session.setAttribute("currentUser", user);
        userDAO.updateLastLogin(user.getId());

        if ("ADMIN".equals(user.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/admin/users");
        } else {
            resp.sendRedirect(req.getContextPath() + "/");
        }
    }
}
