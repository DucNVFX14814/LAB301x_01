package com.doveso.controller.admin;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryPrizeDAO;
import com.doveso.dao.TicketDAO;
import com.doveso.dao.impl.CompanyDAOImpl;
import com.doveso.dao.impl.LotteryPrizeDAOImpl;
import com.doveso.dao.impl.TicketDAOImpl;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryRegion;
import com.doveso.model.LotteryTicket;
import com.doveso.model.TicketPreviewItem;
import com.doveso.model.User;
import com.doveso.util.LotteryFetchException;
import com.doveso.util.LotteryResultCache;
import com.doveso.util.MinhNgocClient;
import com.doveso.util.ValidationUtil;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Logic dung chung cho cac man hinh them ve do (tao le, tao hang loat) va danh sach ve do cua ADMIN:
 * nap danh sach mien / dai cho bo loc, tao danh sach xem truoc (lay du lieu tu nguon) va luu ve do.
 */
final class AdminTicketSupport {

    /** Gia tri tham so "company" nghia la tat ca cac dai cua mien (ap dung cho man hinh them ve do). */
    static final String ALL_COMPANIES = "ALL";
    static final String DEFAULT_REGION = MinhNgocClient.REGION_BAC;
    static final String DEFAULT_COMPANY = "mien-bac";

    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final CompanyDAO companyDAO = new CompanyDAOImpl();
    private final TicketDAO ticketDAO = new TicketDAOImpl();
    private final LotteryPrizeDAO prizeDAO = new LotteryPrizeDAOImpl();

    /** Danh sach mien va dai dang hoat dong, nap 1 lan cho 1 request. */
    private final List<LotteryRegion> regions;
    private final List<LotteryCompany> companies;

    /** Bo nho dem ket qua nguon trong 1 request, va tinh duoc chon lay tu trang rieng (null = dung trang mien). */
    private final LotteryResultCache cache = new LotteryResultCache();
    private LotteryCompany provinceCompany;

    AdminTicketSupport() {
        this.regions = companyDAO.findAllRegions();
        this.companies = companyDAO.findActiveCompanies();
    }

    /** Dat cac attribute "regions", "companies" cho fragment _company-select.jsp. */
    void putFilterData(HttpServletRequest req, String selRegion, String selCompany,
                       boolean allowAllRegion, String allCompanyValue) {
        req.setAttribute("regions", regions);
        req.setAttribute("companies", companies);
        req.setAttribute("selRegion", selRegion);
        req.setAttribute("selCompany", selCompany);
        req.setAttribute("allowAllRegion", allowAllRegion);
        req.setAttribute("allCompanyValue", allCompanyValue);
    }

    boolean isValidRegion(String regionCode) {
        for (LotteryRegion r : regions) {
            if (r.getRegionCode().equals(regionCode)) {
                return true;
            }
        }
        return false;
    }

    LotteryCompany findCompany(String companyCode) {
        for (LotteryCompany c : companies) {
            if (c.getCompanyCode().equals(companyCode)) {
                return c;
            }
        }
        return null;
    }

    List<LotteryCompany> companiesOfRegion(String regionCode) {
        List<LotteryCompany> result = new ArrayList<>();
        for (LotteryCompany c : companies) {
            if (c.getRegionCode().equals(regionCode)) {
                result.add(c);
            }
        }
        return result;
    }

    /**
     * Xac dinh danh sach dai can xu ly tu (region, company). company = "ALL" -> tat ca dai cua mien.
     * Tra ve null neu tham so khong hop le (mien khong ton tai, dai khong thuoc mien).
     */
    List<LotteryCompany> resolveTargets(String regionCode, String companyParam) {
        if (!isValidRegion(regionCode)) {
            return null;
        }
        if (ALL_COMPANIES.equals(companyParam)) {
            List<LotteryCompany> all = companiesOfRegion(regionCode);
            return all.isEmpty() ? null : all;
        }
        LotteryCompany c = findCompany(companyParam);
        if (c == null || !c.getRegionCode().equals(regionCode)) {
            return null;
        }
        return List.of(c);
    }

    /**
     * Chon nguon lay du lieu cho request nay. Chon 1 tinh cu the cua mien Trung / Nam -> lay tu trang rieng cua
     * tinh do (moi trang cho 6 ky gan nhat, nhanh hon); cac truong hop con lai -> lay tu trang mien
     * (moi trang cho 7 ngay). Neu trang rieng cua tinh loi thi tu dong quay ve trang mien.
     */
    void selectSource(String regionCode, List<LotteryCompany> selectedTargets, boolean allMode) {
        this.provinceCompany = (!allMode && !MinhNgocClient.REGION_BAC.equals(regionCode)
                && selectedTargets != null && selectedTargets.size() == 1) ? selectedTargets.get(0) : null;
    }

    /** Tai truoc cac trang nguon can de phu khoang [from, to], de vong lap tung ngay khong phai goi lai nguon. */
    void prefetch(String regionCode, LocalDate from, LocalDate to) {
        if (provinceCompany != null) {
            LotteryCompany c = provinceCompany;
            cache.prefetch(provinceKey(c), from, to, d -> MinhNgocClient.fetchProvincePage(c, d));
        } else {
            cache.prefetch(regionKey(regionCode), from, to, regionFetcher(regionCode));
        }
    }

    /**
     * Tao danh sach xem truoc cho ngay date. Tinh da co ve do -> EXISTS (khong lay lai tu nguon);
     * cac tinh con lai lay tu nguon: co du lieu -> OK, loi -> ERROR.
     *
     * @param allMode    true: nguoi dung chon "Tat ca tinh"; loi chung cua nguon chi bao 1 dong cho ca ngay
     * @param skipNoDraw true: tinh khong xo vao ngay do thi bo qua (khong tao dong); false: bao loi "khong mo thuong"
     */
    List<TicketPreviewItem> buildPreview(LocalDate date, String regionCode, List<LotteryCompany> targets,
                                         boolean allMode, boolean skipNoDraw) {
        List<TicketPreviewItem> items = new ArrayList<>();
        String pageError = null;

        for (LotteryCompany c : targets) {
            LotteryTicket existing = ticketDAO.findByCompanyAndDate(c.getCompanyCode(), date);
            if (existing != null) {
                TicketPreviewItem item = new TicketPreviewItem(date, c, TicketPreviewItem.EXISTS);
                item.setExistingTicketId(existing.getId());
                item.setExistingPublished(existing.isPublished());
                item.setPrizes(sortPrizes(prizeDAO.findByTicketId(existing.getId())));
                items.add(item);
                continue;
            }
            Outcome o = lookup(c, date, regionCode);
            if (o.prizes != null) {
                TicketPreviewItem item = new TicketPreviewItem(date, c, TicketPreviewItem.OK);
                item.setPrizes(sortPrizes(new ArrayList<>(o.prizes)));
                items.add(item);
            } else if (o.error != null) {
                if (o.pageLevel && allMode) {
                    pageError = o.error;
                } else {
                    items.add(errorItem(date, c, o.error));
                }
            } else if (!skipNoDraw) {
                items.add(errorItem(date, c, "Tỉnh " + c.getCompanyName() + " không mở thưởng ngày "
                        + date.format(DISPLAY_DATE) + "."));
            }
        }

        if (pageError != null) {
            items.add(errorItem(date, null, pageError));
        } else if (items.isEmpty() && !skipNoDraw) {
            items.add(errorItem(date, null, "Không có tỉnh nào trong hệ thống mở thưởng ngày "
                    + date.format(DISPLAY_DATE) + "."));
        }
        return items;
    }

    /** Ket qua tra cuu 1 tinh trong 1 ngay: co du lieu (prizes), loi (error), hoac khong xo (ca 2 deu null). */
    private static final class Outcome {
        List<LotteryPrize> prizes;
        String error;
        boolean pageLevel; // loi cua ca trang nguon (khong ket noi, chua co ket qua...) chu khong rieng tinh nay
    }

    private Outcome lookup(LotteryCompany c, LocalDate date, String regionCode) {
        Outcome o = new Outcome();
        if (provinceCompany != null && provinceCompany.getCompanyCode().equals(c.getCompanyCode())) {
            try {
                MinhNgocClient.RegionResult r = cache.get(provinceKey(c), date,
                        d -> MinhNgocClient.fetchProvincePage(c, d));
                if (r != null) {
                    fill(o, r, c.getCompanyCode());
                }
                return o; // r == null: trang rieng cua tinh khong co ky nay = tinh khong xo ngay do
            } catch (LotteryFetchException e) {
                // Trang rieng cua tinh khong dung duoc (sai slug, loi mang...): quay ve trang mien
            }
        }
        try {
            MinhNgocClient.RegionResult r = cache.get(regionKey(regionCode), date, regionFetcher(regionCode));
            if (r == null) {
                o.error = "Nguồn dữ liệu chưa có kết quả xổ số " + MinhNgocClient.regionLabel(regionCode)
                        + " ngày " + date.format(DISPLAY_DATE) + ".";
                o.pageLevel = true;
            } else {
                fill(o, r, c.getCompanyCode());
            }
        } catch (LotteryFetchException e) {
            o.error = e.getMessage();
            o.pageLevel = true;
        }
        return o;
    }

    private static void fill(Outcome o, MinhNgocClient.RegionResult r, String companyCode) {
        if (r.getPrizes().containsKey(companyCode)) {
            o.prizes = r.getPrizes().get(companyCode);
        } else if (r.getErrors().containsKey(companyCode)) {
            o.error = r.getErrors().get(companyCode);
        }
    }

    private LotteryResultCache.Fetcher regionFetcher(String regionCode) {
        return d -> MinhNgocClient.fetchRegionPage(regionCode, d, companiesOfRegion(regionCode));
    }

    private static String regionKey(String regionCode) {
        return "REGION:" + regionCode;
    }

    private static String provinceKey(LotteryCompany c) {
        return "PROVINCE:" + c.getCompanyCode();
    }

    /**
     * Luu cac dong OK cua danh sach xem truoc. Du lieu da duoc lay lai tu nguon trong buildPreview,
     * khong tin du lieu tu client gui len.
     *
     * @param savedIds  danh sach id ve do da luu (out)
     * @param failed    mo ta cac dong luu that bai (out)
     */
    void saveOkItems(List<TicketPreviewItem> items, User admin, boolean publish,
                     List<Long> savedIds, List<String> failed) {
        for (TicketPreviewItem item : items) {
            if (!item.isOk()) {
                continue;
            }
            try {
                LotteryTicket ticket = new LotteryTicket();
                ticket.setCompanyCode(item.getCompanyCode());
                ticket.setDrawDate(item.getDate());
                ticket.setCreatedBy(admin.getId());
                savedIds.add(ticketDAO.insertWithPrizes(ticket, item.getPrizes(), publish));
            } catch (RuntimeException e) {
                failed.add(item.getCompanyName() + " " + item.getDateFormatted());
            }
        }
    }

    static List<LotteryPrize> sortPrizes(List<LotteryPrize> prizes) {
        List<String> order = Arrays.asList(LotteryPrize.PRIZE_ORDER);
        prizes.sort(Comparator.comparingInt(p -> order.indexOf(p.getPrizeCode())));
        return prizes;
    }

    private static TicketPreviewItem errorItem(LocalDate date, LotteryCompany c, String message) {
        TicketPreviewItem item = new TicketPreviewItem(date, c, TicketPreviewItem.ERROR);
        item.setMessage(message);
        return item;
    }

    /** Ket qua dem theo trang thai cua danh sach xem truoc (dung chung cho man hinh tao le va tao hang loat). */
    static final class PreviewCounts {
        int successCount;
        int existsPublishedCount;
        int existsUnpublishedCount;
        int errorCount;
    }

    /** Dem so dong theo tung trang thai trong danh sach xem truoc, de hien thi cac badge thong ke. */
    static PreviewCounts countByStatus(List<TicketPreviewItem> items) {
        PreviewCounts counts = new PreviewCounts();
        for (TicketPreviewItem item : items) {
            switch (item.getStatus()) {
                case TicketPreviewItem.OK -> counts.successCount++;
                case TicketPreviewItem.EXISTS -> {
                    if (item.isExistingPublished()) {
                        counts.existsPublishedCount++;
                    } else {
                        counts.existsUnpublishedCount++;
                    }
                }
                default -> counts.errorCount++;
            }
        }
        return counts;
    }

    static String trim(String s) {
        return ValidationUtil.trimToEmpty(s);
    }

    static LocalDate parseDate(String s) {
        if (s == null || s.isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(s);
        } catch (java.time.format.DateTimeParseException e) {
            return null;
        }
    }
}
