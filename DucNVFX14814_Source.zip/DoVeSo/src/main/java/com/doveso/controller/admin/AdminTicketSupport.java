package com.doveso.controller.admin;

import com.doveso.bo.TicketBO;
import com.doveso.model.TicketPreviewItem;
import com.doveso.util.MinhNgocClient;
import com.doveso.util.ValidationUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;
import java.util.List;

/**
 * Tien ich phia web (chi lam viec voi HttpServletRequest/Session) dung chung cho cac Servlet quan ly ve do cua ADMIN.
 * Toan bo logic nghiep vu (kiem tra tham so, lay du lieu nguon, luu ve do...) nam o tang BO (TicketBO/TicketBOImpl).
 */
final class AdminTicketSupport {

    /** Gia tri tham so "company" nghia la tat ca cac dai cua mien (ap dung cho man hinh them ve do). */
    static final String ALL_COMPANIES = TicketBO.ALL_COMPANIES;
    static final String DEFAULT_REGION = MinhNgocClient.REGION_BAC;
    static final String DEFAULT_COMPANY = "mien-bac";

    private AdminTicketSupport() {
        // Chi dung phuong thuc static
    }

    /** Dat cac attribute "regions", "companies" cho fragment _company-select.jsp. */
    static void putFilterData(HttpServletRequest req, TicketBO bo, String selRegion, String selCompany,
                              boolean allowAllRegion, String allCompanyValue) {
        req.setAttribute("regions", bo.getRegions());
        req.setAttribute("companies", bo.getCompanies());
        req.setAttribute("selRegion", selRegion);
        req.setAttribute("selCompany", selCompany);
        req.setAttribute("allowAllRegion", allowAllRegion);
        req.setAttribute("allCompanyValue", allCompanyValue);
    }

    /** Dat attribute items va cac badge thong ke (dung chung cho man hinh them le va them hang loat). */
    static void putPreviewCounts(HttpServletRequest req, List<TicketPreviewItem> items) {
        req.setAttribute("items", items);
        TicketBO.PreviewCounts counts = TicketBO.countByStatus(items);
        req.setAttribute("successCount", counts.successCount);
        req.setAttribute("existsPublishedCount", counts.existsPublishedCount);
        req.setAttribute("existsUnpublishedCount", counts.existsUnpublishedCount);
        req.setAttribute("errorCount", counts.errorCount);
    }

    /** Chuyen thong bao (flash) luu tam trong session sang request de hien thi 1 lan. */
    static void moveFlashMessages(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session == null) {
            return;
        }
        Object success = session.getAttribute("flashSuccess");
        if (success != null) {
            req.setAttribute("success", success);
            session.removeAttribute("flashSuccess");
        }
        Object error = session.getAttribute("flashError");
        if (error != null) {
            req.setAttribute("error", error);
            session.removeAttribute("flashError");
        }
    }

    /** Dat thong bao ket qua xu ly hang loat vao session (flash) de hien thi sau khi chuyen huong. */
    static void putFlash(HttpServletRequest req, String success, String error) {
        if (success != null) {
            req.getSession().setAttribute("flashSuccess", success);
        }
        if (error != null) {
            req.getSession().setAttribute("flashError", error);
        }
    }

    static String trim(String s) {
        return ValidationUtil.trimToEmpty(s);
    }

    static LocalDate parseDate(String s) {
        return ValidationUtil.parseIsoDate(s);
    }
}
