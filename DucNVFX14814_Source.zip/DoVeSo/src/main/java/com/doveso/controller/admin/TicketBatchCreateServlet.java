package com.doveso.controller.admin;

import com.doveso.bo.FlashResult;
import com.doveso.bo.MasterAdmin;
import com.doveso.bo.TicketBO;
import com.doveso.bo.TicketBOImpl;
import com.doveso.model.TicketPreviewItem;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static com.doveso.controller.admin.AdminTicketSupport.*;

/**
 * UC10 (mo rong): Them ve do hang loat theo mien / dai trong 1 khoang ngay (bat buoc cung 1 thang).
 * GET  /admin/tickets/create-batch                                  : form chon mien, dai, khoang ngay
 * GET  /admin/tickets/create-batch?region=&company=&from=&to=       : lay du lieu tung ngay, hien thi bang xem truoc
 * POST /admin/tickets/create-batch                                  : action = saveAll | savePublishAll (tham so "pairs" = maDai|yyyy-MM-dd, lap lai nhieu lan)
 *                                                                     hoac publishExistingAll (tham so "publishIds")
 * company = "ALL": tat ca cac dai cua mien.
 *
 * Quy uoc xu ly loi khi lay du lieu hang loat: dong nao loi (nguon chua co ket qua...) thi bao loi rieng,
 * cac dong con lai van duoc xu ly, roi bao cao tong ket o cuoi (khong dung ca khoang lai).
 */
@WebServlet("/admin/tickets/create-batch")
public class TicketBatchCreateServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/admin/ticket-create-batch.jsp";
    private static final String ACTION_SAVE_ALL = "saveAll";
    private static final String ACTION_SAVE_PUBLISH_ALL = "savePublishAll";
    private static final String ACTION_PUBLISH_EXISTING_ALL = "publishExistingAll";
    private static final String FORBIDDEN_MESSAGE =
            "Chỉ tài khoản ADMIN chính mới được dùng chức năng thêm vé dò hàng loạt.";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        /*
         * Chuc nang them ve do hang loat chi danh cho tai khoan ADMIN chinh (MasterAdmin) de tranh nhieu ADMIN
         * cung goi hang loat request toi nguon du lieu cung luc. Cac ADMIN khac chi dung duoc man hinh
         * them ve do le (/admin/tickets/create).
         */
        if (!isMasterAdmin(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, FORBIDDEN_MESSAGE);
            return;
        }
        TicketBO bo = TicketBOImpl.newDefault();
        req.setAttribute("maxDate", LocalDate.now().toString());
        moveFlashMessages(req);

        String region = trim(req.getParameter("region"));
        String company = trim(req.getParameter("company"));
        String fromParam = trim(req.getParameter("from"));
        String toParam = trim(req.getParameter("to"));

        if (region.isEmpty() && company.isEmpty() && fromParam.isEmpty() && toParam.isEmpty()) {
            LocalDate today = LocalDate.now();
            putFilterData(req, bo, DEFAULT_REGION, DEFAULT_COMPANY, false, ALL_COMPANIES);
            req.setAttribute("fromValue", today.withDayOfMonth(1).toString());
            req.setAttribute("toValue", today.toString());
            forward(req, resp);
            return;
        }

        putFilterData(req, bo, region, company, false, ALL_COMPANIES);
        req.setAttribute("fromValue", fromParam);
        req.setAttribute("toValue", toParam);
        if (bo.resolveTargets(region, company) == null) {
            req.setAttribute("error", "Vui lòng chọn miền và tỉnh hợp lệ.");
            forward(req, resp);
            return;
        }
        LocalDate from = parseDate(fromParam);
        LocalDate to = parseDate(toParam);
        String problem = bo.validateRange(from, to);
        if (problem != null) {
            req.setAttribute("error", problem);
            forward(req, resp);
            return;
        }

        List<TicketPreviewItem> items = bo.previewRange(region, company, from, to);
        if (items.isEmpty()) {
            req.setAttribute("notice", "Không có kỳ mở thưởng nào trong khoảng ngày đã chọn.");
        }

        putPreviewCounts(req, items);
        req.setAttribute("totalDays", ChronoUnit.DAYS.between(from, to) + 1);
        forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        if (!isMasterAdmin(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, FORBIDDEN_MESSAGE);
            return;
        }
        TicketBO bo = TicketBOImpl.newDefault();
        String action = req.getParameter("action");
        String region = trim(req.getParameter("region"));
        String company = trim(req.getParameter("company"));
        String fromParam = trim(req.getParameter("from"));
        String toParam = trim(req.getParameter("to"));
        if (bo.resolveTargets(region, company) == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Yêu cầu không hợp lệ.");
            return;
        }

        FlashResult result;
        if (ACTION_SAVE_ALL.equals(action) || ACTION_SAVE_PUBLISH_ALL.equals(action)) {
            // action = saveAll | savePublishAll: luu tat ca cac dong "san sang luu" (tham so "pairs" = maDai|ngay)
            User admin = (User) req.getSession().getAttribute("currentUser");
            result = bo.saveBatch(admin, region, company, req.getParameterValues("pairs"),
                    ACTION_SAVE_PUBLISH_ALL.equals(action));
        } else if (ACTION_PUBLISH_EXISTING_ALL.equals(action)) {
            // action = publishExistingAll: cong bo tat ca ve do da co san nhung dang UNPUBLISH ("publishIds")
            result = bo.publishExisting(req.getParameterValues("publishIds"));
        } else {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Yêu cầu không hợp lệ.");
            return;
        }
        putFlash(req, result.getSuccess(), result.getError());
        resp.sendRedirect(req.getContextPath() + "/admin/tickets/create-batch?region="
                + URLEncoder.encode(region, StandardCharsets.UTF_8)
                + "&company=" + URLEncoder.encode(company, StandardCharsets.UTF_8)
                + "&from=" + URLEncoder.encode(fromParam, StandardCharsets.UTF_8)
                + "&to=" + URLEncoder.encode(toParam, StandardCharsets.UTF_8));
    }

    /** Tai khoan dang dang nhap co phai ADMIN chinh khong. */
    private boolean isMasterAdmin(HttpServletRequest req) {
        return MasterAdmin.is((User) req.getSession().getAttribute("currentUser"));
    }

    private void forward(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
