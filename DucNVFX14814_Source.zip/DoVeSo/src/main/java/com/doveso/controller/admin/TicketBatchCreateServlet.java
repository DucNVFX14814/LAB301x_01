package com.doveso.controller.admin;

import com.doveso.dao.TicketDAO;
import com.doveso.dao.impl.TicketDAOImpl;
import com.doveso.model.LotteryCompany;
import com.doveso.model.TicketPreviewItem;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.doveso.controller.admin.AdminTicketSupport.*;

/**
 * UC10 (mo rong): Them ve do hang loat theo mien / dai trong 1 khoang ngay (bat buoc cung 1 thang).
 * GET  /admin/tickets/create-batch                                  : form chon mien, dai, khoang ngay
 * GET  /admin/tickets/create-batch?region=&company=&from=&to=       : lay du lieu tung ngay, hien thi bang xem truoc
 * POST /admin/tickets/create-batch                                  : action = saveAll | savePublishAll (tham so "pairs" = maDai|yyyy-MM-dd, lap lai nhieu lan)
 *                                                                     hoac publishExistingAll (tham so "publishIds")
 * company = "ALL": tat ca cac dai cua mien.
 *
 * Quy uoc xu ly loi khi lay du lieu hang loat: dong nao loi (nguon chua co ket qua...) thi bao loi rieng,
 * cac dong con lai van duoc xu ly, roi bao cao tong ket o cuoi (khong dung ca khoang lai).
 */
@WebServlet("/admin/tickets/create-batch")
public class TicketBatchCreateServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/admin/ticket-create-batch.jsp";
    private static final String ACTION_SAVE_ALL = "saveAll";
    private static final String ACTION_SAVE_PUBLISH_ALL = "savePublishAll";
    private static final String ACTION_PUBLISH_EXISTING_ALL = "publishExistingAll";
    /** Gioi han an toan so ngay xu ly 1 lan (cung thang nen toi da la 31, nhung chan them cho chac). */
    private static final int MAX_RANGE_DAYS = 31;
    /**
     * Chuc nang them ve do hang loat chi danh cho tai khoan ADMIN chinh (id nay, theo du lieu mau) de tranh
     * nhieu ADMIN cung goi hang loat request toi nguon du lieu cung luc. Cac ADMIN khac chi dung duoc man hinh
     * them ve do le (/admin/tickets/create).
     */
    private static final long MASTER_ADMIN_ID = 10000000L;

    private final TicketDAO ticketDAO = new TicketDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        if (!isMasterAdmin(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN,
                    "Chỉ tài khoản ADMIN chính mới được dùng chức năng thêm vé dò hàng loạt.");
            return;
        }
        AdminTicketSupport support = new AdminTicketSupport();
        req.setAttribute("maxDate", LocalDate.now().toString());
        moveFlashMessages(req);

        String region = trim(req.getParameter("region"));
        String company = trim(req.getParameter("company"));
        String fromParam = trim(req.getParameter("from"));
        String toParam = trim(req.getParameter("to"));

        if (region.isEmpty() && company.isEmpty() && fromParam.isEmpty() && toParam.isEmpty()) {
            LocalDate today = LocalDate.now();
            support.putFilterData(req, DEFAULT_REGION, DEFAULT_COMPANY, false, ALL_COMPANIES);
            req.setAttribute("fromValue", today.withDayOfMonth(1).toString());
            req.setAttribute("toValue", today.toString());
            forward(req, resp);
            return;
        }

        support.putFilterData(req, region, company, false, ALL_COMPANIES);
        req.setAttribute("fromValue", fromParam);
        req.setAttribute("toValue", toParam);
        List<LotteryCompany> targets = support.resolveTargets(region, company);
        if (targets == null) {
            req.setAttribute("error", "Vui lòng chọn miền và tỉnh hợp lệ.");
            forward(req, resp);
            return;
        }
        LocalDate from = parseDate(fromParam);
        LocalDate to = parseDate(toParam);
        String problem = validateRange(from, to);
        if (problem != null) {
            req.setAttribute("error", problem);
            forward(req, resp);
            return;
        }

        boolean allMode = ALL_COMPANIES.equals(company);
        support.selectSource(region, targets, allMode);
        support.prefetch(region, from, to);
        List<TicketPreviewItem> items = new ArrayList<>();
        for (LocalDate date = to; !date.isBefore(from); date = date.minusDays(1)) {
            // Ngay 1 tinh khong xo (vd Da Nang chi xo Thu Tu, Thu Bay) thi bo qua, khong tinh la loi
            items.addAll(support.buildPreview(date, region, targets, allMode, true));
        }
        if (items.isEmpty()) {
            req.setAttribute("notice", "Không có kỳ mở thưởng nào trong khoảng ngày đã chọn.");
        }

        PreviewCounts counts = countByStatus(items);
        req.setAttribute("items", items);
        req.setAttribute("totalDays", ChronoUnit.DAYS.between(from, to) + 1);
        req.setAttribute("successCount", counts.successCount);
        req.setAttribute("existsPublishedCount", counts.existsPublishedCount);
        req.setAttribute("existsUnpublishedCount", counts.existsUnpublishedCount);
        req.setAttribute("errorCount", counts.errorCount);
        forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        if (!isMasterAdmin(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN,
                    "Chỉ tài khoản ADMIN chính mới được dùng chức năng thêm vé dò hàng loạt.");
            return;
        }
        AdminTicketSupport support = new AdminTicketSupport();
        String action = req.getParameter("action");
        String region = trim(req.getParameter("region"));
        String company = trim(req.getParameter("company"));
        String fromParam = trim(req.getParameter("from"));
        String toParam = trim(req.getParameter("to"));
        if (support.resolveTargets(region, company) == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Yêu cầu không hợp lệ.");
            return;
        }

        if (ACTION_SAVE_ALL.equals(action) || ACTION_SAVE_PUBLISH_ALL.equals(action)) {
            handleSaveAll(req, support, region, company, ACTION_SAVE_PUBLISH_ALL.equals(action));
        } else if (ACTION_PUBLISH_EXISTING_ALL.equals(action)) {
            handlePublishExistingAll(req);
        } else {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Yêu cầu không hợp lệ.");
            return;
        }
        resp.sendRedirect(req.getContextPath() + "/admin/tickets/create-batch?region="
                + URLEncoder.encode(region, StandardCharsets.UTF_8)
                + "&company=" + URLEncoder.encode(company, StandardCharsets.UTF_8)
                + "&from=" + URLEncoder.encode(fromParam, StandardCharsets.UTF_8)
                + "&to=" + URLEncoder.encode(toParam, StandardCharsets.UTF_8));
    }

    /** action = saveAll | savePublishAll: luu tat ca cac dong "san sang luu" (tham so "pairs" = maDai|ngay). */
    private void handleSaveAll(HttpServletRequest req, AdminTicketSupport support, String region, String companyParam,
                               boolean publish) {
        String[] pairParams = req.getParameterValues("pairs");
        if (pairParams == null || pairParams.length == 0) {
            req.getSession().setAttribute("flashError", "Không có vé dò nào để lưu.");
            return;
        }
        // Gom cac dai theo ngay de moi ngay chi lay du lieu tu nguon 1 lan
        Map<LocalDate, List<LotteryCompany>> byDate = new LinkedHashMap<>();
        for (String pair : pairParams) {
            String[] parts = pair.split("\\|");
            LocalDate date = parts.length == 2 ? parseDate(parts[1]) : null;
            LotteryCompany company = parts.length == 2 ? support.findCompany(parts[0]) : null;
            if (date == null || company == null || !company.getRegionCode().equals(region)) {
                continue;
            }
            byDate.computeIfAbsent(date, d -> new ArrayList<>()).add(company);
        }

        if (byDate.isEmpty()) {
            req.getSession().setAttribute("flashError", "Không có vé dò nào để lưu.");
            return;
        }
        // Tai truoc cac trang nguon can thiet (giong luc xem truoc) de khong phai goi nguon cho tung ngay
        support.selectSource(region, support.resolveTargets(region, companyParam), ALL_COMPANIES.equals(companyParam));
        LocalDate minDate = java.util.Collections.min(byDate.keySet());
        LocalDate maxDate = java.util.Collections.max(byDate.keySet());
        if (!maxDate.isAfter(LocalDate.now())) {
            support.prefetch(region, minDate, maxDate);
        }

        User admin = (User) req.getSession().getAttribute("currentUser");
        List<Long> savedIds = new ArrayList<>();
        List<String> failed = new ArrayList<>();
        for (Map.Entry<LocalDate, List<LotteryCompany>> e : byDate.entrySet()) {
            LocalDate date = e.getKey();
            if (date.isAfter(LocalDate.now())) {
                failed.add(date.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                        + " (ngày trong tương lai)");
                continue;
            }
            List<TicketPreviewItem> items = support.buildPreview(date, region, e.getValue(), false, false);
            support.saveOkItems(items, admin, publish, savedIds, failed);
            for (TicketPreviewItem item : items) {
                if (TicketPreviewItem.ERROR.equals(item.getStatus())) {
                    failed.add((item.getCompanyName() == null ? "" : item.getCompanyName() + " ")
                            + item.getDateFormatted());
                }
            }
        }
        if (!savedIds.isEmpty()) {
            req.getSession().setAttribute("flashSuccess",
                    "Đã lưu" + (publish ? " và công bố " : " ") + savedIds.size() + " vé dò.");
        }
        if (!failed.isEmpty()) {
            req.getSession().setAttribute("flashError",
                    "Không lưu được " + failed.size() + " vé dò: " + String.join(", ", failed));
        } else if (savedIds.isEmpty()) {
            req.getSession().setAttribute("flashError", "Không có vé dò nào được lưu.");
        }
    }

    /** action = publishExistingAll: cong bo tat ca cac ve do da co san nhung dang UNPUBLISH (tham so "publishIds"). */
    private void handlePublishExistingAll(HttpServletRequest req) {
        String[] idParams = req.getParameterValues("publishIds");
        if (idParams == null || idParams.length == 0) {
            req.getSession().setAttribute("flashError", "Không có vé dò nào cần công bố.");
            return;
        }
        int publishedCount = 0;
        List<String> failedIds = new ArrayList<>();
        for (String idParam : idParams) {
            try {
                Long id = Long.valueOf(idParam);
                ticketDAO.publish(id);
                publishedCount++;
            } catch (NumberFormatException e) {
                // bo qua id khong hop le
            } catch (RuntimeException e) {
                log("Loi publish ve do id=" + idParam, e);
                failedIds.add(idParam);
            }
        }
        if (publishedCount > 0) {
            req.getSession().setAttribute("flashSuccess", "Đã công bố " + publishedCount + " vé dò.");
        }
        if (!failedIds.isEmpty()) {
            req.getSession().setAttribute("flashError", "Không công bố được " + failedIds.size() + " vé dò.");
        } else if (publishedCount == 0) {
            req.getSession().setAttribute("flashError", "Không có vé dò nào được công bố.");
        }
    }

    /** Tra ve thong bao loi neu khoang ngay khong hop le, nguoc lai tra ve null. */
    private String validateRange(LocalDate from, LocalDate to) {
        if (from == null || to == null) {
            return "Vui lòng chọn đầy đủ ngày bắt đầu và ngày kết thúc.";
        }
        if (from.isAfter(to)) {
            return "Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.";
        }
        if (to.isAfter(LocalDate.now())) {
            return "Không thể tạo vé dò cho ngày trong tương lai.";
        }
        if (from.getYear() != to.getYear() || from.getMonthValue() != to.getMonthValue()) {
            return "Khoảng ngày phải nằm trong cùng 1 tháng.";
        }
        if (ChronoUnit.DAYS.between(from, to) + 1 > MAX_RANGE_DAYS) {
            return "Khoảng ngày quá lớn, vui lòng chọn tối đa " + MAX_RANGE_DAYS + " ngày.";
        }
        return null;
    }

    /** Tai khoan dang dang nhap co phai ADMIN chinh (id = MASTER_ADMIN_ID) khong. */
    private boolean isMasterAdmin(HttpServletRequest req) {
        User currentUser = (User) req.getSession().getAttribute("currentUser");
        return currentUser != null && currentUser.getId() != null
                && currentUser.getId() == MASTER_ADMIN_ID;
    }

    private void moveFlashMessages(HttpServletRequest req) {
        Object success = req.getSession().getAttribute("flashSuccess");
        if (success != null) {
            req.setAttribute("success", success);
            req.getSession().removeAttribute("flashSuccess");
        }
        Object error = req.getSession().getAttribute("flashError");
        if (error != null) {
            req.setAttribute("error", error);
            req.getSession().removeAttribute("flashError");
        }
    }

    private void forward(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
