package com.doveso.controller.lottery;

import com.doveso.bo.LotteryCheckBO;
import com.doveso.bo.LotteryCheckBOImpl;
import com.doveso.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.time.LocalDate;

/**
 * Servlet thuc hien Chuc nang 3: Thuc hien do ve so.
 * GET  /check-ticket  -> hien thi form chon mien/tinh/ngay + nhap so ve
 * POST /check-ticket  -> goi LotteryCheckBO doi chieu voi ve do PUBLISH (theo dung tinh + ngay da chon)
 *                        va chuyen ket qua sang JSP
 *
 * Ap dung cho tat ca cong ty xo so (khong con gioi han rieng mien Bac). Nguoi dung bat buoc chon 1 tinh
 * (khong ho tro "tat ca tinh") de xac dinh dung ve do can doi chieu.
 *
 * NO_USER: chi duoc do 1 to ve so, khong luu lich su.
 * USER (da dang nhap): duoc do 1 hoac nhieu to ve so (toi da 20) cung luc, ket qua duoc
 * luu vao bang lottery_history de xem lai (UserHistoryServlet).
 */
@WebServlet("/check-ticket")
public class CheckTicketServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/lottery/check-ticket.jsp";

    private final LotteryCheckBO checkBO = LotteryCheckBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Khong chon san mien/tinh mac dinh - de trong, bat nguoi dung tu chon.
        req.setAttribute("regions", checkBO.getRegions());
        req.setAttribute("companies", checkBO.getCompanies());
        req.setAttribute("maxDate", LocalDate.now().toString());
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Nap san danh sach mien/tinh va echo lai lua chon cua nguoi dung cho moi truong hop loi.
        req.setAttribute("regions", checkBO.getRegions());
        req.setAttribute("companies", checkBO.getCompanies());
        req.setAttribute("maxDate", LocalDate.now().toString());
        String companyCode = req.getParameter("company");
        req.setAttribute("selCompany", companyCode == null ? "" : companyCode.trim());

        HttpSession session = req.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        LotteryCheckBO.CheckOutcome outcome = checkBO.check(companyCode, req.getParameter("drawDate"),
                req.getParameter("ticketNumber"), req.getParameter("ticketNumbers"), currentUser);

        if (outcome.getCompany() != null) {
            req.setAttribute("selRegion", outcome.getCompany().getRegionCode());
        }
        if (outcome.getError() != null) {
            req.setAttribute("error", outcome.getError());
        } else {
            req.setAttribute("ticket", outcome.getTicket());
            req.setAttribute("results", outcome.getResults());
            req.setAttribute("grandTotal", outcome.getGrandTotal());
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
