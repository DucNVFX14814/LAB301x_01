package com.doveso.controller.lottery;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryHistoryDAO;
import com.doveso.dao.LotteryPrizeConfigDAO;
import com.doveso.dao.LotteryPrizeDAO;
import com.doveso.dao.TicketDAO;
import com.doveso.dao.impl.CompanyDAOImpl;
import com.doveso.dao.impl.LotteryHistoryDAOImpl;
import com.doveso.dao.impl.LotteryPrizeConfigDAOImpl;
import com.doveso.dao.impl.LotteryPrizeDAOImpl;
import com.doveso.dao.impl.TicketDAOImpl;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryHistory;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryTicket;
import com.doveso.model.User;
import com.doveso.util.LotteryCheckUtil;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Servlet thuc hien Chuc nang 3: Thuc hien do ve so.
 * GET  /check-ticket  -> hien thi form chon mien/tinh/ngay + nhap so ve
 * POST /check-ticket  -> doi chieu voi ve do PUBLISH (theo dung tinh + ngay da chon) va tra ve ket qua
 *
 * Ap dung cho tat ca cong ty xo so (khong con gioi han rieng mien Bac). Nguoi dung bat buoc chon 1 tinh
 * (khong ho tro "tat ca tinh") de xac dinh dung ve do can doi chieu.
 *
 * NO_USER: chi duoc do 1 to ve so, khong luu lich su.
 * USER (da dang nhap): duoc do 1 hoac nhieu to ve so (toi da 20) cung luc, ket qua duoc
 * luu vao bang lottery_history de xem lai (UserHistoryServlet).
 */
@WebServlet("/check-ticket")
public class CheckTicketServlet extends HttpServlet {

    private static final int MAX_TICKET_NUMBERS = 20;
    /** Gioi han do dai du lieu nhap (20 so + dau phan cach) de tranh xu ly chuoi qua lon. */
    private static final int MAX_INPUT_LENGTH = 2000;
    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final TicketDAO ticketDAO = new TicketDAOImpl();
    private final LotteryPrizeDAO prizeDAO = new LotteryPrizeDAOImpl();
    private final LotteryPrizeConfigDAO prizeConfigDAO = new LotteryPrizeConfigDAOImpl();
    private final LotteryHistoryDAO historyDAO = new LotteryHistoryDAOImpl();
    private final CompanyDAO companyDAO = new CompanyDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Khong chon san mien/tinh mac dinh - de trong, bat nguoi dung tu chon.
        req.setAttribute("regions", companyDAO.findAllRegions());
        req.setAttribute("companies", companyDAO.findActiveCompanies());
        req.setAttribute("maxDate", LocalDate.now().toString());
        req.getRequestDispatcher("/WEB-INF/views/lottery/check-ticket.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Nap san danh sach mien/tinh va echo lai lua chon cua nguoi dung cho moi truong hop loi ben duoi.
        req.setAttribute("regions", companyDAO.findAllRegions());
        req.setAttribute("companies", companyDAO.findActiveCompanies());
        req.setAttribute("maxDate", LocalDate.now().toString());
        String companyCode = ValidationUtil.trimToEmpty(req.getParameter("company"));
        req.setAttribute("selCompany", companyCode);

        LotteryCompany company = companyCode.isEmpty() ? null : companyDAO.findByCode(companyCode);
        if (company == null || !company.isActive()) {
            showFormError(req, resp, "Vui lòng chọn tỉnh xổ số hợp lệ.");
            return;
        }
        req.setAttribute("selRegion", company.getRegionCode());

        String drawDateStr = req.getParameter("drawDate");
        LocalDate drawDate;
        try {
            drawDate = LocalDate.parse(drawDateStr);
        } catch (DateTimeParseException | NullPointerException e) {
            showFormError(req, resp, "Vui lòng chọn ngày quay số hợp lệ.");
            return;
        }

        // Business rule: chi duoc do khi ve do da PUBLISH, dung tinh + dung ngay da chon
        LotteryTicket ticket = ticketDAO.findPublishedByCompanyAndDate(companyCode, drawDate);
        if (ticket == null) {
            showFormError(req, resp, "Vé dò " + company.getCompanyName() + " ngày " + drawDate.format(DISPLAY_DATE)
                    + " không tồn tại hoặc chưa được công bố kết quả.");
            return;
        }

        HttpSession session = req.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser != null && lengthOf(req.getParameter("ticketNumbers")) > MAX_INPUT_LENGTH) {
            showFormError(req, resp, "Dữ liệu nhập quá dài, vui lòng chỉ nhập tối đa "
                    + MAX_TICKET_NUMBERS + " số vé.");
            return;
        }
        List<String> ticketNumbers = extractTicketNumbers(req, currentUser != null);
        if (ticketNumbers.isEmpty()) {
            showFormError(req, resp, "Vui lòng nhập ít nhất 1 số vé số.");
            return;
        }
        if (ticketNumbers.size() > MAX_TICKET_NUMBERS) {
            showFormError(req, resp, "Mỗi lần chỉ được dò tối đa " + MAX_TICKET_NUMBERS
                    + " số vé (bạn đã nhập " + ticketNumbers.size() + " số).");
            return;
        }
        int expectedLength = "BAC".equals(company.getRegionCode()) ? 5 : 6;
        for (String number : ticketNumbers) {
            if (!ValidationUtil.isValidTicketNumber(number, expectedLength)) {
                showFormError(req, resp, "Số vé số \"" + abbreviate(number)
                        + "\" không hợp lệ. Số vé " + company.getCompanyName()
                        + " phải gồm đúng " + expectedLength + " chữ số.");
                return;
            }
        }

        List<LotteryPrize> prizes = prizeDAO.findByTicketId(ticket.getId());
        ticket.setPrizes(prizes);
        Map<String, Long> prizeAmounts = prizeConfigDAO.findAmountsByRegion(company.getRegionCode());

        List<LotteryCheckUtil.CheckResult> results = new ArrayList<>();
        long grandTotal = 0;
        for (String number : ticketNumbers) {
            LotteryCheckUtil.CheckResult result = LotteryCheckUtil.check(number, prizes, prizeAmounts);
            results.add(result);
            grandTotal += result.getTotalAmount();

            // Chi USER da dang nhap moi duoc luu lich su do ve
            if (currentUser != null) {
                LotteryHistory history = new LotteryHistory();
                history.setUserId(currentUser.getId());
                history.setTicketId(ticket.getId());
                history.setTicketNumber(result.getTicketNumber());
                history.setResultSummary(result.getSummary());
                history.setPrizeAmount(result.getPrizeAmount());
                historyDAO.insert(history);
            }
        }

        req.setAttribute("ticket", ticket);
        req.setAttribute("results", results);
        req.setAttribute("grandTotal", grandTotal);
        req.getRequestDispatcher("/WEB-INF/views/lottery/check-ticket.jsp").forward(req, resp);
    }

    /**
     * Lay danh sach so ve so tu request (khong lap). NO_USER chi lay 1 so (param "ticketNumber").
     * USER da dang nhap lay tu textarea "ticketNumbers" (moi dong hoac cach nhau boi dau phay).
     */
    private List<String> extractTicketNumbers(HttpServletRequest req, boolean isLoggedIn) {
        Set<String> numbers = new LinkedHashSet<>();
        if (!isLoggedIn) {
            String single = req.getParameter("ticketNumber");
            if (single != null && !single.isBlank()) {
                numbers.add(single.trim());
            }
            return new ArrayList<>(numbers);
        }
        String raw = req.getParameter("ticketNumbers");
        if (raw != null && !raw.isBlank()) {
            for (String part : raw.split("[\\r\\n,]+")) {
                if (!part.isBlank()) {
                    numbers.add(part.trim());
                }
            }
        }
        return new ArrayList<>(numbers);
    }

    private void showFormError(HttpServletRequest req, HttpServletResponse resp, String message)
            throws ServletException, IOException {
        req.setAttribute("error", message);
        req.getRequestDispatcher("/WEB-INF/views/lottery/check-ticket.jsp").forward(req, resp);
    }

    private static int lengthOf(String s) {
        return s == null ? 0 : s.length();
    }

    /** Rut gon chuoi nguoi dung nhap truoc khi dua vao thong bao loi. */
    private static String abbreviate(String s) {
        return s.length() > 12 ? s.substring(0, 12) + "..." : s;
    }
}
