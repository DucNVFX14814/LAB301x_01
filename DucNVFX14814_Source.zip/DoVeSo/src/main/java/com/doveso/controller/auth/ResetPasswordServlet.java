package com.doveso.controller.auth;

import com.doveso.bo.PasswordResetBO;
import com.doveso.bo.PasswordResetBOImpl;
import com.doveso.model.User;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * UC05: Quen mat khau (buoc 4-5): mo lien ket trong email -> nhap mat khau moi.
 * GET  /reset-password?token=... : kiem tra token va hien thi form mat khau moi
 * POST /reset-password           : goi PasswordResetBO luu mat khau moi (token chi dung duoc 1 lan)
 */
@WebServlet("/reset-password")
public class ResetPasswordServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/auth/reset-password.jsp";

    private final PasswordResetBO resetBO = PasswordResetBOImpl.newDefault();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        noStore(resp);
        String token = ValidationUtil.trimToEmpty(req.getParameter("token"));
        User user = resetBO.findUserByToken(token);
        if (user == null) {
            req.setAttribute("invalid", true);
        } else {
            req.setAttribute("token", token);
            req.setAttribute("resetEmail", user.getEmail());
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        noStore(resp);
        String token = ValidationUtil.trimToEmpty(req.getParameter("token"));

        PasswordResetBO.ResetResult result = resetBO.resetPassword(token, req.getParameter("password"),
                req.getParameter("confirmPassword"));

        switch (result.getStatus()) {
            case INVALID_TOKEN -> {
                req.setAttribute("invalid", true);
                req.getRequestDispatcher(VIEW).forward(req, resp);
            }
            case INVALID_INPUT -> {
                req.setAttribute("error", result.getError());
                req.setAttribute("token", token);
                req.setAttribute("resetEmail", result.getUser().getEmail());
                req.getRequestDispatcher(VIEW).forward(req, resp);
            }
            default -> {
                req.setAttribute("message", "Đặt lại mật khẩu thành công! Vui lòng đăng nhập.");
                req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
            }
        }
    }

    /** Trang chua token: khong cho luu cache va khong gui Referer sang trang khac. */
    private static void noStore(HttpServletResponse resp) {
        resp.setHeader("Cache-Control", "no-store");
        resp.setHeader("Referrer-Policy", "no-referrer");
    }
}
