package com.doveso.controller.auth;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;
import com.doveso.util.PasswordUtil;
import com.doveso.util.ResetTokenUtil;
import com.doveso.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * UC05: Quen mat khau (buoc 4-5): mo lien ket trong email -> nhap mat khau moi.
 * GET  /reset-password?token=... : kiem tra token va hien thi form mat khau moi
 * POST /reset-password           : luu mat khau moi (token chi dung duoc 1 lan)
 */
@WebServlet("/reset-password")
public class ResetPasswordServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/auth/reset-password.jsp";

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        noStore(resp);
        String token = trim(req.getParameter("token"));
        User user = token.isEmpty() ? null : userDAO.findByValidResetToken(ResetTokenUtil.hash(token));
        if (user == null) {
            req.setAttribute("invalid", true);
        } else {
            req.setAttribute("token", token);
            req.setAttribute("resetEmail", user.getEmail());
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        noStore(resp);
        String token = trim(req.getParameter("token"));
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");

        User user = token.isEmpty() ? null : userDAO.findByValidResetToken(ResetTokenUtil.hash(token));
        if (user == null) {
            req.setAttribute("invalid", true);
            req.getRequestDispatcher(VIEW).forward(req, resp);
            return;
        }

        String error = null;
        if (!ValidationUtil.isValidPassword(password)) {
            error = "Mật khẩu phải có ít nhất 6 ký tự.";
        } else if (!password.equals(confirmPassword)) {
            error = "Mật khẩu xác nhận không khớp.";
        }
        if (error != null) {
            req.setAttribute("error", error);
            req.setAttribute("token", token);
            req.setAttribute("resetEmail", user.getEmail());
            req.getRequestDispatcher(VIEW).forward(req, resp);
            return;
        }

        // Cap nhat mat khau va xoa token trong 1 cau UPDATE: thanh cong toi da 1 lan cho moi token
        boolean updated = userDAO.resetPasswordWithToken(ResetTokenUtil.hash(token), PasswordUtil.hash(password));
        if (!updated) {
            req.setAttribute("invalid", true);
            req.getRequestDispatcher(VIEW).forward(req, resp);
            return;
        }
        req.setAttribute("message", "Đặt lại mật khẩu thành công! Vui lòng đăng nhập.");
        req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
    }

    /** Trang chua token: khong cho luu cache va khong gui Referer sang trang khac. */
    private static void noStore(HttpServletResponse resp) {
        resp.setHeader("Cache-Control", "no-store");
        resp.setHeader("Referrer-Policy", "no-referrer");
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
