package com.doveso.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * 1 dong xem truoc khi them ve do (ADMIN): ung voi 1 cap (dai, ngay).
 * status: OK (san sang luu) | EXISTS (ve do da co trong CSDL) | ERROR (loi / khong co du lieu).
 * Khi companyCode = null la loi chung cua ca ngay (vd nguon chua co ket qua), khong gan voi dai cu the.
 */
public class TicketPreviewItem {

    public static final String OK = "OK";
    public static final String EXISTS = "EXISTS";
    public static final String ERROR = "ERROR";

    private final LocalDate date;
    private String companyCode;
    private String companyName;
    private String regionName;
    private String status;
    private String message;
    private List<LotteryPrize> prizes = new ArrayList<>();
    private Long existingTicketId;
    private boolean existingPublished;

    public TicketPreviewItem(LocalDate date, LotteryCompany company, String status) {
        this.date = date;
        this.status = status;
        if (company != null) {
            this.companyCode = company.getCompanyCode();
            this.companyName = company.getCompanyName();
            this.regionName = company.getRegionName();
        }
    }

    public LocalDate getDate() {
        return date;
    }

    public String getDateFormatted() {
        return date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getRegionName() {
        return regionName;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<LotteryPrize> getPrizes() {
        return prizes;
    }

    public void setPrizes(List<LotteryPrize> prizes) {
        this.prizes = prizes;
    }

    public Long getExistingTicketId() {
        return existingTicketId;
    }

    public void setExistingTicketId(Long existingTicketId) {
        this.existingTicketId = existingTicketId;
    }

    public boolean isExistingPublished() {
        return existingPublished;
    }

    public void setExistingPublished(boolean existingPublished) {
        this.existingPublished = existingPublished;
    }

    public boolean isOk() {
        return OK.equals(status);
    }
}
