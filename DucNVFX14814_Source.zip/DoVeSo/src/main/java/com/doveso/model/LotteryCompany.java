package com.doveso.model;

/** Entity anh xa bang `lottery_companies` (cong ty / dai xo so, vd 'mien-bac', 'tp-hcm'). */
public class LotteryCompany {

    private String companyCode;
    private String companyName;
    private String regionCode;
    private String regionName; // lay tu join lottery_regions, chi dung de hien thi
    private boolean active;

    public LotteryCompany() {
    }

    public LotteryCompany(String companyCode, String companyName, String regionCode) {
        this.companyCode = companyCode;
        this.companyName = companyName;
        this.regionCode = regionCode;
        this.active = true;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
