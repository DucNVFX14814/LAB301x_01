package com.doveso.model;

/**
 * Ket qua thong ke tan suat cua 1 so lo (2 chu so, "00".."99") tren toan bo cac ve do da PUBLISH.
 * Chuc nang 4 (*): Phan tich va de xuat so ve so nen mua.
 */
public class NumberStat {

    private final String number;     // "00".."99"
    private final int frequency;     // so lan xuat hien (tinh tren 2 chu so cuoi cua moi so trung giai)
    private final String lastSeenDrawDateFormatted; // dd/MM/yyyy, rong neu chua tung xuat hien
    private final int gapDraws;      // so ky quay so gan day nhat ma so nay CHUA ve (0 = vua ve ky gan nhat)

    public NumberStat(String number, int frequency, String lastSeenDrawDateFormatted, int gapDraws) {
        this.number = number;
        this.frequency = frequency;
        this.lastSeenDrawDateFormatted = lastSeenDrawDateFormatted;
        this.gapDraws = gapDraws;
    }

    public String getNumber() {
        return number;
    }

    public int getFrequency() {
        return frequency;
    }

    public String getLastSeenDrawDateFormatted() {
        return lastSeenDrawDateFormatted;
    }

    public boolean isNeverSeen() {
        return lastSeenDrawDateFormatted == null || lastSeenDrawDateFormatted.isEmpty();
    }

    public int getGapDraws() {
        return gapDraws;
    }
}
