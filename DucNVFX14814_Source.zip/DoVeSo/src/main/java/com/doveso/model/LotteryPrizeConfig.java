package com.doveso.model;

/**
 * Entity anh xa bang `lottery_prize_configs` - cau hinh gia tri 1 giai (VND) theo tung mien.
 * Dung de doi chieu tinh tien thuong khi thuc hien do ve so (Chuc nang 3), thay cho gia tri fix cung.
 */
public class LotteryPrizeConfig {

    private Long id;
    private String regionCode;  // 'BAC','TRUNG','NAM'
    private String prizeCode;   // 'DB','G1'..'G8'
    private String prizeName;   // 'Đặc biệt','Giải nhất'...
    private Long prizeAmount;   // gia tri giai (VND)

    public LotteryPrizeConfig() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getPrizeCode() {
        return prizeCode;
    }

    public void setPrizeCode(String prizeCode) {
        this.prizeCode = prizeCode;
    }

    public String getPrizeName() {
        return prizeName;
    }

    public void setPrizeName(String prizeName) {
        this.prizeName = prizeName;
    }

    public Long getPrizeAmount() {
        return prizeAmount;
    }

    public void setPrizeAmount(Long prizeAmount) {
        this.prizeAmount = prizeAmount;
    }
}
