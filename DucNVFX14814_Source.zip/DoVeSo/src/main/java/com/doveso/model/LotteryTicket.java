package com.doveso.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity anh xa bang `lottery_tickets` (ve do) trong co so du lieu.
 * Moi ve do gan voi 1 cong ty xo so (company_code) va 1 ngay quay so (draw_date).
 * Tuong ung Chuc nang 2 - Quan ly ve do trong tai lieu yeu cau du an.
 */
public class LotteryTicket {

    public static final String STATUS_UNPUBLISH = "UNPUBLISH";
    public static final String STATUS_PUBLISH = "PUBLISH";

    private Long id;
    private String companyCode;      // Ma cong ty xo so (lottery_companies.company_code)
    private String companyName;      // Ten cong ty (join, chi dung de hien thi)
    private String regionCode;       // Ma mien (join)
    private String regionName;       // Ten mien (join)
    private LocalDate drawDate;      // Ngay mo thuong
    private String status;           // UNPUBLISH | PUBLISH
    private Long createdBy;          // id ADMIN tao ve do
    private LocalDateTime createdAt;
    private List<LotteryPrize> prizes = new ArrayList<>(); // DB, G1..G7 (mien Bac) hoac DB, G1..G8 (mien Trung/Nam)

    public LotteryTicket() {
        this.status = STATUS_UNPUBLISH;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public LocalDate getDrawDate() {
        return drawDate;
    }

    public void setDrawDate(LocalDate drawDate) {
        this.drawDate = drawDate;
    }

    /** Dinh dang ngay quay so kieu dd/MM/yyyy de hien thi tren JSP (JSTL fmt khong doc duoc LocalDate). */
    public String getDrawDateFormatted() {
        return drawDate == null ? "" : drawDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isPublished() {
        return STATUS_PUBLISH.equals(status);
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public List<LotteryPrize> getPrizes() {
        return prizes;
    }

    public void setPrizes(List<LotteryPrize> prizes) {
        this.prizes = prizes;
    }

    /** Lay 1 giai theo ma giai (DB, G1..G8), tra ve null neu khong co. */
    public LotteryPrize getPrizeByCode(String code) {
        for (LotteryPrize p : prizes) {
            if (p.getPrizeCode().equals(code)) {
                return p;
            }
        }
        return null;
    }
}
