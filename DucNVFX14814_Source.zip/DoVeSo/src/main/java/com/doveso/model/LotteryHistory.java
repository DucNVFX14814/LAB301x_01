package com.doveso.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Entity anh xa bang `lottery_history` - luu lai lich su cac lan do ve so
 * cua USER da dang nhap. Tuong ung Chuc nang 3 - Thuc hien do ve so.
 * NO_USER khong duoc luu lich su nen userId luon khac null o day.
 */
public class LotteryHistory {

    private Long id;
    private Long userId;
    private Long ticketId;
    private String ticketNumber;  // day so tren to ve so nguoi dung nhap
    private String resultSummary; // vi du: "Trung Giai Ba", "Khong trung giai"
    private Long prizeAmount;     // so tien trung thuong (neu co), don vi VND
    private LocalDateTime checkedAt;

    // Cac truong bo sung khi join sang lottery_tickets/lottery_companies/lottery_regions, chi dung de hien thi
    private java.time.LocalDate drawDate;
    private String companyCode;
    private String companyName;
    private String regionName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getTicketId() {
        return ticketId;
    }

    public void setTicketId(Long ticketId) {
        this.ticketId = ticketId;
    }

    public String getTicketNumber() {
        return ticketNumber;
    }

    public void setTicketNumber(String ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public String getResultSummary() {
        return resultSummary;
    }

    public void setResultSummary(String resultSummary) {
        this.resultSummary = resultSummary;
    }

    public Long getPrizeAmount() {
        return prizeAmount;
    }

    public void setPrizeAmount(Long prizeAmount) {
        this.prizeAmount = prizeAmount;
    }

    public LocalDateTime getCheckedAt() {
        return checkedAt;
    }

    public void setCheckedAt(LocalDateTime checkedAt) {
        this.checkedAt = checkedAt;
    }

    public java.time.LocalDate getDrawDate() {
        return drawDate;
    }

    public void setDrawDate(java.time.LocalDate drawDate) {
        this.drawDate = drawDate;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    /** Dinh dang ngay quay so kieu dd/MM/yyyy de hien thi tren JSP. */
    public String getDrawDateFormatted() {
        return drawDate == null ? "" : drawDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    /** Dinh dang thoi diem do ve kieu dd/MM/yyyy HH:mm de hien thi tren JSP. */
    public String getCheckedAtFormatted() {
        return checkedAt == null ? "" : checkedAt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }
}
