package com.doveso.model;

import java.time.LocalDate;

/**
 * 1 dong du lieu tho: ngay quay so va chuoi so trung cua 1 giai (co the nhieu so cach nhau boi '-').
 * Dung rieng cho thong ke / de xuat so (Chuc nang 4), khong anh xa truc tiep 1 bang cu the.
 */
public class PrizeDrawRow {

    private final LocalDate drawDate;
    private final String prizeNumber;

    public PrizeDrawRow(LocalDate drawDate, String prizeNumber) {
        this.drawDate = drawDate;
        this.prizeNumber = prizeNumber;
    }

    public LocalDate getDrawDate() {
        return drawDate;
    }

    public String getPrizeNumber() {
        return prizeNumber;
    }
}
