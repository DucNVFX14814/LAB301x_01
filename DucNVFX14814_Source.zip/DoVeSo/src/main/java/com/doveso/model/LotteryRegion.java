package com.doveso.model;

/** Entity anh xa bang `lottery_regions` (mien: BAC, TRUNG, NAM). */
public class LotteryRegion {

    private String regionCode;
    private String regionName;

    public LotteryRegion() {
    }

    public LotteryRegion(String regionCode, String regionName) {
        this.regionCode = regionCode;
        this.regionName = regionName;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }
}
