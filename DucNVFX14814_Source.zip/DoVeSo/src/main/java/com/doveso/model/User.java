package com.doveso.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * Entity anh xa bang `users` trong co so du lieu.
 * Tuong ung Actor NO_USER (sau khi dang ky) / USER / ADMIN.
 */
public class User {

    private Long id;
    private String fullName;
    private String email;
    private String phone;
    private String passwordHash;
    private String role;        // "USER" | "ADMIN"
    private boolean active;     // true = duoc phep su dung he thong
    private LocalDateTime lastLoginAt;
    private LocalDateTime createdAt;

    public User() {
    }

    public User(String fullName, String email, String phone, String passwordHash) {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.passwordHash = passwordHash;
        this.role = "USER";
        this.active = true;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public LocalDateTime getLastLoginAt() {
        return lastLoginAt;
    }

    public void setLastLoginAt(LocalDateTime lastLoginAt) {
        this.lastLoginAt = lastLoginAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Thoi diem dang nhap gan nhat dang dd/MM/yyyy HH:mm:ss (dung cho tooltip), rong neu chua tung dang nhap.
     */
    public String getLastLoginAtFormatted() {
        return lastLoginAt == null ? "" : lastLoginAt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
    }

    /**
     * Dang nhap gan nhat theo kieu de doc: "Đã đăng nhập 15 phút trước" hoac "Chưa từng đăng nhập".
     */
    public String getLastLoginRelative() {
        if (lastLoginAt == null) {
            return "Chưa từng đăng nhập";
        }
        LocalDateTime now = LocalDateTime.now();
        long seconds = Math.max(0, ChronoUnit.SECONDS.between(lastLoginAt, now));
        if (seconds < 5) {
            return "Vừa đăng nhập";
        }
        String ago;
        if (seconds < 60) {
            ago = seconds + " giây";
        } else if (seconds < 3600) {
            ago = (seconds / 60) + " phút";
        } else if (seconds < 86400) {
            ago = (seconds / 3600) + " giờ";
        } else {
            long days = seconds / 86400;
            if (days < 7) {
                ago = days + " ngày";
            } else if (days < 30) {
                ago = (days / 7) + " tuần";
            } else {
                long months = ChronoUnit.MONTHS.between(lastLoginAt, now);
                ago = months < 12 ? Math.max(1, months) + " tháng" : ChronoUnit.YEARS.between(lastLoginAt, now) + " năm";
            }

        }
        return ago + " trước";
    }

    /**
     * Lay ten goi (tu cuoi cung trong ho ten) de hien thi ngan gon, vd "Nguyễn Việt Đức" -> "Đức".
     */
    public String getShortName() {
        if (fullName == null || fullName.isBlank()) {
            return "";
        }
        String trimmed = fullName.trim();
        int lastSpace = trimmed.lastIndexOf(' ');
        return lastSpace >= 0 ? trimmed.substring(lastSpace + 1) : trimmed;
    }
}