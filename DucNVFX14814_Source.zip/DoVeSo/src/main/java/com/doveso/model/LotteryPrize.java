package com.doveso.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Entity anh xa bang `lottery_ticket_items` - 1 dong ung voi 1 giai (DB, G1..G8)
 * cua 1 ve do (lottery_tickets). Truong prize_number co the chua nhieu so
 * cach nhau boi dau '-' (vi du G3 co 6 so: "10449-17020-...").
 * Tuong ung Chuc nang 2 - Quan ly ve do trong tai lieu yeu cau du an.
 */
public class LotteryPrize {

    /** Thu tu uu tien khi doi chieu ket qua (tu cao xuong thap). */
    public static final String[] PRIZE_ORDER = {"DB", "G1", "G2", "G3", "G4", "G5", "G6", "G7", "G8"};

    private Long id;
    private Long ticketId;
    private String prizeCode;   // 'DB','G1'..'G7'
    private String prizeName;   // 'Đặc biệt','Giải nhất'...
    private String prizeNumber; // vi du "10449-17020-70611"

    public LotteryPrize() {
    }

    public LotteryPrize(String prizeCode, String prizeName, String prizeNumber) {
        this.prizeCode = prizeCode;
        this.prizeName = prizeName;
        this.prizeNumber = prizeNumber;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTicketId() {
        return ticketId;
    }

    public void setTicketId(Long ticketId) {
        this.ticketId = ticketId;
    }

    public String getPrizeCode() {
        return prizeCode;
    }

    public void setPrizeCode(String prizeCode) {
        this.prizeCode = prizeCode;
    }

    public String getPrizeName() {
        return prizeName;
    }

    public void setPrizeName(String prizeName) {
        this.prizeName = prizeName;
    }

    public String getPrizeNumber() {
        return prizeNumber;
    }

    public void setPrizeNumber(String prizeNumber) {
        this.prizeNumber = prizeNumber;
    }

    /** Tach chuoi prizeNumber (vd "9977-5957-2580-2082") thanh danh sach so rieng le. */
    public List<String> getNumbers() {
        List<String> result = new ArrayList<>();
        if (prizeNumber == null || prizeNumber.isBlank()) {
            return result;
        }
        for (String n : prizeNumber.split("-")) {
            if (!n.isBlank()) {
                result.add(n.trim());
            }
        }
        return result;
    }
}
