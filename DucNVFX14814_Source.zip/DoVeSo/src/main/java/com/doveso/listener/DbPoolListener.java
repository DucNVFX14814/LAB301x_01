package com.doveso.listener;

import com.doveso.util.DBConnectionUtil;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Dong connection pool khi ung dung dung hoac redeploy tren Tomcat, tranh ro ri ket noi va luong nen cua pool.
 */
@WebListener
public class DbPoolListener implements ServletContextListener {

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        DBConnectionUtil.shutdown();
    }
}
