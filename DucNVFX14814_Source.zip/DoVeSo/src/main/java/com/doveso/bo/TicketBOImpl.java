package com.doveso.bo;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryPrizeDAO;
import com.doveso.dao.TicketDAO;
import com.doveso.dao.impl.CompanyDAOImpl;
import com.doveso.dao.impl.LotteryPrizeDAOImpl;
import com.doveso.dao.impl.TicketDAOImpl;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryRegion;
import com.doveso.model.LotteryTicket;
import com.doveso.model.TicketPreviewItem;
import com.doveso.model.User;
import com.doveso.util.LotteryFetchException;
import com.doveso.util.LotteryResultCache;
import com.doveso.util.LotteryResultSource;
import com.doveso.util.MinhNgocClient;
import com.doveso.util.MinhNgocResultSource;
import com.doveso.util.ValidationUtil;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cai dat TicketBO: gom logic nghiep vu ve do truoc day nam trong AdminTicketSupport va cac Servlet quan ly ve do.
 * Khong phu thuoc HttpServletRequest/Session; DAO va nguon ket qua xo so duoc truyen qua constructor de unit test
 * bang mock (khong can CSDL, khong can mang).
 *
 * Doi tuong nay co trang thai theo request (bo nho dem ket qua nguon, tinh duoc chon lay tu trang rieng) nen khong
 * dung chung giua cac request.
 */
public class TicketBOImpl implements TicketBO {

    private static final Logger LOG = Logger.getLogger(TicketBOImpl.class.getName());

    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final LocalDate MIN_DATE = LocalDate.of(2000, 1, 1);
    private static final LocalDate MAX_DATE = LocalDate.of(9999, 12, 31);
    /** Gioi han an toan so ngay xu ly 1 lan (cung thang nen toi da la 31, nhung chan them cho chac). */
    private static final int MAX_RANGE_DAYS = 31;

    private final CompanyDAO companyDAO;
    private final TicketDAO ticketDAO;
    private final LotteryPrizeDAO prizeDAO;
    private final LotteryResultSource source;

    /** Danh sach mien va dai dang hoat dong, nap 1 lan (khi can) cho 1 request. */
    private List<LotteryRegion> regions;
    private List<LotteryCompany> companies;

    /** Bo nho dem ket qua nguon trong 1 request, va tinh duoc chon lay tu trang rieng (null = dung trang mien). */
    private final LotteryResultCache cache = new LotteryResultCache();
    private LotteryCompany provinceCompany;

    public TicketBOImpl(CompanyDAO companyDAO, TicketDAO ticketDAO, LotteryPrizeDAO prizeDAO,
                        LotteryResultSource source) {
        this.companyDAO = companyDAO;
        this.ticketDAO = ticketDAO;
        this.prizeDAO = prizeDAO;
        this.source = source;
    }

    /** Tao BO voi DAO that va nguon Minh Ngoc (dung trong Servlet, 1 doi tuong cho moi request). */
    public static TicketBO newDefault() {
        return new TicketBOImpl(new CompanyDAOImpl(), new TicketDAOImpl(), new LotteryPrizeDAOImpl(),
                new MinhNgocResultSource());
    }

    // ---------------------------------------------------------------- danh muc mien / dai

    @Override
    public List<LotteryRegion> getRegions() {
        if (regions == null) {
            regions = companyDAO.findAllRegions();
        }
        return regions;
    }

    @Override
    public List<LotteryCompany> getCompanies() {
        if (companies == null) {
            companies = companyDAO.findActiveCompanies();
        }
        return companies;
    }

    @Override
    public boolean isValidRegion(String regionCode) {
        for (LotteryRegion r : getRegions()) {
            if (r.getRegionCode().equals(regionCode)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public LotteryCompany findCompany(String companyCode) {
        for (LotteryCompany c : getCompanies()) {
            if (c.getCompanyCode().equals(companyCode)) {
                return c;
            }
        }
        return null;
    }

    private List<LotteryCompany> companiesOfRegion(String regionCode) {
        List<LotteryCompany> result = new ArrayList<>();
        for (LotteryCompany c : getCompanies()) {
            if (c.getRegionCode().equals(regionCode)) {
                result.add(c);
            }
        }
        return result;
    }

    @Override
    public List<LotteryCompany> resolveTargets(String regionCode, String companyParam) {
        if (!isValidRegion(regionCode)) {
            return null;
        }
        if (ALL_COMPANIES.equals(companyParam)) {
            List<LotteryCompany> all = companiesOfRegion(regionCode);
            return all.isEmpty() ? null : all;
        }
        LotteryCompany c = findCompany(companyParam);
        if (c == null || !c.getRegionCode().equals(regionCode)) {
            return null;
        }
        return List.of(c);
    }

    // ---------------------------------------------------------------- UC10: them ve do

    @Override
    public String validateSingleDay(String regionCode, String companyParam, String dateParam) {
        if (resolveTargets(regionCode, companyParam) == null) {
            return "Vui lòng chọn miền và tỉnh hợp lệ.";
        }
        LocalDate date = ValidationUtil.parseIsoDate(dateParam);
        if (date == null) {
            return "Ngày không hợp lệ.";
        }
        if (date.isAfter(LocalDate.now())) {
            return "Không thể tạo vé dò cho ngày trong tương lai.";
        }
        return null;
    }

    @Override
    public String validateRange(LocalDate from, LocalDate to) {
        if (from == null || to == null) {
            return "Vui lòng chọn đầy đủ ngày bắt đầu và ngày kết thúc.";
        }
        if (from.isAfter(to)) {
            return "Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.";
        }
        if (to.isAfter(LocalDate.now())) {
            return "Không thể tạo vé dò cho ngày trong tương lai.";
        }
        if (from.getYear() != to.getYear() || from.getMonthValue() != to.getMonthValue()) {
            return "Khoảng ngày phải nằm trong cùng 1 tháng.";
        }
        if (ChronoUnit.DAYS.between(from, to) + 1 > MAX_RANGE_DAYS) {
            return "Khoảng ngày quá lớn, vui lòng chọn tối đa " + MAX_RANGE_DAYS + " ngày.";
        }
        return null;
    }

    @Override
    public List<TicketPreviewItem> previewDay(String regionCode, String companyParam, LocalDate date) {
        List<LotteryCompany> targets = resolveTargets(regionCode, companyParam);
        boolean allMode = ALL_COMPANIES.equals(companyParam);
        selectSource(regionCode, targets, allMode);
        return buildPreview(date, regionCode, targets, allMode, allMode);
    }

    @Override
    public List<TicketPreviewItem> previewRange(String regionCode, String companyParam, LocalDate from,
                                                LocalDate to) {
        List<LotteryCompany> targets = resolveTargets(regionCode, companyParam);
        boolean allMode = ALL_COMPANIES.equals(companyParam);
        selectSource(regionCode, targets, allMode);
        prefetch(regionCode, from, to);
        List<TicketPreviewItem> items = new ArrayList<>();
        for (LocalDate date = to; !date.isBefore(from); date = date.minusDays(1)) {
            // Ngay 1 tinh khong xo (vd Da Nang chi xo Thu Tu, Thu Bay) thi bo qua, khong tinh la loi
            items.addAll(buildPreview(date, regionCode, targets, allMode, true));
        }
        return items;
    }

    /**
     * Chon nguon lay du lieu cho request nay. Chon 1 tinh cu the cua mien Trung / Nam -> lay tu trang rieng cua
     * tinh do (moi trang cho 6 ky gan nhat, nhanh hon); cac truong hop con lai -> lay tu trang mien
     * (moi trang cho 7 ngay). Neu trang rieng cua tinh loi thi tu dong quay ve trang mien.
     */
    private void selectSource(String regionCode, List<LotteryCompany> selectedTargets, boolean allMode) {
        this.provinceCompany = (!allMode && !MinhNgocClient.REGION_BAC.equals(regionCode)
                && selectedTargets != null && selectedTargets.size() == 1) ? selectedTargets.get(0) : null;
    }

    /** Tai truoc cac trang nguon can de phu khoang [from, to], de vong lap tung ngay khong phai goi lai nguon. */
    private void prefetch(String regionCode, LocalDate from, LocalDate to) {
        if (provinceCompany != null) {
            LotteryCompany c = provinceCompany;
            cache.prefetch(provinceKey(c), from, to, d -> source.fetchProvincePage(c, d));
        } else {
            cache.prefetch(regionKey(regionCode), from, to, regionFetcher(regionCode));
        }
    }

    /**
     * Tao danh sach xem truoc cho ngay date. Tinh da co ve do -> EXISTS (khong lay lai tu nguon);
     * cac tinh con lai lay tu nguon: co du lieu -> OK, loi -> ERROR.
     *
     * @param allMode    true: nguoi dung chon "Tat ca tinh"; loi chung cua nguon chi bao 1 dong cho ca ngay
     * @param skipNoDraw true: tinh khong xo vao ngay do thi bo qua (khong tao dong); false: bao loi "khong mo thuong"
     */
    List<TicketPreviewItem> buildPreview(LocalDate date, String regionCode, List<LotteryCompany> targets,
                                         boolean allMode, boolean skipNoDraw) {
        List<TicketPreviewItem> items = new ArrayList<>();
        String pageError = null;

        for (LotteryCompany c : targets) {
            LotteryTicket existing = ticketDAO.findByCompanyAndDate(c.getCompanyCode(), date);
            if (existing != null) {
                TicketPreviewItem item = new TicketPreviewItem(date, c, TicketPreviewItem.EXISTS);
                item.setExistingTicketId(existing.getId());
                item.setExistingPublished(existing.isPublished());
                item.setPrizes(TicketBO.sortPrizes(prizeDAO.findByTicketId(existing.getId())));
                items.add(item);
                continue;
            }
            Outcome o = lookup(c, date, regionCode);
            if (o.prizes != null) {
                TicketPreviewItem item = new TicketPreviewItem(date, c, TicketPreviewItem.OK);
                item.setPrizes(TicketBO.sortPrizes(new ArrayList<>(o.prizes)));
                items.add(item);
            } else if (o.error != null) {
                if (o.pageLevel && allMode) {
                    pageError = o.error;
                } else {
                    items.add(errorItem(date, c, o.error));
                }
            } else if (!skipNoDraw) {
                items.add(errorItem(date, c, "Tỉnh " + c.getCompanyName() + " không mở thưởng ngày "
                        + date.format(DISPLAY_DATE) + "."));
            }
        }

        if (pageError != null) {
            items.add(errorItem(date, null, pageError));
        } else if (items.isEmpty() && !skipNoDraw) {
            items.add(errorItem(date, null, "Không có tỉnh nào trong hệ thống mở thưởng ngày "
                    + date.format(DISPLAY_DATE) + "."));
        }
        return items;
    }

    /** Ket qua tra cuu 1 tinh trong 1 ngay: co du lieu (prizes), loi (error), hoac khong xo (ca 2 deu null). */
    private static final class Outcome {
        List<LotteryPrize> prizes;
        String error;
        boolean pageLevel; // loi cua ca trang nguon (khong ket noi, chua co ket qua...) chu khong rieng tinh nay
    }

    private Outcome lookup(LotteryCompany c, LocalDate date, String regionCode) {
        Outcome o = new Outcome();
        if (provinceCompany != null && provinceCompany.getCompanyCode().equals(c.getCompanyCode())) {
            try {
                MinhNgocClient.RegionResult r = cache.get(provinceKey(c), date,
                        d -> source.fetchProvincePage(c, d));
                if (r != null) {
                    fill(o, r, c.getCompanyCode());
                }
                return o; // r == null: trang rieng cua tinh khong co ky nay = tinh khong xo ngay do
            } catch (LotteryFetchException e) {
                // Trang rieng cua tinh khong dung duoc (sai slug, loi mang...): quay ve trang mien
            }
        }
        try {
            MinhNgocClient.RegionResult r = cache.get(regionKey(regionCode), date, regionFetcher(regionCode));
            if (r == null) {
                o.error = "Nguồn dữ liệu chưa có kết quả xổ số " + MinhNgocClient.regionLabel(regionCode)
                        + " ngày " + date.format(DISPLAY_DATE) + ".";
                o.pageLevel = true;
            } else {
                fill(o, r, c.getCompanyCode());
            }
        } catch (LotteryFetchException e) {
            o.error = e.getMessage();
            o.pageLevel = true;
        }
        return o;
    }

    private static void fill(Outcome o, MinhNgocClient.RegionResult r, String companyCode) {
        if (r.getPrizes().containsKey(companyCode)) {
            o.prizes = r.getPrizes().get(companyCode);
        } else if (r.getErrors().containsKey(companyCode)) {
            o.error = r.getErrors().get(companyCode);
        }
    }

    private LotteryResultCache.Fetcher regionFetcher(String regionCode) {
        return d -> source.fetchRegionPage(regionCode, d, companiesOfRegion(regionCode));
    }

    private static String regionKey(String regionCode) {
        return "REGION:" + regionCode;
    }

    private static String provinceKey(LotteryCompany c) {
        return "PROVINCE:" + c.getCompanyCode();
    }

    private static TicketPreviewItem errorItem(LocalDate date, LotteryCompany c, String message) {
        TicketPreviewItem item = new TicketPreviewItem(date, c, TicketPreviewItem.ERROR);
        item.setMessage(message);
        return item;
    }

    @Override
    public void saveOkItems(List<TicketPreviewItem> items, User admin, boolean publish,
                            List<Long> savedIds, List<String> failed) {
        for (TicketPreviewItem item : items) {
            if (!item.isOk()) {
                continue;
            }
            try {
                LotteryTicket ticket = new LotteryTicket();
                ticket.setCompanyCode(item.getCompanyCode());
                ticket.setDrawDate(item.getDate());
                ticket.setCreatedBy(admin.getId());
                savedIds.add(ticketDAO.insertWithPrizes(ticket, item.getPrizes(), publish));
            } catch (RuntimeException e) {
                failed.add(item.getCompanyName() + " " + item.getDateFormatted());
            }
        }
    }

    @Override
    public FlashResult saveBatch(User admin, String regionCode, String companyParam, String[] pairParams,
                                 boolean publish) {
        if (pairParams == null || pairParams.length == 0) {
            return new FlashResult(null, "Không có vé dò nào để lưu.");
        }
        // Gom cac dai theo ngay de moi ngay chi lay du lieu tu nguon 1 lan
        Map<LocalDate, List<LotteryCompany>> byDate = new LinkedHashMap<>();
        for (String pair : pairParams) {
            String[] parts = pair.split("\\|");
            LocalDate date = parts.length == 2 ? ValidationUtil.parseIsoDate(parts[1]) : null;
            LotteryCompany company = parts.length == 2 ? findCompany(parts[0]) : null;
            if (date == null || company == null || !company.getRegionCode().equals(regionCode)) {
                continue;
            }
            byDate.computeIfAbsent(date, d -> new ArrayList<>()).add(company);
        }

        if (byDate.isEmpty()) {
            return new FlashResult(null, "Không có vé dò nào để lưu.");
        }
        // Tai truoc cac trang nguon can thiet (giong luc xem truoc) de khong phai goi nguon cho tung ngay
        selectSource(regionCode, resolveTargets(regionCode, companyParam), ALL_COMPANIES.equals(companyParam));
        LocalDate minDate = Collections.min(byDate.keySet());
        LocalDate maxDate = Collections.max(byDate.keySet());
        if (!maxDate.isAfter(LocalDate.now())) {
            prefetch(regionCode, minDate, maxDate);
        }

        List<Long> savedIds = new ArrayList<>();
        List<String> failed = new ArrayList<>();
        for (Map.Entry<LocalDate, List<LotteryCompany>> e : byDate.entrySet()) {
            LocalDate date = e.getKey();
            if (date.isAfter(LocalDate.now())) {
                failed.add(date.format(DISPLAY_DATE) + " (ngày trong tương lai)");
                continue;
            }
            List<TicketPreviewItem> items = buildPreview(date, regionCode, e.getValue(), false, false);
            saveOkItems(items, admin, publish, savedIds, failed);
            for (TicketPreviewItem item : items) {
                if (TicketPreviewItem.ERROR.equals(item.getStatus())) {
                    failed.add((item.getCompanyName() == null ? "" : item.getCompanyName() + " ")
                            + item.getDateFormatted());
                }
            }
        }

        String success = null;
        String error = null;
        if (!savedIds.isEmpty()) {
            success = "Đã lưu" + (publish ? " và công bố " : " ") + savedIds.size() + " vé dò.";
        }
        if (!failed.isEmpty()) {
            error = "Không lưu được " + failed.size() + " vé dò: " + String.join(", ", failed);
        } else if (savedIds.isEmpty()) {
            error = "Không có vé dò nào được lưu.";
        }
        return new FlashResult(success, error);
    }

    @Override
    public FlashResult publishExisting(String[] idParams) {
        if (idParams == null || idParams.length == 0) {
            return new FlashResult(null, "Không có vé dò nào cần công bố.");
        }
        int publishedCount = 0;
        List<String> failedIds = new ArrayList<>();
        for (String idParam : idParams) {
            try {
                Long id = Long.valueOf(idParam);
                ticketDAO.publish(id);
                publishedCount++;
            } catch (NumberFormatException e) {
                // bo qua id khong hop le
            } catch (RuntimeException e) {
                LOG.log(Level.SEVERE, "Loi publish ve do id=" + idParam, e);
                failedIds.add(idParam);
            }
        }
        String success = null;
        String error = null;
        if (publishedCount > 0) {
            success = "Đã công bố " + publishedCount + " vé dò.";
        }
        if (!failedIds.isEmpty()) {
            error = "Không công bố được " + failedIds.size() + " vé dò.";
        } else if (publishedCount == 0) {
            error = "Không có vé dò nào được công bố.";
        }
        return new FlashResult(success, error);
    }

    // ---------------------------------------------------------------- UC11: tim kiem + phan trang

    @Override
    public TicketSearchResult search(String regionRaw, String companyRaw, String statusRaw, String fromRaw,
                                     String toRaw, String pageRaw) {
        String region = ValidationUtil.trimToEmpty(regionRaw);
        String company = ValidationUtil.trimToEmpty(companyRaw);
        String status = ValidationUtil.trimToEmpty(statusRaw);
        String fromParam = ValidationUtil.trimToEmpty(fromRaw);
        String toParam = ValidationUtil.trimToEmpty(toRaw);
        boolean firstVisit = regionRaw == null && companyRaw == null && fromParam.isEmpty() && toParam.isEmpty();
        if (fromParam.isEmpty() && toParam.isEmpty()) {
            LocalDate today = LocalDate.now();
            fromParam = today.withDayOfMonth(1).toString();
            toParam = today.toString();
        }
        if (firstVisit) {
            region = "";
            company = "";
        }

        LocalDate from = ValidationUtil.parseIsoDate(fromParam);
        LocalDate to = ValidationUtil.parseIsoDate(toParam);
        String error = null;
        if ((!fromParam.isEmpty() && from == null) || (!toParam.isEmpty() && to == null)) {
            error = "Ngày tìm kiếm không hợp lệ.";
        } else if (from != null && to != null && from.isAfter(to)) {
            error = "Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.";
        } else if (!region.isEmpty() && !isValidRegion(region)) {
            error = "Miền không hợp lệ.";
        } else if (!company.isEmpty() && findCompany(company) == null) {
            error = "Tỉnh không hợp lệ.";
        } else if (!status.isEmpty() && !LotteryTicket.STATUS_PUBLISH.equals(status)
                && !LotteryTicket.STATUS_UNPUBLISH.equals(status)) {
            error = "Trạng thái không hợp lệ.";
        }

        List<LotteryTicket> tickets = new ArrayList<>();
        long total = 0;
        int totalPages = 0;
        int page = 1;
        if (error == null) {
            LocalDate searchFrom = (from != null) ? from : MIN_DATE;
            LocalDate searchTo = (to != null) ? to : MAX_DATE;
            total = ticketDAO.count(region, company, searchFrom, searchTo, status);
            totalPages = (int) Math.ceil((double) total / PAGE_SIZE);
            page = parsePage(pageRaw);
            page = Math.min(Math.max(page, 1), Math.max(totalPages, 1));
            tickets = ticketDAO.search(region, company, searchFrom, searchTo, status, page, PAGE_SIZE);
        }
        return new TicketSearchResult(region, company, status, fromParam, toParam, error, tickets, total,
                totalPages, page);
    }

    private static int parsePage(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 1;
        }
    }

    // ---------------------------------------------------------------- UC12: publish

    @Override
    public PublishResult publish(Long ticketId) {
        LotteryTicket ticket = (ticketId == null) ? null : ticketDAO.findById(ticketId);

        if (ticket == null) {
            return new PublishResult(false, null, "Không tìm thấy vé dò cần công bố.");
        }
        if (ticket.isPublished()) {
            return new PublishResult(true, null, "Vé dò ngày " + ticket.getDrawDateFormatted()
                    + " đã được công bố, không thể thay đổi trạng thái.");
        }
        try {
            ticketDAO.publish(ticketId);
            return new PublishResult(true, "Đã công bố vé dò ngày " + ticket.getDrawDateFormatted() + ".", null);
        } catch (RuntimeException e) {
            LOG.log(Level.SEVERE, "Loi publish ve do id=" + ticketId, e);
            return new PublishResult(true, null, "Không thể công bố vé dò, vui lòng thử lại.");
        }
    }

    // ---------------------------------------------------------------- UC13: chi tiet + so lan do

    @Override
    public TicketDetail getDetail(Long ticketId) {
        LotteryTicket ticket = (ticketId == null) ? null : ticketDAO.findById(ticketId);
        if (ticket == null) {
            return null;
        }
        List<LotteryPrize> prizes = TicketBO.sortPrizes(prizeDAO.findByTicketId(ticketId));
        return new TicketDetail(ticket, prizes, ticketDAO.countDrawTimes(ticketId));
    }
}
