package com.doveso.bo;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;
import com.doveso.util.MailUtilResetMailSender;
import com.doveso.util.PasswordUtil;
import com.doveso.util.ResetMailSender;
import com.doveso.util.ResetTokenUtil;
import com.doveso.util.ValidationUtil;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.ForkJoinPool;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cai dat PasswordResetBO. Gui email o luong nen (executor) de khong bat nguoi dung cho ket noi SMTP;
 * loi gui (sai App Password, mat mang...) duoc ghi vao log. Khong phu thuoc HttpServletRequest nen unit test
 * duoc bang mock UserDAO va ResetMailSender (dung executor chay dong bo).
 */
public class PasswordResetBOImpl implements PasswordResetBO {

    private static final Logger LOG = Logger.getLogger(PasswordResetBOImpl.class.getName());

    private final UserDAO userDAO;
    private final ResetMailSender mailSender;
    private final Executor executor;

    public PasswordResetBOImpl(UserDAO userDAO, ResetMailSender mailSender, Executor executor) {
        this.userDAO = userDAO;
        this.mailSender = mailSender;
        this.executor = executor;
    }

    /** Tao BO voi DAO that, gui mail bang MailUtil, chay nen tren ForkJoinPool chung (dung trong Servlet). */
    public static PasswordResetBO newDefault() {
        return new PasswordResetBOImpl(new UserDAOImpl(), new MailUtilResetMailSender(),
                ForkJoinPool.commonPool());
    }

    @Override
    public BoResult<Void> requestReset(String email, String fallbackBaseUrl) {
        if (ValidationUtil.isBlank(email) || !ValidationUtil.isValidEmail(email)) {
            return BoResult.fail("Email không hợp lệ.");
        }

        User user = userDAO.findByEmail(email);
        if (user == null) {
            LOG.info("Yeu cau quen mat khau voi email khong ton tai: " + email);
        } else if (!user.isActive()) {
            LOG.info("Yeu cau quen mat khau cho tai khoan da bi khoa, userId=" + user.getId());
        } else if (!mailSender.isConfigured()) {
            LOG.warning("Chua cau hinh mail.username / mail.password trong mail.properties");
        } else {
            try {
                sendResetEmail(user, fallbackBaseUrl);
            } catch (RuntimeException e) {
                LOG.log(Level.SEVERE, "Loi xu ly yeu cau quen mat khau cho userId=" + user.getId(), e);
            }
        }
        return BoResult.ok(null);
    }

    /** Tao token, luu (da bam) va gui email dat lai mat khau cho user o luong nen. */
    private void sendResetEmail(User user, String fallbackBaseUrl) {
        String token = ResetTokenUtil.generateToken();
        LocalDateTime expireAt = LocalDateTime.now().plusMinutes(ResetTokenUtil.EXPIRE_MINUTES);
        // CSDL chi luu ban bam cua token; token goc chi nam trong lien ket gui qua email
        userDAO.saveResetToken(user.getId(), ResetTokenUtil.hash(token), expireAt);

        String baseUrl = mailSender.getConfiguredBaseUrl();
        if (baseUrl == null) {
            baseUrl = fallbackBaseUrl;
        }
        final String link = baseUrl + "/reset-password?token=" + token;
        final String toEmail = user.getEmail();
        final String fullName = user.getFullName();
        final Long userId = user.getId();

        CompletableFuture.runAsync(() -> {
            try {
                mailSender.sendResetPasswordMail(toEmail, fullName, link, ResetTokenUtil.EXPIRE_MINUTES);
            } catch (Exception e) {
                LOG.log(Level.SEVERE, "Loi gui email dat lai mat khau cho userId=" + userId, e);
            }
        }, executor);
    }

    @Override
    public User findUserByToken(String token) {
        String trimmed = ValidationUtil.trimToEmpty(token);
        return trimmed.isEmpty() ? null : userDAO.findByValidResetToken(ResetTokenUtil.hash(trimmed));
    }

    @Override
    public ResetResult resetPassword(String token, String password, String confirmPassword) {
        String trimmed = ValidationUtil.trimToEmpty(token);
        User user = findUserByToken(trimmed);
        if (user == null) {
            return new ResetResult(Status.INVALID_TOKEN, null, null);
        }

        String error = null;
        if (!ValidationUtil.isValidPassword(password)) {
            error = "Mật khẩu phải có ít nhất 6 ký tự.";
        } else if (!password.equals(confirmPassword)) {
            error = "Mật khẩu xác nhận không khớp.";
        }
        if (error != null) {
            return new ResetResult(Status.INVALID_INPUT, error, user);
        }

        // Cap nhat mat khau va xoa token trong 1 cau UPDATE: thanh cong toi da 1 lan cho moi token
        boolean updated = userDAO.resetPasswordWithToken(ResetTokenUtil.hash(trimmed), PasswordUtil.hash(password));
        if (!updated) {
            return new ResetResult(Status.INVALID_TOKEN, null, null);
        }
        return new ResetResult(Status.SUCCESS, null, user);
    }
}
