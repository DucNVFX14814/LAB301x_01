package com.doveso.bo;

import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryRegion;
import com.doveso.model.LotteryTicket;
import com.doveso.model.User;
import com.doveso.util.LotteryCheckUtil;

import java.util.List;

/**
 * Tang nghiep vu (Business Object) cua Chuc nang 3: Thuc hien do ve so.
 * NO_USER: chi do 1 to ve, khong luu lich su. USER: do 1 hoac nhieu to (toi da MAX_TICKET_NUMBERS), ket qua duoc
 * luu vao lich su. ADMIN khong ho tro chuc nang nay (chan boi AdminCheckTicketBlockFilter).
 * Business rule: chi do duoc khi ve do da o trang thai PUBLISH.
 */
public interface LotteryCheckBO {

    /** So to ve toi da duoc do trong 1 lan (USER). */
    int MAX_TICKET_NUMBERS = 20;

    /** Gioi han do dai du lieu nhap (20 so + dau phan cach) de tranh xu ly chuoi qua lon. */
    int MAX_INPUT_LENGTH = 2000;

    /** Danh sach mien cho form chon tinh. */
    List<LotteryRegion> getRegions();

    /** Danh sach dai xo so dang hoat dong cho form chon tinh. */
    List<LotteryCompany> getCompanies();

    /** Ket qua 1 lan do: loi (error != null) hoac ve do + danh sach ket qua tung to + tong tien trung. */
    class CheckOutcome {
        private final String error;
        private final LotteryCompany company;
        private final LotteryTicket ticket;
        private final List<LotteryCheckUtil.CheckResult> results;
        private final long grandTotal;

        public CheckOutcome(String error, LotteryCompany company, LotteryTicket ticket,
                            List<LotteryCheckUtil.CheckResult> results, long grandTotal) {
            this.error = error;
            this.company = company;
            this.ticket = ticket;
            this.results = results;
            this.grandTotal = grandTotal;
        }

        /** Thong bao loi (tieng Viet), null neu do thanh cong. */
        public String getError() {
            return error;
        }

        /** Dai xo so da chon (null neu ma dai khong hop le) - dung de echo lai mien da chon tren form. */
        public LotteryCompany getCompany() {
            return company;
        }

        public LotteryTicket getTicket() {
            return ticket;
        }

        public List<LotteryCheckUtil.CheckResult> getResults() {
            return results;
        }

        public long getGrandTotal() {
            return grandTotal;
        }
    }

    /**
     * Do ve so.
     *
     * @param companyCode      ma dai xo so da chon
     * @param drawDateStr      ngay quay so dang yyyy-MM-dd
     * @param singleNumber     so ve nhap o o 1 so (NO_USER)
     * @param multiNumbersRaw  cac so ve nhap o textarea, moi dong hoac cach nhau boi dau phay (USER)
     * @param currentUser      nguoi dung dang nhap, null neu chua dang nhap (NO_USER)
     */
    CheckOutcome check(String companyCode, String drawDateStr, String singleNumber, String multiNumbersRaw,
                       User currentUser);
}
