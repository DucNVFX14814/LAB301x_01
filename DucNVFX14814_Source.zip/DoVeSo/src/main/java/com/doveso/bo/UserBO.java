package com.doveso.bo;

import com.doveso.model.User;

import java.util.List;

/**
 * Tang nghiep vu (Business Object) cua Chuc nang 1: Quan ly nguoi dung.
 * Chua cac quy tac nghiep vu (xac thuc dang nhap, dang ky, doi mat khau, quy tac cap quyen/khoa tai khoan)
 * va goi tang DAO; Controller (Servlet) chi doc request, goi BO roi chuyen ket qua sang JSP.
 * UC01, UC02, UC04, UC06, UC07, UC08, UC09 trong HV_SRS.
 */
public interface UserBO {

    /** So nguoi dung moi trang cua man hinh quan ly nguoi dung (UC09). */
    int PAGE_SIZE = 20;

    /**
     * UC02: Dang nhap. Kiem tra email/mat khau truoc, roi toi trang thai khoa; thanh cong thi cap nhat
     * thoi diem dang nhap gan nhat.
     *
     * @return thanh cong: gia tri la User da dang nhap; that bai: thong bao loi
     */
    BoResult<User> login(String email, String password);

    /**
     * UC01: Dang ky tai khoan moi voi ROLE = USER (kiem tra dinh dang, trung email, trung so dien thoai).
     */
    BoResult<Void> register(String fullName, String email, String phone, String password, String confirmPassword);

    /**
     * UC04: Doi mat khau cua nguoi dung userId (doc lai tu CSDL de lay ma bam moi nhat).
     */
    BoResult<Void> changePassword(Long userId, String currentPassword, String newPassword, String confirmPassword);

    /** 1 thay doi duoc yeu cau cho 1 nguoi dung: ROLE moi va trang thai (active) moi. */
    class RoleChange {
        private final Long userId;
        private final String newRole;
        private final boolean newActive;

        public RoleChange(Long userId, String newRole, boolean newActive) {
            this.userId = userId;
            this.newRole = newRole;
            this.newActive = newActive;
        }

        public Long getUserId() {
            return userId;
        }

        public String getNewRole() {
            return newRole;
        }

        public boolean isNewActive() {
            return newActive;
        }
    }

    /**
     * UC06/UC09: Luu hang loat thay doi ROLE + trang thai. Doi chieu voi du lieu THUC TE trong CSDL (khong tin
     * du lieu client) theo 3 quy tac: (1) khong khoa/ha quyen tai khoan ADMIN, (2) tai khoan dang bi khoa khong
     * duoc doi ROLE, (3) chi ADMIN chinh moi duoc cap quyen ADMIN. Co BAT KY vi pham nao thi HUY TOAN BO
     * (khong ghi thay doi nao) va tra ve thong bao loi.
     *
     * @param requester tai khoan ADMIN dang thuc hien
     */
    BoResult<Void> updateRoleAndStatus(User requester, List<RoleChange> changes);

    /** 1 trang ket qua tim kiem / loc nguoi dung (UC06, UC09). */
    class UserPage {
        private final List<User> users;
        private final long total;
        private final int totalPages;
        private final String noLoginFor;

        public UserPage(List<User> users, long total, int totalPages, String noLoginFor) {
            this.users = users;
            this.total = total;
            this.totalPages = totalPages;
            this.noLoginFor = noLoginFor;
        }

        public List<User> getUsers() {
            return users;
        }

        public long getTotal() {
            return total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        /** Ma loc thoi gian khong dang nhap da duoc chuan hoa ("" neu khong loc hoac ma khong hop le). */
        public String getNoLoginFor() {
            return noLoginFor;
        }
    }

    /**
     * UC06/UC09: Tim kiem va phan trang danh sach nguoi dung (PAGE_SIZE nguoi/trang).
     *
     * @param noLoginFor "" = tat ca; 1d / 1w / 1m / 1q / 1y = khong dang nhap trong khoang do; never = chua tung dang nhap
     */
    UserPage search(String keyword, String noLoginFor, int page);
}
