package com.doveso.bo;

/**
 * Ket qua tra ve tu tang BO: thanh cong (kem gia tri tuy chon) hoac that bai (kem thong bao loi tieng Viet
 * de Controller hien thi cho nguoi dung). Tranh viec BO phai nem exception cho cac loi nghiep vu thong thuong.
 *
 * @param <T> kieu gia tri tra ve khi thanh cong (dung Void/null neu khong co)
 */
public final class BoResult<T> {

    private final T value;
    private final String error;

    private BoResult(T value, String error) {
        this.value = value;
        this.error = error;
    }

    public static <T> BoResult<T> ok(T value) {
        return new BoResult<>(value, null);
    }

    public static <T> BoResult<T> fail(String error) {
        return new BoResult<>(null, error);
    }

    public boolean isOk() {
        return error == null;
    }

    /** Gia tri khi thanh cong (co the null neu thao tac khong co gia tri tra ve). */
    public T getValue() {
        return value;
    }

    /** Thong bao loi khi that bai, null neu thanh cong. */
    public String getError() {
        return error;
    }
}
