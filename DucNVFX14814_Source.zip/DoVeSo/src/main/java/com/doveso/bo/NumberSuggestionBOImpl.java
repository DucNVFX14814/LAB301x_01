package com.doveso.bo;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.NumberStatDAO;
import com.doveso.dao.impl.CompanyDAOImpl;
import com.doveso.dao.impl.NumberStatDAOImpl;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryRegion;
import com.doveso.model.PrizeDrawRow;
import com.doveso.util.NumberSuggestionUtil;
import com.doveso.util.ValidationUtil;

import java.util.List;

/** Cai dat NumberSuggestionBO; khong phu thuoc HttpServletRequest nen unit test duoc bang mock DAO. */
public class NumberSuggestionBOImpl implements NumberSuggestionBO {

    private final NumberStatDAO statDAO;
    private final CompanyDAO companyDAO;

    public NumberSuggestionBOImpl(NumberStatDAO statDAO, CompanyDAO companyDAO) {
        this.statDAO = statDAO;
        this.companyDAO = companyDAO;
    }

    /** Tao BO voi DAO that (dung trong Servlet). */
    public static NumberSuggestionBO newDefault() {
        return new NumberSuggestionBOImpl(new NumberStatDAOImpl(), new CompanyDAOImpl());
    }

    @Override
    public List<LotteryRegion> getRegions() {
        return companyDAO.findAllRegions();
    }

    @Override
    public List<LotteryCompany> getCompanies() {
        return companyDAO.findActiveCompanies();
    }

    @Override
    public Suggestion suggest(String companyCodeRaw) {
        String companyCode = ValidationUtil.trimToEmpty(companyCodeRaw);
        if (companyCode.isEmpty()) {
            return new Suggestion(null, null, null);
        }
        LotteryCompany company = companyDAO.findByCode(companyCode);
        if (company == null || !company.isActive()) {
            return new Suggestion("Vui lòng chọn tỉnh xổ số hợp lệ.", null, null);
        }
        List<PrizeDrawRow> rows = statDAO.findAllPublishedPrizeNumbers(companyCode);
        return new Suggestion(null, company, NumberSuggestionUtil.analyze(rows, TOP_N));
    }
}
