package com.doveso.bo;

import com.doveso.model.User;

/**
 * Quy tac "ADMIN chinh": chi tai khoan co id = ID moi duoc thang cap nguoi khac len ADMIN
 * (UpdateUsersServlet) va dung chuc nang them ve do hang loat (TicketBatchCreateServlet).
 * Dat o 1 cho de 2 noi dung chung 1 quy tac.
 */
public final class MasterAdmin {

    /** Id cua ADMIN chinh (theo du lieu mau trong database/schema.sql). */
    public static final long ID = 10000000L;

    private MasterAdmin() {
        // Chi dung phuong thuc static
    }

    /** true neu user la ADMIN chinh. */
    public static boolean is(User user) {
        return user != null && user.getId() != null && user.getId() == ID;
    }
}
