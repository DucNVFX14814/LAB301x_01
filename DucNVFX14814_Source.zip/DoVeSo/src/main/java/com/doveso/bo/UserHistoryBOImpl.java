package com.doveso.bo;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryHistoryDAO;
import com.doveso.dao.impl.CompanyDAOImpl;
import com.doveso.dao.impl.LotteryHistoryDAOImpl;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryHistory;
import com.doveso.model.LotteryRegion;
import com.doveso.util.ValidationUtil;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

/** Cai dat UserHistoryBO; khong phu thuoc HttpServletRequest nen unit test duoc bang mock DAO. */
public class UserHistoryBOImpl implements UserHistoryBO {

    private final LotteryHistoryDAO historyDAO;
    private final CompanyDAO companyDAO;

    public UserHistoryBOImpl(LotteryHistoryDAO historyDAO, CompanyDAO companyDAO) {
        this.historyDAO = historyDAO;
        this.companyDAO = companyDAO;
    }

    /** Tao BO voi DAO that (dung trong Servlet). */
    public static UserHistoryBO newDefault() {
        return new UserHistoryBOImpl(new LotteryHistoryDAOImpl(), new CompanyDAOImpl());
    }

    @Override
    public List<LotteryRegion> getRegions() {
        return companyDAO.findAllRegions();
    }

    @Override
    public List<LotteryCompany> getCompanies() {
        return companyDAO.findActiveCompanies();
    }

    @Override
    public HistoryPage getHistory(Long userId, String regionRaw, String companyRaw, String fromRaw, String toRaw,
                                  String pageRaw) {
        return getHistory(userId, regionRaw, companyRaw, fromRaw, toRaw, pageRaw, LocalDate.now());
    }

    /** Nhu tren nhung cho truoc "hom nay" (de unit test khong phu thuoc ngay chay test). */
    HistoryPage getHistory(Long userId, String regionRaw, String companyRaw, String fromRaw, String toRaw,
                           String pageRaw, LocalDate today) {
        int page = 1;
        try {
            page = Integer.parseInt(pageRaw);
        } catch (NumberFormatException ignored) {
            // giu gia tri mac dinh page = 1
        }

        // Bo loc mien/cong ty: tuy chon, khong bat buoc chon (rong = xem tat ca).
        String region = ValidationUtil.trimToEmpty(regionRaw);
        String company = ValidationUtil.trimToEmpty(companyRaw);

        LocalDate fromDate = parseDate(fromRaw, today.withDayOfMonth(1));
        LocalDate toDate = parseDate(toRaw, today);
        if (toDate.isAfter(today)) {
            toDate = today;
        }
        if (fromDate.isAfter(toDate)) {
            fromDate = toDate;
        }

        long total = historyDAO.countByUserId(userId, region, company, fromDate, toDate);
        int totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        // Dua so trang ve khoang hop le (tranh trang rong khi ?page vuot qua so trang)
        page = Math.min(Math.max(page, 1), totalPages);

        List<LotteryHistory> history = historyDAO.findByUserId(userId, region, company, fromDate, toDate, page,
                PAGE_SIZE);
        return new HistoryPage(region, company, today, fromDate, toDate, history, total, page, totalPages);
    }

    /** Parse ngay dang yyyy-MM-dd, tra ve gia tri mac dinh neu rong hoac khong hop le. */
    private static LocalDate parseDate(String value, LocalDate defaultValue) {
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        try {
            return LocalDate.parse(value.trim());
        } catch (DateTimeParseException e) {
            return defaultValue;
        }
    }
}
