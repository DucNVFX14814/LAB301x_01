package com.doveso.bo;

/**
 * Ket qua cua 1 thao tac xu ly hang loat: thong bao thanh cong va/hoac thong bao loi (moi cai co the null).
 * Controller dat 2 thong bao nay vao session (flashSuccess / flashError) de hien thi 1 lan sau khi chuyen huong.
 */
public final class FlashResult {

    private final String success;
    private final String error;

    public FlashResult(String success, String error) {
        this.success = success;
        this.error = error;
    }

    public String getSuccess() {
        return success;
    }

    public String getError() {
        return error;
    }
}
