package com.doveso.bo;

import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryRegion;
import com.doveso.util.NumberSuggestionUtil;

import java.util.List;

/**
 * Tang nghiep vu cua Chuc nang 4 (*): Phan tich va de xuat so ve so nen mua.
 * Thong ke tan suat 2 chu so cuoi tren cac ve do da PUBLISH cua 1 cong ty xo so (bat buoc chon).
 */
public interface NumberSuggestionBO {

    /** So luong so nong / nguoi hien thi. */
    int TOP_N = 10;

    List<LotteryRegion> getRegions();

    List<LotteryCompany> getCompanies();

    /** Ket qua phan tich: loi (tinh khong hop le) hoac tinh da chon kem ket qua thong ke; ca 3 deu null neu chua chon tinh. */
    class Suggestion {
        private final String error;
        private final LotteryCompany company;
        private final NumberSuggestionUtil.Result result;

        public Suggestion(String error, LotteryCompany company, NumberSuggestionUtil.Result result) {
            this.error = error;
            this.company = company;
            this.result = result;
        }

        public String getError() {
            return error;
        }

        public LotteryCompany getCompany() {
            return company;
        }

        public NumberSuggestionUtil.Result getResult() {
            return result;
        }
    }

    /**
     * Phan tich cho tinh companyCode. companyCode rong -> chua co ket qua (chi hien form);
     * ma khong ton tai hoac khong hoat dong -> loi.
     */
    Suggestion suggest(String companyCode);
}
