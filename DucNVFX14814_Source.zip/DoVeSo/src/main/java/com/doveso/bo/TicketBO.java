package com.doveso.bo;

import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryRegion;
import com.doveso.model.LotteryTicket;
import com.doveso.model.TicketPreviewItem;
import com.doveso.model.User;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Tang nghiep vu (Business Object) cua Chuc nang 2: Quan ly ve do (ADMIN).
 * UC10 (them ve do le / hang loat), UC11 (tim kiem + phan trang), UC12 (publish), UC13 (xem so lan do).
 * Cac chuc nang nay chi danh cho ADMIN: NO_USER va USER khong ho tro (kiem soat boi AdminAuthorizationFilter).
 *
 * Luu y: moi doi tuong TicketBO giu bo nho dem ket qua nguon cua 1 request (xem LotteryResultCache),
 * vi vay Controller tao doi tuong moi cho moi request (TicketBOImpl.newDefault()).
 */
public interface TicketBO {

    /** Gia tri tham so "company" nghia la tat ca cac dai cua mien (ap dung cho man hinh them ve do). */
    String ALL_COMPANIES = "ALL";

    /** So ve do toi da tren 1 trang danh sach (UC11). */
    int PAGE_SIZE = 10;

    // ---------------------------------------------------------------- danh muc mien / dai

    /** Danh sach mien (nap 1 lan cho 1 request). */
    List<LotteryRegion> getRegions();

    /** Danh sach dai xo so dang hoat dong (nap 1 lan cho 1 request). */
    List<LotteryCompany> getCompanies();

    boolean isValidRegion(String regionCode);

    /** Tim dai dang hoat dong theo ma dai, null neu khong co. */
    LotteryCompany findCompany(String companyCode);

    /**
     * Xac dinh danh sach dai can xu ly tu (region, company). company = "ALL" -> tat ca dai cua mien.
     * Tra ve null neu tham so khong hop le (mien khong ton tai, dai khong thuoc mien).
     */
    List<LotteryCompany> resolveTargets(String regionCode, String companyParam);

    // ---------------------------------------------------------------- UC10: them ve do

    /** Kiem tra tham so man hinh them ve do le; tra ve thong bao loi, hoac null neu hop le. */
    String validateSingleDay(String regionCode, String companyParam, String dateParam);

    /** Kiem tra khoang ngay cua man hinh them hang loat; tra ve thong bao loi, hoac null neu hop le. */
    String validateRange(LocalDate from, LocalDate to);

    /** Danh sach xem truoc cho 1 ngay (lay du lieu tu nguon cho cac tinh chua co ve do). */
    List<TicketPreviewItem> previewDay(String regionCode, String companyParam, LocalDate date);

    /** Danh sach xem truoc cho khoang ngay [from, to], ngay moi nhat truoc. */
    List<TicketPreviewItem> previewRange(String regionCode, String companyParam, LocalDate from, LocalDate to);

    /**
     * Luu cac dong OK cua danh sach xem truoc (du lieu da lay lai tu nguon, khong tin du lieu tu client).
     *
     * @param savedIds danh sach id ve do da luu (out)
     * @param failed   mo ta cac dong luu that bai (out)
     */
    void saveOkItems(List<TicketPreviewItem> items, User admin, boolean publish,
                     List<Long> savedIds, List<String> failed);

    /**
     * Luu hang loat cac cap (maDai|yyyy-MM-dd) da chon, lay lai du lieu tu nguon cho moi ngay.
     * Dong nao loi thi bao loi rieng, cac dong con lai van duoc xu ly.
     */
    FlashResult saveBatch(User admin, String regionCode, String companyParam, String[] pairParams,
                          boolean publish);

    /** Cong bo hang loat cac ve do da co san nhung dang UNPUBLISH. */
    FlashResult publishExisting(String[] idParams);

    // ---------------------------------------------------------------- UC11: tim kiem + phan trang

    /** Ket qua tim kiem ve do da chuan hoa tham so, san sang dat vao request. */
    class TicketSearchResult {
        private final String region;
        private final String company;
        private final String status;
        private final String fromDate;
        private final String toDate;
        private final String error;
        private final List<LotteryTicket> tickets;
        private final long total;
        private final int totalPages;
        private final int page;

        public TicketSearchResult(String region, String company, String status, String fromDate, String toDate,
                                  String error, List<LotteryTicket> tickets, long total, int totalPages, int page) {
            this.region = region;
            this.company = company;
            this.status = status;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.error = error;
            this.tickets = tickets;
            this.total = total;
            this.totalPages = totalPages;
            this.page = page;
        }

        public String getRegion() {
            return region;
        }

        public String getCompany() {
            return company;
        }

        public String getStatus() {
            return status;
        }

        public String getFromDate() {
            return fromDate;
        }

        public String getToDate() {
            return toDate;
        }

        /** Thong bao loi bo loc khong hop le, null neu hop le. */
        public String getError() {
            return error;
        }

        public List<LotteryTicket> getTickets() {
            return tickets;
        }

        public long getTotal() {
            return total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public int getPage() {
            return page;
        }
    }

    /**
     * Tim kiem ve do theo mien/dai/trang thai/khoang ngay, phan trang PAGE_SIZE ve do/trang.
     * Cac tham so la gia tri tho cua request (co the null). Lan vao dau tien (khong co tham so loc)
     * mac dinh loc tu dau thang den hom nay.
     */
    TicketSearchResult search(String regionRaw, String companyRaw, String statusRaw, String fromRaw,
                              String toRaw, String pageRaw);

    // ---------------------------------------------------------------- UC12: publish

    /** Ket qua cong bo 1 ve do. */
    class PublishResult {
        private final boolean ticketFound;
        private final String success;
        private final String error;

        public PublishResult(boolean ticketFound, String success, String error) {
            this.ticketFound = ticketFound;
            this.success = success;
            this.error = error;
        }

        public boolean isTicketFound() {
            return ticketFound;
        }

        public String getSuccess() {
            return success;
        }

        public String getError() {
            return error;
        }
    }

    /** Cong bo ve do (UNPUBLISH -> PUBLISH). Ve do da PUBLISH khong duoc chuyen nguoc lai. */
    PublishResult publish(Long ticketId);

    // ---------------------------------------------------------------- UC13: chi tiet + so lan do

    /** Chi tiet 1 ve do: cac giai (da sap xep) va so lan ve do duoc dung de do. */
    class TicketDetail {
        private final LotteryTicket ticket;
        private final List<LotteryPrize> prizes;
        private final long drawTimes;

        public TicketDetail(LotteryTicket ticket, List<LotteryPrize> prizes, long drawTimes) {
            this.ticket = ticket;
            this.prizes = prizes;
            this.drawTimes = drawTimes;
        }

        public LotteryTicket getTicket() {
            return ticket;
        }

        public List<LotteryPrize> getPrizes() {
            return prizes;
        }

        public long getDrawTimes() {
            return drawTimes;
        }
    }

    /** Lay chi tiet ve do, null neu khong tim thay (hoac ticketId null). */
    TicketDetail getDetail(Long ticketId);

    // ---------------------------------------------------------------- tien ich thuan (khong can CSDL)

    /** Sap xep cac giai theo thu tu DB, G1, G2... (sap xep tai cho, tra ve chinh danh sach da truyen vao). */
    static List<LotteryPrize> sortPrizes(List<LotteryPrize> prizes) {
        List<String> order = Arrays.asList(LotteryPrize.PRIZE_ORDER);
        prizes.sort(Comparator.comparingInt(p -> order.indexOf(p.getPrizeCode())));
        return prizes;
    }

    /** Ket qua dem theo trang thai cua danh sach xem truoc (dung chung cho man hinh tao le va tao hang loat). */
    final class PreviewCounts {
        public int successCount;
        public int existsPublishedCount;
        public int existsUnpublishedCount;
        public int errorCount;
    }

    /** Dem so dong theo tung trang thai trong danh sach xem truoc, de hien thi cac badge thong ke. */
    static PreviewCounts countByStatus(List<TicketPreviewItem> items) {
        PreviewCounts counts = new PreviewCounts();
        for (TicketPreviewItem item : items) {
            switch (item.getStatus()) {
                case TicketPreviewItem.OK -> counts.successCount++;
                case TicketPreviewItem.EXISTS -> {
                    if (item.isExistingPublished()) {
                        counts.existsPublishedCount++;
                    } else {
                        counts.existsUnpublishedCount++;
                    }
                }
                default -> counts.errorCount++;
            }
        }
        return counts;
    }
}
