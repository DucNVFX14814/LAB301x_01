package com.doveso.bo;

import com.doveso.model.User;
import com.doveso.util.ResetTokenUtil;

/**
 * Tang nghiep vu (Business Object) cua UC05: Quen mat khau.
 * Buoc 1-3: nhap email -> tao token -> gui email chua lien ket dat lai mat khau (requestReset).
 * Buoc 4-5: mo lien ket -> kiem tra token (findUserByToken) -> nhap mat khau moi (resetPassword).
 */
public interface PasswordResetBO {

    /**
     * Thong bao chung, giong het nhau du email co ton tai/dang hoat dong hay khong, de tranh lo thong tin
     * ve viec 1 email co dang ky trong he thong hay khong (user enumeration). Ly do that chi ghi vao log server.
     */
    String GENERIC_MESSAGE = "Nếu email tồn tại trong hệ thống, chúng tôi đã gửi hướng dẫn "
            + "đặt lại mật khẩu tới hộp thư của bạn (kiểm tra cả thư rác). Liên kết có hiệu lực "
            + ResetTokenUtil.EXPIRE_MINUTES + " phút.";

    /**
     * Xu ly yeu cau quen mat khau. Email khong hop le -> that bai kem thong bao. Con lai luon thanh cong
     * (dung hien thi GENERIC_MESSAGE) bat ke email co ton tai, tai khoan co bi khoa, hay mail co duoc cau hinh
     * hay khong; token (da bam) duoc luu va email duoc gui o luong nen.
     *
     * @param email           email nguoi dung nhap (da trim)
     * @param fallbackBaseUrl dia chi goc dung tao lien ket khi chua cau hinh app.baseUrl (vd http://localhost:8080/doveso)
     */
    BoResult<Void> requestReset(String email, String fallbackBaseUrl);

    /** Tim nguoi dung theo token (con han, chua dung); null neu token rong/khong hop le/het han. */
    User findUserByToken(String token);

    /** Trang thai ket qua dat lai mat khau. */
    enum Status {
        /** Token khong hop le, het han hoac da duoc dung. */
        INVALID_TOKEN,
        /** Token hop le nhung mat khau moi khong hop le (xem error). */
        INVALID_INPUT,
        /** Da dat lai mat khau thanh cong. */
        SUCCESS
    }

    /** Ket qua dat lai mat khau. */
    class ResetResult {
        private final Status status;
        private final String error;
        private final User user;

        public ResetResult(Status status, String error, User user) {
            this.status = status;
            this.error = error;
            this.user = user;
        }

        public Status getStatus() {
            return status;
        }

        /** Thong bao loi khi status = INVALID_INPUT, nguoc lai null. */
        public String getError() {
            return error;
        }

        /** Nguoi dung ung voi token (null khi INVALID_TOKEN), dung de hien lai email tren form. */
        public User getUser() {
            return user;
        }
    }

    /**
     * Dat lai mat khau bang token. Token chi dung duoc 1 lan (cap nhat mat khau va xoa token trong 1 cau UPDATE).
     */
    ResetResult resetPassword(String token, String password, String confirmPassword);
}
