package com.doveso.bo;

import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryHistory;
import com.doveso.model.LotteryRegion;

import java.time.LocalDate;
import java.util.List;

/**
 * Tang nghiep vu cua UC16: Xem lich su do ve cua USER da dang nhap.
 * Sap xep theo thoi gian do giam dan, phan trang PAGE_SIZE dong/trang, loc tuy chon theo mien/cong ty/khoang ngay.
 */
public interface UserHistoryBO {

    /** So dong lich su moi trang. */
    int PAGE_SIZE = 10;

    List<LotteryRegion> getRegions();

    List<LotteryCompany> getCompanies();

    /** 1 trang lich su cung cac gia tri bo loc da chuan hoa (de dat lai vao form). */
    class HistoryPage {
        private final String region;
        private final String company;
        private final LocalDate today;
        private final LocalDate fromDate;
        private final LocalDate toDate;
        private final List<LotteryHistory> history;
        private final long total;
        private final int page;
        private final int totalPages;

        public HistoryPage(String region, String company, LocalDate today, LocalDate fromDate, LocalDate toDate,
                           List<LotteryHistory> history, long total, int page, int totalPages) {
            this.region = region;
            this.company = company;
            this.today = today;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.history = history;
            this.total = total;
            this.page = page;
            this.totalPages = totalPages;
        }

        public String getRegion() {
            return region;
        }

        public String getCompany() {
            return company;
        }

        public LocalDate getToday() {
            return today;
        }

        public LocalDate getFromDate() {
            return fromDate;
        }

        public LocalDate getToDate() {
            return toDate;
        }

        public List<LotteryHistory> getHistory() {
            return history;
        }

        public long getTotal() {
            return total;
        }

        public int getPage() {
            return page;
        }

        public int getTotalPages() {
            return totalPages;
        }
    }

    /**
     * Lay 1 trang lich su do ve cua nguoi dung. Cac tham so la gia tri tho cua request (co the null).
     * Mac dinh loc tu dau thang den hom nay; ngay khong hop le dung gia tri mac dinh; den-ngay khong qua hom nay;
     * tu-ngay khong sau den-ngay; so trang duoc dua ve khoang hop le.
     */
    HistoryPage getHistory(Long userId, String regionRaw, String companyRaw, String fromRaw, String toRaw,
                           String pageRaw);
}
