package com.doveso.bo;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryHistoryDAO;
import com.doveso.dao.LotteryPrizeConfigDAO;
import com.doveso.dao.LotteryPrizeDAO;
import com.doveso.dao.TicketDAO;
import com.doveso.dao.impl.CompanyDAOImpl;
import com.doveso.dao.impl.LotteryHistoryDAOImpl;
import com.doveso.dao.impl.LotteryPrizeConfigDAOImpl;
import com.doveso.dao.impl.LotteryPrizeDAOImpl;
import com.doveso.dao.impl.TicketDAOImpl;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryHistory;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryRegion;
import com.doveso.model.LotteryTicket;
import com.doveso.model.User;
import com.doveso.util.LotteryCheckUtil;
import com.doveso.util.ValidationUtil;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Cai dat LotteryCheckBO. Ap dung cho tat ca cong ty xo so; nguoi dung bat buoc chon 1 tinh de xac dinh dung
 * ve do can doi chieu. Khong phu thuoc HttpServletRequest nen unit test duoc bang mock DAO.
 */
public class LotteryCheckBOImpl implements LotteryCheckBO {

    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final TicketDAO ticketDAO;
    private final LotteryPrizeDAO prizeDAO;
    private final LotteryPrizeConfigDAO prizeConfigDAO;
    private final LotteryHistoryDAO historyDAO;
    private final CompanyDAO companyDAO;

    public LotteryCheckBOImpl(TicketDAO ticketDAO, LotteryPrizeDAO prizeDAO, LotteryPrizeConfigDAO prizeConfigDAO,
                              LotteryHistoryDAO historyDAO, CompanyDAO companyDAO) {
        this.ticketDAO = ticketDAO;
        this.prizeDAO = prizeDAO;
        this.prizeConfigDAO = prizeConfigDAO;
        this.historyDAO = historyDAO;
        this.companyDAO = companyDAO;
    }

    /** Tao BO voi DAO that (dung trong Servlet). */
    public static LotteryCheckBO newDefault() {
        return new LotteryCheckBOImpl(new TicketDAOImpl(), new LotteryPrizeDAOImpl(),
                new LotteryPrizeConfigDAOImpl(), new LotteryHistoryDAOImpl(), new CompanyDAOImpl());
    }

    @Override
    public List<LotteryRegion> getRegions() {
        return companyDAO.findAllRegions();
    }

    @Override
    public List<LotteryCompany> getCompanies() {
        return companyDAO.findActiveCompanies();
    }

    @Override
    public CheckOutcome check(String companyCodeRaw, String drawDateStr, String singleNumber,
                              String multiNumbersRaw, User currentUser) {
        String companyCode = ValidationUtil.trimToEmpty(companyCodeRaw);
        LotteryCompany company = companyCode.isEmpty() ? null : companyDAO.findByCode(companyCode);
        if (company == null || !company.isActive()) {
            return error(null, "Vui lòng chọn tỉnh xổ số hợp lệ.");
        }

        LocalDate drawDate;
        try {
            drawDate = LocalDate.parse(drawDateStr);
        } catch (DateTimeParseException | NullPointerException e) {
            return error(company, "Vui lòng chọn ngày quay số hợp lệ.");
        }

        // Business rule: chi duoc do khi ve do da PUBLISH, dung tinh + dung ngay da chon
        LotteryTicket ticket = ticketDAO.findPublishedByCompanyAndDate(companyCode, drawDate);
        if (ticket == null) {
            return error(company, "Vé dò " + company.getCompanyName() + " ngày " + drawDate.format(DISPLAY_DATE)
                    + " không tồn tại hoặc chưa được công bố kết quả.");
        }

        boolean loggedIn = currentUser != null;
        if (loggedIn && lengthOf(multiNumbersRaw) > MAX_INPUT_LENGTH) {
            return error(company, "Dữ liệu nhập quá dài, vui lòng chỉ nhập tối đa "
                    + MAX_TICKET_NUMBERS + " số vé.");
        }
        List<String> ticketNumbers = extractTicketNumbers(singleNumber, multiNumbersRaw, loggedIn);
        if (ticketNumbers.isEmpty()) {
            return error(company, "Vui lòng nhập ít nhất 1 số vé số.");
        }
        if (ticketNumbers.size() > MAX_TICKET_NUMBERS) {
            return error(company, "Mỗi lần chỉ được dò tối đa " + MAX_TICKET_NUMBERS
                    + " số vé (bạn đã nhập " + ticketNumbers.size() + " số).");
        }
        int expectedLength = "BAC".equals(company.getRegionCode()) ? 5 : 6;
        for (String number : ticketNumbers) {
            if (!ValidationUtil.isValidTicketNumber(number, expectedLength)) {
                return error(company, "Số vé số \"" + abbreviate(number)
                        + "\" không hợp lệ. Số vé " + company.getCompanyName()
                        + " phải gồm đúng " + expectedLength + " chữ số.");
            }
        }

        List<LotteryPrize> prizes = prizeDAO.findByTicketId(ticket.getId());
        ticket.setPrizes(prizes);
        Map<String, Long> prizeAmounts = prizeConfigDAO.findAmountsByRegion(company.getRegionCode());

        List<LotteryCheckUtil.CheckResult> results = new ArrayList<>();
        long grandTotal = 0;
        for (String number : ticketNumbers) {
            LotteryCheckUtil.CheckResult result = LotteryCheckUtil.check(number, prizes, prizeAmounts);
            results.add(result);
            grandTotal += result.getTotalAmount();

            // Chi USER da dang nhap moi duoc luu lich su do ve
            if (loggedIn) {
                LotteryHistory history = new LotteryHistory();
                history.setUserId(currentUser.getId());
                history.setTicketId(ticket.getId());
                history.setTicketNumber(result.getTicketNumber());
                history.setResultSummary(result.getSummary());
                history.setPrizeAmount(result.getPrizeAmount());
                historyDAO.insert(history);
            }
        }
        return new CheckOutcome(null, company, ticket, results, grandTotal);
    }

    private static CheckOutcome error(LotteryCompany company, String message) {
        return new CheckOutcome(message, company, null, null, 0);
    }

    /**
     * Lay danh sach so ve so (khong lap). NO_USER chi lay 1 so (o "singleNumber").
     * USER da dang nhap lay tu textarea (moi dong hoac cach nhau boi dau phay).
     */
    static List<String> extractTicketNumbers(String singleNumber, String multiNumbersRaw, boolean isLoggedIn) {
        Set<String> numbers = new LinkedHashSet<>();
        if (!isLoggedIn) {
            if (singleNumber != null && !singleNumber.isBlank()) {
                numbers.add(singleNumber.trim());
            }
            return new ArrayList<>(numbers);
        }
        if (multiNumbersRaw != null && !multiNumbersRaw.isBlank()) {
            for (String part : multiNumbersRaw.split("[\\r\\n,]+")) {
                if (!part.isBlank()) {
                    numbers.add(part.trim());
                }
            }
        }
        return new ArrayList<>(numbers);
    }

    private static int lengthOf(String s) {
        return s == null ? 0 : s.length();
    }

    /** Rut gon chuoi nguoi dung nhap truoc khi dua vao thong bao loi. */
    private static String abbreviate(String s) {
        return s.length() > 12 ? s.substring(0, 12) + "..." : s;
    }
}
