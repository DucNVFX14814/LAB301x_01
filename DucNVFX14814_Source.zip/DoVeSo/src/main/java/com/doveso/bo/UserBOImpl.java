package com.doveso.bo;

import com.doveso.dao.UserDAO;
import com.doveso.dao.impl.UserDAOImpl;
import com.doveso.model.User;
import com.doveso.util.PasswordUtil;
import com.doveso.util.ValidationUtil;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Cai dat UserBO. Khong phu thuoc HttpServletRequest/Session nen test duoc bang unit test (mock UserDAO).
 */
public class UserBOImpl implements UserBO {

    private static final String ROLE_ADMIN = "ADMIN";

    private final UserDAO userDAO;

    public UserBOImpl(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    /** Tao BO voi DAO that (dung trong Servlet). */
    public static UserBO newDefault() {
        return new UserBOImpl(new UserDAOImpl());
    }

    @Override
    public BoResult<User> login(String email, String password) {
        User user = userDAO.findByEmail(email);

        // Buoc 3a: sai email/mat khau
        if (user == null || !PasswordUtil.verify(password, user.getPasswordHash())) {
            return BoResult.fail("Sai tên đăng nhập hoặc mật khẩu.");
        }
        // Buoc 3b: tai khoan bi khoa
        if (!user.isActive()) {
            return BoResult.fail("Tài khoản của bạn đã bị khóa, vui lòng liên hệ quản trị viên.");
        }
        userDAO.updateLastLogin(user.getId());
        return BoResult.ok(user);
    }

    @Override
    public BoResult<Void> register(String fullName, String email, String phone, String password,
                                   String confirmPassword) {
        // Buoc 2 (UC01): kiem tra dinh dang du lieu dau vao - tra ve loi cu the theo tung truong
        String validationError = validateRegistration(fullName, email, phone, password, confirmPassword);
        if (validationError != null) {
            return BoResult.fail(validationError);
        }
        // Buoc 3a (UC01): email da ton tai
        if (userDAO.existsByEmail(email)) {
            return BoResult.fail("Email đã được sử dụng.");
        }
        // Buoc 3b (UC01): so dien thoai da ton tai (tranh SQLIntegrityConstraintViolationException)
        if (userDAO.existsByPhone(phone)) {
            return BoResult.fail("Số điện thoại đã được sử dụng.");
        }

        User newUser = new User(fullName.trim(), email.trim(), phone.trim(), PasswordUtil.hash(password));
        try {
            userDAO.insert(newUser);
        } catch (RuntimeException e) {
            // Phong truong hop 2 nguoi dang ky trung email/sdt cung luc (vuot qua duoc buoc kiem tra
            // existsBy... o tren nhung insert vao CSDL lai dung luc nhau) - tranh loi 500.
            return BoResult.fail("Email hoặc số điện thoại đã được sử dụng. Vui lòng kiểm tra lại.");
        }
        return BoResult.ok(null);
    }

    /** Kiem tra tung truong va tra ve thong bao loi dau tien gap phai, null neu hop le. */
    private static String validateRegistration(String fullName, String email, String phone, String password,
                                               String confirmPassword) {
        if (!ValidationUtil.isValidFullName(fullName)) {
            return "Họ và tên không hợp lệ (2-150 ký tự, chỉ gồm chữ cái và khoảng trắng).";
        }
        if (!ValidationUtil.isValidEmail(email)) {
            return "Email không đúng định dạng.";
        }
        if (!ValidationUtil.isValidPhone(phone)) {
            return "Số điện thoại phải bắt đầu bằng số 0 và có đúng 10 chữ số.";
        }
        if (!ValidationUtil.isValidPassword(password)) {
            return "Mật khẩu phải có ít nhất 6 ký tự.";
        }
        if (!password.equals(confirmPassword)) {
            return "Mật khẩu xác nhận không khớp.";
        }
        return null;
    }

    @Override
    public BoResult<Void> changePassword(Long userId, String currentPassword, String newPassword,
                                         String confirmPassword) {
        // Doc lai tu CSDL de lay ma bam mat khau moi nhat (session co the cu)
        User user = userDAO.findById(userId);

        if (ValidationUtil.isBlank(currentPassword)) {
            return BoResult.fail("Vui lòng nhập mật khẩu hiện tại.");
        }
        if (user == null || !PasswordUtil.verify(currentPassword, user.getPasswordHash())) {
            return BoResult.fail("Mật khẩu hiện tại không đúng");
        }
        if (!ValidationUtil.isValidPassword(newPassword)) {
            return BoResult.fail("Mật khẩu mới phải có ít nhất 6 ký tự.");
        }
        if (!newPassword.equals(confirmPassword)) {
            return BoResult.fail("Mật khẩu xác nhận không khớp.");
        }
        if (newPassword.equals(currentPassword)) {
            return BoResult.fail("Mật khẩu mới phải khác mật khẩu hiện tại.");
        }
        userDAO.updatePassword(user.getId(), PasswordUtil.hash(newPassword));
        return BoResult.ok(null);
    }

    @Override
    public BoResult<Void> updateRoleAndStatus(User requester, List<RoleChange> changes) {
        boolean requesterIsMasterAdmin = MasterAdmin.is(requester);

        // Buoc 1: doi chieu voi du lieu THUC TE trong CSDL, gom danh sach vi pham theo tung loai (neu co)
        List<String> lockedOrDemotedAdminNames = new ArrayList<>();
        List<String> roleChangedWhileLockedNames = new ArrayList<>();
        List<String> unauthorizedPromoteNames = new ArrayList<>();
        for (RoleChange change : changes) {
            User current = userDAO.findById(change.getUserId());
            if (current == null) {
                continue;
            }
            boolean isCurrentlyAdmin = ROLE_ADMIN.equals(current.getRole());
            boolean isRoleChanged = !current.getRole().equals(change.getNewRole());
            boolean isBeingDemoted = isCurrentlyAdmin && !ROLE_ADMIN.equals(change.getNewRole());
            boolean isBeingLocked = !change.isNewActive();

            if (isCurrentlyAdmin && (isBeingDemoted || isBeingLocked)) {
                lockedOrDemotedAdminNames.add(current.getFullName());
                continue; // da bi chan boi quy tac 1, khong can kiem tra tiep dong nay
            }
            if (!current.isActive() && isRoleChanged) {
                roleChangedWhileLockedNames.add(current.getFullName());
                continue;
            }
            if (!requesterIsMasterAdmin && ROLE_ADMIN.equals(change.getNewRole()) && !isCurrentlyAdmin) {
                unauthorizedPromoteNames.add(current.getFullName());
            }
        }

        // Buoc 2: neu co vi pham, HUY TOAN BO thao tac luu (khong ghi bat ky thay doi nao), bao loi ro rang
        List<String> violationMessages = new ArrayList<>();
        if (!lockedOrDemotedAdminNames.isEmpty()) {
            violationMessages.add("không thể khóa hoặc hạ quyền tài khoản ADMIN: "
                    + String.join(", ", lockedOrDemotedAdminNames));
        }
        if (!roleChangedWhileLockedNames.isEmpty()) {
            violationMessages.add("tài khoản đang bị khóa nên không thể đổi ROLE, hãy mở khóa trước: "
                    + String.join(", ", roleChangedWhileLockedNames));
        }
        if (!unauthorizedPromoteNames.isEmpty()) {
            violationMessages.add("chỉ ADMIN chính mới được cấp quyền ADMIN cho: "
                    + String.join(", ", unauthorizedPromoteNames));
        }
        if (!violationMessages.isEmpty()) {
            return BoResult.fail("Không thể lưu thay đổi (" + String.join("; ", violationMessages)
                    + "). Không có thay đổi nào được lưu, vui lòng bỏ chọn các thay đổi này rồi thử lại.");
        }

        // Buoc 3: khong co vi pham, tien hanh luu toan bo thay doi
        for (RoleChange change : changes) {
            userDAO.updateRoleAndStatus(change.getUserId(), change.getNewRole(), change.isNewActive());
        }
        return BoResult.ok(null);
    }

    @Override
    public UserPage search(String keyword, String noLoginFor, int page) {
        boolean neverLoggedIn = "never".equals(noLoginFor);                              // chua tung dang nhap
        LocalDateTime lastLoginBefore = toLastLoginBefore(noLoginFor, LocalDateTime.now()); // "never"/ma la -> null

        List<User> users = userDAO.search(keyword, lastLoginBefore, neverLoggedIn, page, PAGE_SIZE);
        long total = userDAO.count(keyword, lastLoginBefore, neverLoggedIn);
        int totalPages = (int) Math.ceil((double) total / PAGE_SIZE);
        String normalized = (neverLoggedIn || lastLoginBefore != null) ? noLoginFor : "";
        return new UserPage(users, total, totalPages, normalized);
    }

    /** Doi ma loc (1d, 1w, 1m, 1q, 1y) thanh moc thoi gian; tra ve null neu khong loc hoac ma khong hop le. */
    static LocalDateTime toLastLoginBefore(String code, LocalDateTime now) {
        if (code == null) {
            return null;
        }
        return switch (code) {
            case "1d" -> now.minusDays(1);
            case "1w" -> now.minusWeeks(1);
            case "1m" -> now.minusMonths(1);
            case "1q" -> now.minusMonths(3);
            case "1y" -> now.minusYears(1);
            default -> null;
        };
    }
}
