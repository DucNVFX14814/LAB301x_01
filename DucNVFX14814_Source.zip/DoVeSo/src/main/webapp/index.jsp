<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- [CN3] Trang gốc "/": ADMIN vào thẳng màn hình bắt đầu của admin (/admin/users), còn lại vào trang Dò vé số. --%>
<c:choose>
    <c:when test="${sessionScope.currentUser.role == 'ADMIN'}">
        <c:redirect url="/admin/users"/>
    </c:when>
    <c:otherwise>
        <jsp:forward page="/check-ticket" />
    </c:otherwise>
</c:choose>
<%-- Bản gốc (trước CN3): <jsp:forward page="/check-ticket" /> --%>
