<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- Bang ket qua 8 giai XSKT mien Bac cua 1 ngay quay so.
     Yeu cau request attribute "prizes" (List<LotteryPrize>).
     Cau truc dong bo voi /WEB-INF/views/admin/_prize-table.jsp, class doi sang Bootstrap 5. --%>
<div class="table-responsive">
    <table class="table table-bordered lottery-prize-table mb-0">
        <tbody>
        <c:forEach var="p" items="${prizes}">
            <tr class="${p.prizeCode == 'DB' ? 'prize-row-special' : ''}">
                <td class="prize-label"><c:out value="${p.prizeName}"/></td>
                <td class="prize-numbers">
                    <c:forEach var="n" items="${p.numbers}">
                        <span class="prize-number ${p.prizeCode == 'DB' ? 'prize-number-special' : ''}"><c:out
                                value="${n}"/></span>
                    </c:forEach>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
