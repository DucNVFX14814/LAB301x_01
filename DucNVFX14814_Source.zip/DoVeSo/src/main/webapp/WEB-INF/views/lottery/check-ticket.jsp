<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<fmt:setLocale value="vi_VN"/>

<div class="row justify-content-center">
    <div class="col-md-8">
        <h1 class="mb-2 text-center">Dò vé số</h1>
        <h4 class="mb-3 text-muted text-center">Đối chiếu kết quả xổ số kiến thiết</h4>

        <c:if test="${not empty error}">
            <div class="alert alert-danger"><c:out value="${error}"/></div>
        </c:if>

        <div class="card shadow mb-4">
            <div class="card-body">
                <form method="post" action="${pageContext.request.contextPath}/check-ticket">
                    <div class="row align-items-end">
                        <jsp:include page="/WEB-INF/views/common/_region-company-select.jsp"/>
                        <div class="col-6 col-md-3 mb-3">
                            <label class="form-label">Ngày quay số</label>
                            <input type="date" name="drawDate" class="form-control form-control-sm" required
                                   max="<c:out value='${maxDate}'/>"
                                   value="<c:out value='${empty param.drawDate ? maxDate : param.drawDate}'/>">
                        </div>
                    </div>

                    <c:choose>
                        <c:when test="${not empty sessionScope.currentUser}">
                            <div class="mb-3">
                                <label id="ticketNumbersLabel" class="form-label">Danh sách số vé số (mỗi dòng 1 số, 5 hoặc 6 chữ số, tối đa 20 số)</label>
                                <textarea id="ticketNumbersInput" name="ticketNumbers" class="form-control" rows="5"
                                          placeholder="Ví dụ:&#10;12345&#10;99999" required><c:out value="${param.ticketNumbers}"/></textarea>
                            </div>
                        </c:when>
                        <c:otherwise>
                            <div class="mb-3">
                                <label id="ticketNumberLabel" class="form-label">Số vé số (5 hoặc 6 chữ số)</label>
                                <input id="ticketNumberInput" type="text" name="ticketNumber" class="form-control"
                                       maxlength="6" pattern="\d{5,6}" placeholder="Ví dụ: 12345" required
                                       value="<c:out value='${param.ticketNumber}'/>">
                            </div>
                            <p class="text-muted small">Đăng nhập để dò được nhiều vé cùng lúc và xem lại lịch sử dò vé.</p>
                        </c:otherwise>
                    </c:choose>

                    <script>
                        (function () {
                            var companySel = document.getElementById('companySel');
                            var singleInput = document.getElementById('ticketNumberInput');
                            var singleLabel = document.getElementById('ticketNumberLabel');
                            var textarea = document.getElementById('ticketNumbersInput');
                            var textareaLabel = document.getElementById('ticketNumbersLabel');
                            if (!companySel) {
                                return;
                            }

                            function expectedLength() {
                                var opt = companySel.options[companySel.selectedIndex];
                                var region = opt ? opt.getAttribute('data-region') : null;
                                if (region === 'BAC') return 5;
                                if (region) return 6;
                                return null; // chua chon tinh cu the - chua biet 5 hay 6 chu so
                            }

                            function applyLength() {
                                var len = expectedLength();
                                var lenText = len ? (len + ' chữ số') : '5 hoặc 6 chữ số';
                                if (singleInput) {
                                    singleInput.maxLength = len || 6;
                                    singleInput.pattern = len ? ('\\d{' + len + '}') : '\\d{5,6}';
                                }
                                if (singleLabel) {
                                    singleLabel.textContent = 'Số vé số (' + lenText + ')';
                                }
                                if (textarea) {
                                    textarea.setAttribute('data-expected-length', len || '');
                                }
                                if (textareaLabel) {
                                    textareaLabel.textContent = 'Danh sách số vé số (mỗi dòng 1 số, '
                                        + lenText + ', tối đa 20 số)';
                                }
                            }

                            companySel.addEventListener('change', applyLength);
                            applyLength();

                            if (textarea) {
                                var form = companySel.closest('form');
                                form.addEventListener('submit', function (e) {
                                    var lenAttr = textarea.getAttribute('data-expected-length');
                                    var re = lenAttr ? new RegExp('^\\d{' + lenAttr + '}$') : /^\d{5,6}$/;
                                    var lines = textarea.value.split(/[\r\n,]+/)
                                        .map(function (s) { return s.trim(); })
                                        .filter(function (s) { return s.length > 0; });
                                    var bad = null;
                                    for (var i = 0; i < lines.length; i++) {
                                        if (!re.test(lines[i])) {
                                            bad = lines[i];
                                            break;
                                        }
                                    }
                                    if (bad) {
                                        e.preventDefault();
                                        var expect = lenAttr ? lenAttr : '5 hoặc 6';
                                        alert('Số vé "' + bad + '" không hợp lệ. Số vé phải gồm đúng ' + expect + ' chữ số.');
                                    }
                                });
                            }
                        })();
                    </script>

                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Dò vé
                    </button>
                </form>
            </div>
        </div>

        <c:if test="${not empty results}">

            <div class="card shadow mb-4">
                <div class="card-header fw-bold">
                    Kết quả dò của bạn
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle mb-0">
                            <thead>
                            <tr>
                                <th style="width: 120px;">Số vé</th>
                                <th>Kết quả</th>
                                <th style="width: 200px;">Tổng tiền thưởng</th>
                            </tr>
                            </thead>
                            <tbody>
                            <c:forEach var="r" items="${results}">
                                <tr class="${r.won ? 'row-won' : ''}">
                                    <td><strong><c:out value="${r.ticketNumber}"/></strong></td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${r.won}">
                                                <c:forEach var="m" items="${r.matches}">
                                                    <div>
                                                        <span class="badge bg-success"><c:out value="${m.name}"/></span>
                                                        <span class="text-muted small">
                                                        <fmt:formatNumber value="${m.amount}" groupingUsed="true"/> đ
                                                    </span>
                                                    </div>
                                                </c:forEach>
                                            </c:when>
                                            <c:otherwise>Không trúng giải</c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${r.won}">
                                                <strong><fmt:formatNumber value="${r.totalAmount}" groupingUsed="true"/> đ</strong>
                                            </c:when>
                                            <c:otherwise>-</c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                            </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </div>
                <c:if test="${grandTotal > 0 and results.size() > 1}">
                    <div class="card-footer text-end">
                        Tổng tiền trúng thưởng:
                        <strong class="text-success"><fmt:formatNumber value="${grandTotal}" groupingUsed="true"/> đ</strong>
                    </div>
                </c:if>
            </div>

            <div class="card shadow">
                <div class="card-header fw-bold">
                    Kết quả xổ số <c:out value="${ticket.companyName}"/> (<c:out value="${ticket.regionName}"/>)
                    - Ngày <c:out value="${ticket.drawDateFormatted}"/>
                </div>
                <div class="card-body p-0">
                    <c:set var="prizes" value="${ticket.prizes}" scope="request"/>
                    <jsp:include page="/WEB-INF/views/lottery/_prize-table.jsp"/>
                </div>
            </div>

        </c:if>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
