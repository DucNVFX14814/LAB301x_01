<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%--
    Bo chon Mien + Dai xo so (dai loc theo mien dang chon).
    Request attribute can co: regions, companies, selRegion, selCompany, allowAllRegion (boolean),
    allCompanyValue (gia tri cua lua chon "Tat ca dai": "" cho bo loc danh sach, "ALL" cho man hinh them ve do).
    Ten tham so gui di: region, company.
--%>
<label for="regionSel" class="mr-2 mb-2">Miền</label>
<select id="regionSel" name="region" class="form-control mr-3 mb-2">
    <c:if test="${allowAllRegion}">
        <option value="">Tất cả miền</option>
    </c:if>
    <c:forEach var="r" items="${regions}">
        <option value="<c:out value='${r.regionCode}'/>" ${r.regionCode == selRegion ? 'selected' : ''}>
            <c:out value="${r.regionName}"/></option>
    </c:forEach>
</select>
<label for="companySel" class="mr-2 mb-2">Tỉnh</label>
<select id="companySel" name="company" class="form-control mr-3 mb-2">
    <option value="<c:out value='${allCompanyValue}'/>" data-all="1">Tất cả tỉnh</option>
    <c:forEach var="c" items="${companies}">
        <option value="<c:out value='${c.companyCode}'/>" data-region="<c:out value='${c.regionCode}'/>"
            ${c.companyCode == selCompany ? 'selected' : ''}><c:out value="${c.companyName}"/></option>
    </c:forEach>
</select>
<script>
    // Loc danh sach dai theo mien dang chon (dung cach dung lai option thay vi an option de chay tot tren mobile)
    (function () {
        var region = document.getElementById('regionSel');
        var company = document.getElementById('companySel');
        var all = Array.prototype.slice.call(company.options);

        function rebuild(keepValue) {
            var r = region.value;
            company.innerHTML = '';
            all.forEach(function (o) {
                if (o.getAttribute('data-all') || !r || o.getAttribute('data-region') === r) {
                    company.appendChild(o);
                }
            });
            var found = false;
            Array.prototype.forEach.call(company.options, function (o, i) {
                if (o.value === keepValue && keepValue !== '') {
                    company.selectedIndex = i;
                    found = true;
                }
            });
            if (!found) {
                company.selectedIndex = 0;
            }
        }

        region.addEventListener('change', function () {
            rebuild('');
        });
        rebuild(company.value);
    })();
</script>
