<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>
<c:set var="isMasterAdmin" value="${sessionScope.currentUser.id == 10000000}"/>
<div class="list-page">
    <div class="d-flex flex-wrap align-items-center mb-3">
        <h3 class="mb-0">Quản lý người dùng</h3>
        <button type="button" id="btnSaveChanges" class="btn btn-primary ml-auto">Lưu thay đổi</button>
    </div>

    <c:if test="${not empty error}">
        <div class="alert alert-danger"><c:out value="${error}"/></div>
    </c:if>

    <div class="card shadow list-card">
        <div class="card-body">
            <form method="get" action="${pageContext.request.contextPath}/admin/users" class="form-inline mb-3">
                <input type="text" name="keyword" value="<c:out value='${keyword}'/>" class="form-control mr-2"
                       style="width: 340px; max-width: 100%;" placeholder="Tìm theo id/họ tên/email/sdt">
                <select name="noLoginFor" class="custom-select mr-2 mt-2 mt-sm-0" style="width: auto;">
                    <option value="">Tất cả thời gian đăng nhập</option>
                    <option value="1d" ${noLoginFor == '1d' ? 'selected' : ''}>Không đăng nhập trên 1 ngày</option>
                    <option value="1w" ${noLoginFor == '1w' ? 'selected' : ''}>Không đăng nhập trên 1 tuần</option>
                    <option value="1m" ${noLoginFor == '1m' ? 'selected' : ''}>Không đăng nhập trên 1 tháng</option>
                    <option value="1q" ${noLoginFor == '1q' ? 'selected' : ''}>Không đăng nhập trên 1 quý</option>
                    <option value="1y" ${noLoginFor == '1y' ? 'selected' : ''}>Không đăng nhập trên 1 năm</option>
                    <option value="never" ${noLoginFor == 'never' ? 'selected' : ''}>Chưa từng đăng nhập</option>
                </select>
                <button type="submit" class="btn btn-primary mr-2 mt-2 mt-sm-0">Tìm kiếm</button>
                <a href="${pageContext.request.contextPath}/admin/users" class="btn btn-secondary mt-2 mt-sm-0">Xóa bộ
                    lọc</a>
            </form>

            <c:choose>
                <c:when test="${empty users}">
                    <div class="text-center text-muted py-5">
                        Không tìm thấy người dùng phù hợp.
                    </div>
                </c:when>
                <c:otherwise>
                    <form id="userForm" method="post" class="list-scroll"
                          action="${pageContext.request.contextPath}/admin/users/update">
                        <input type="hidden" name="keyword" value="<c:out value='${keyword}'/>">
                        <input type="hidden" name="noLoginFor" value="<c:out value='${noLoginFor}'/>">
                        <input type="hidden" name="page" value="${currentPage}">
                        <table class="table table-bordered table-hover mb-0">
                            <thead class="thead-light">
                            <tr>
                                <th style="width: 150px;">User ID</th>
                                <th>Họ tên</th>
                                <th>Email</th>
                                <th style="width: 150px;">Số điện thoại</th>
                                <th style="width: 200px;">Đăng nhập gần nhất</th>
                                <th style="width: 150px;">ROLE</th>
                                <th style="width: 180px;">Trạng thái</th>
                            </tr>
                            </thead>
                            <tbody>
                            <c:forEach var="u" items="${users}">
                                <tr class="${!u.active ? 'row-inactive' : ''}">
                                    <td><c:out value="${u.id}"/></td>
                                    <td><c:out value="${u.fullName}"/></td>
                                    <td><c:out value="${u.email}"/></td>
                                    <td><c:out value="${u.phone}"/></td>
                                    <td>
                                        <span title="<c:out value='${u.lastLoginAtFormatted}'/>"
                                              class="text-nowrap ${empty u.lastLoginAtFormatted ? 'text-muted' : ''}"><c:out
                                                value="${u.lastLoginRelative}"/>
                                        </span>
                                    </td>
                                    <c:choose>
                                        <c:when test="${u.role == 'ADMIN'}">
                                            <%-- Tai khoan ADMIN: chi hien thi, khong cho sua qua man hinh nay --%>
                                            <td><span class="badge badge-primary">${u.role}</span></td>
                                            <td>
                                                <c:choose>
                                                    <c:when test="${u.active}">
                                                        <span class="badge badge-success">Đã kích hoạt</span>
                                                    </c:when>
                                                    <c:otherwise>
                                                        <span class="badge badge-secondary">Đã khóa</span>
                                                    </c:otherwise>
                                                </c:choose>
                                            </td>
                                        </c:when>
                                        <c:otherwise>
                                            <td>
                                                <select name="role_${u.id}"
                                                        class="custom-select custom-select-sm row-field"
                                                        data-original="${u.role}"
                                                        title="${!u.active ? 'Tài khoản đang bị khóa: mở khóa trước khi đổi ROLE' : (!isMasterAdmin ? 'Chỉ ADMIN chính mới được cấp quyền ADMIN' : '')}">
                                                    <option value="USER" ${u.role == 'USER' ? 'selected' : ''}>USER
                                                    </option>
                                                        <%-- Chi cho chon ADMIN khi tai khoan dang kich hoat VA nguoi thao tac la ADMIN chinh (10000000) --%>
                                                    <c:if test="${u.active and isMasterAdmin}">
                                                        <option value="ADMIN" ${u.role == 'ADMIN' ? 'selected' : ''}>ADMIN
                                                        </option>
                                                    </c:if>
                                                </select>
                                            </td>
                                            <td>
                                                <select name="active_${u.id}"
                                                        class="custom-select custom-select-sm row-field active-select"
                                                        data-original="${u.active}">
                                                    <option value="true" ${u.active ? 'selected' : ''}>Đã kích hoạt
                                                    </option>
                                                    <option value="false" ${!u.active ? 'selected' : ''}>Đã khóa
                                                    </option>
                                                </select>
                                            </td>
                                        </c:otherwise>
                                    </c:choose>
                                </tr>
                            </c:forEach>
                            </tbody>
                        </table>
                    </form>

                    <div class="d-flex flex-wrap align-items-center mt-3">
                        <span class="text-muted">Tổng cộng ${total} người dùng - trang ${currentPage}/${totalPages}</span>
                        <c:if test="${totalPages > 1}">
                            <nav class="ml-auto">
                                <ul class="pagination mb-0">
                                    <c:forEach begin="1" end="${totalPages}" var="p">
                                        <c:url var="pageUrl" value="/admin/users">
                                            <c:param name="keyword" value="${keyword}"/>
                                            <c:param name="noLoginFor" value="${noLoginFor}"/>
                                            <c:param name="page" value="${p}"/>
                                        </c:url>
                                        <li class="page-item ${p == currentPage ? 'active' : ''}">
                                            <a class="page-link" href="${pageUrl}">${p}</a>
                                        </li>
                                    </c:forEach>
                                </ul>
                            </nav>
                        </c:if>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</div>
<script>
    (function () {
        let form = document.getElementById('userForm');
        let saveBtn = document.getElementById('btnSaveChanges');
        let fields = document.querySelectorAll('.row-field');
        let isSubmitting = false;

        function countChangedRows() {
            let changedRows = new Set();
            fields.forEach(function (el) {
                if (el.value !== el.getAttribute('data-original')) {
                    changedRows.add(el.closest('tr'));
                }
            });
            return changedRows.size;
        }

        saveBtn.addEventListener('click', function () {
            let changedCount = countChangedRows();
            if (changedCount === 0) {
                alert('Không có thay đổi nào để lưu.');
                return;
            }
            if (confirm('Bạn đã thay đổi thông tin của ' + changedCount + ' người dùng. Xác nhận lưu?')) {
                isSubmitting = true;
                form.submit();
            }
        });

        // Cap nhat ngay giao dien mo xam khi doi trang thai, khong can luu/reload
        document.querySelectorAll('.active-select').forEach(function (select) {
            select.addEventListener('change', function () {
                let row = select.closest('tr');
                row.classList.toggle('row-inactive', select.value === 'false');
            });
        });

        // Canh bao khi reload/chuyen trang ma con thay doi chua luu
        window.addEventListener('beforeunload', function (e) {
            if (!isSubmitting && countChangedRows() > 0) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
    })();
</script>
<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
