<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="d-flex flex-wrap align-items-center mb-4">
    <h3 class="mb-0">Thêm vé dò hàng loạt</h3>
    <a href="${pageContext.request.contextPath}/admin/tickets" class="btn btn-secondary ml-auto">Quay lại danh sách</a>
</div>

<c:if test="${not empty success}">
    <div class="alert alert-success"><c:out value="${success}"/></div>
</c:if>
<c:if test="${not empty error}">
    <div class="alert alert-danger"><c:out value="${error}"/></div>
</c:if>
<c:if test="${not empty notice}">
    <div class="alert alert-info"><c:out value="${notice}"/></div>
</c:if>

<div class="card shadow mb-4">
    <div class="card-header font-weight-bold">Bước 1: Chọn miền, tỉnh và khoảng ngày mở thưởng (bắt buộc cùng 1 tháng)</div>
    <div class="card-body">
        <form method="get" id="rangeForm" action="${pageContext.request.contextPath}/admin/tickets/create-batch"
              class="form-inline" data-busy="Đang lấy kết quả từ nguồn dữ liệu, vui lòng chờ...">
            <jsp:include page="/WEB-INF/views/admin/_company-select.jsp"/>
            <label for="from" class="mr-2 mb-2">Từ ngày</label>
            <input type="date" id="from" name="from" value="<c:out value='${fromValue}'/>"
                   max="<c:out value='${maxDate}'/>" class="form-control mr-3 mb-2" required>
            <label for="to" class="mr-2 mb-2">Đến ngày</label>
            <input type="date" id="to" name="to" value="<c:out value='${toValue}'/>"
                   max="<c:out value='${maxDate}'/>" class="form-control mr-3 mb-2" required>
            <button type="submit" class="btn btn-primary mb-2">Xem trước</button>
        </form>
        <p class="text-muted mt-2 mb-0">
            Hệ thống lấy dữ liệu tự động qua API (mỗi lần tải được nhiều ngày; chọn một tỉnh cụ thể của miền Trung/Nam sẽ nhanh hơn).
            Ngày tỉnh không xổ số được bỏ qua; vé dò đã có hoặc chưa có kết quả trên nguồn được báo riêng, các dòng còn lại vẫn được xử lý bình thường.
        </p>
    </div>
</div>

<c:if test="${not empty items}">
    <div class="card shadow mb-4">
        <div class="card-header d-flex flex-wrap align-items-center">
            <span class="font-weight-bold">Bước 2: Kết quả xử lý (${totalDays} ngày, ${items.size()} dòng)</span>
            <div class="ml-auto">
                <button type="submit" form="batchForm" name="action" value="saveAll"
                        class="btn btn-primary btn-sm" ${successCount == 0 ? 'disabled' : ''}>
                    Lưu tất cả (${successCount})
                </button>
                <button type="submit" form="batchForm" name="action" value="publishExistingAll"
                        class="btn btn-warning btn-sm" ${existsUnpublishedCount == 0 ? 'disabled' : ''}
                        onclick="return confirm('Công bố tất cả ${existsUnpublishedCount} vé dò đang Unpublish?');">
                    Publish tất cả (${existsUnpublishedCount})
                </button>
                <button type="submit" form="batchForm" name="action" value="savePublishAll"
                        class="btn btn-success btn-sm" ${successCount == 0 ? 'disabled' : ''}
                        onclick="return confirm('Lưu và công bố tất cả ${successCount} vé dò đang sẵn sàng lưu?');">
                    Lưu và Publish tất cả (${successCount})
                </button>
            </div>
        </div>
        <div class="card-body">
            <form method="post" id="batchForm"
                  action="${pageContext.request.contextPath}/admin/tickets/create-batch"
                  data-busy="Đang xử lý vé dò, vui lòng chờ...">
                <input type="hidden" name="region" value="<c:out value='${selRegion}'/>">
                <input type="hidden" name="company" value="<c:out value='${selCompany}'/>">
                <input type="hidden" name="from" value="<c:out value='${fromValue}'/>">
                <input type="hidden" name="to" value="<c:out value='${toValue}'/>">
                <c:forEach var="item" items="${items}">
                    <c:if test="${item.status == 'OK'}">
                        <input type="hidden" name="pairs" value="${item.companyCode}|${item.date}">
                    </c:if>
                    <c:if test="${item.status == 'EXISTS' and not item.existingPublished}">
                        <input type="hidden" name="publishIds" value="${item.existingTicketId}">
                    </c:if>
                </c:forEach>

                <div class="mb-3">
                    <span class="badge badge-primary mr-2">Sẵn sàng lưu: ${successCount}</span>
                    <span class="badge badge-success mr-2">Publish: ${existsPublishedCount}</span>
                    <span class="badge badge-secondary mr-2">Unpublish: ${existsUnpublishedCount}</span>
                    <span class="badge badge-danger">Lỗi: ${errorCount}</span>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered align-middle mb-0">
                        <thead class="thead-light">
                        <tr>
                            <th style="width: 110px;">Ngày</th>
                            <th style="width: 130px;">Tỉnh</th>
                            <th style="width: 130px;">Trạng thái</th>
                            <th>Kết quả xổ số</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="item" items="${items}">
                            <tr>
                                <td class="font-weight-bold"><c:out value="${item.dateFormatted}"/></td>
                                <td>
                                    <c:choose>
                                        <c:when test="${not empty item.companyName}">
                                            <c:choose>
                                                <c:when test="${item.status == 'EXISTS'}">
                                                    <a href="${pageContext.request.contextPath}/admin/tickets/detail?id=${item.existingTicketId}"
                                                       title="Xem chi tiết vé dò"><c:out value="${item.companyName}"/></a>
                                                </c:when>
                                                <c:otherwise><c:out value="${item.companyName}"/></c:otherwise>
                                            </c:choose>
                                        </c:when>
                                        <c:otherwise><span class="text-muted">Tất cả tỉnh</span></c:otherwise>
                                    </c:choose>
                                </td>
                                <td>
                                    <c:choose>
                                        <c:when test="${item.status == 'OK'}">
                                            <span class="badge badge-primary">Sẵn sàng lưu</span>
                                        </c:when>
                                        <c:when test="${item.status == 'EXISTS' and item.existingPublished}">
                                            <span class="badge badge-success">Publish</span>
                                        </c:when>
                                        <c:when test="${item.status == 'EXISTS'}">
                                            <span class="badge badge-secondary">Unpublish</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-danger">Lỗi</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>
                                    <c:choose>
                                        <c:when test="${item.status == 'ERROR'}">
                                            <span class="text-muted small"><c:out value="${item.message}"/></span>
                                        </c:when>
                                        <c:otherwise>
                                            <c:set var="prizes" value="${item.prizes}" scope="request"/>
                                            <jsp:include page="/WEB-INF/views/admin/_prize-table.jsp"/>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    </div>
</c:if>

<script>
    // Nhac nho (khong chan submit, server van validate lai) neu 2 ngay chon khac thang
    (function () {
        var form = document.getElementById('rangeForm');
        var from = document.getElementById('from');
        var to = document.getElementById('to');
        form.addEventListener('submit', function (e) {
            if (from.value && to.value) {
                var fm = from.value.substring(0, 7);
                var tm = to.value.substring(0, 7);
                if (fm !== tm) {
                    e.preventDefault();
                    alert('Ngày bắt đầu và ngày kết thúc phải nằm trong cùng 1 tháng.');
                } else if (from.value > to.value) {
                    e.preventDefault();
                    alert('Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.');
                }
            }
        });
    })();
</script>

<jsp:include page="/WEB-INF/views/admin/_busy.jsp"/>
<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
