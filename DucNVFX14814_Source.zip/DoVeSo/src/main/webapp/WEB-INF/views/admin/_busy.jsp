<%--
    Lop phu "dang xu ly" (busy indicator): hien khi gui form co thuoc tinh data-busy="noi dung thong bao".
    Include 1 lan o cuoi trang, truoc admin-footer.
--%>
<style>
    #busyOverlay { display: none; position: fixed; top: 0; right: 0; bottom: 0; left: 0; z-index: 2000;
        background: rgba(255, 255, 255, .8); align-items: center; justify-content: center; flex-direction: column; }
    #busyOverlay.show { display: flex; }
    #busyOverlay .busy-spinner { width: 3rem; height: 3rem; border: .3rem solid #d1d3e2; border-top-color: #4e73df;
        border-radius: 50%; animation: busy-spin .8s linear infinite; }
    #busyOverlay .busy-text { margin-top: 1rem; padding: 0 1rem; text-align: center; font-weight: 600; color: #4e73df; }
    @keyframes busy-spin { to { transform: rotate(360deg); } }
</style>
<div id="busyOverlay" role="alert" aria-live="assertive">
    <div class="busy-spinner"></div>
    <div class="busy-text" id="busyText">Đang xử lý, vui lòng chờ...</div>
</div>
<script>
    (function () {
        var overlay = document.getElementById('busyOverlay');
        var text = document.getElementById('busyText');
        Array.prototype.forEach.call(document.querySelectorAll('form[data-busy]'), function (form) {
            form.addEventListener('submit', function (e) {
                // Cho cac trinh xu ly submit khac (vd kiem tra khoang ngay) chay xong; neu bi huy thi khong hien
                setTimeout(function () {
                    if (!e.defaultPrevented) {
                        text.textContent = form.getAttribute('data-busy');
                        overlay.classList.add('show');
                    }
                }, 0);
            });
        });
        // Quay lai bang nut Back (bfcache): an lop phu
        window.addEventListener('pageshow', function () {
            overlay.classList.remove('show');
        });
    })();
</script>
