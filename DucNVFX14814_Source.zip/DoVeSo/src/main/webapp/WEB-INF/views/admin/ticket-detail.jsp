<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>
<div class="d-flex flex-wrap align-items-center mb-4">
    <h3 class="mb-0">Vé dò <c:out value="${ticket.companyName}"/> ngày <c:out value="${ticket.drawDateFormatted}"/></h3>
    <c:choose>
        <c:when test="${ticket.published}">
            <span class="badge badge-success ml-3">Đã công bố</span>
        </c:when>
        <c:otherwise>
            <span class="badge badge-warning ml-3">Chưa công bố</span>
        </c:otherwise>
    </c:choose>
    <a href="${pageContext.request.contextPath}/admin/tickets" class="btn btn-secondary ml-auto">Quay lại danh sách</a>
</div>

<c:if test="${not empty success}">
    <div class="alert alert-success"><c:out value="${success}"/></div>
</c:if>
<c:if test="${not empty error}">
    <div class="alert alert-danger"><c:out value="${error}"/></div>
</c:if>

<div class="card shadow mb-4">
    <div class="card-header font-weight-bold">Kết quả xổ số <c:out value="${ticket.companyName}"/> (<c:out value="${ticket.regionName}"/>)</div>
    <div class="card-body">
        <jsp:include page="/WEB-INF/views/admin/_prize-table.jsp"/>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-body d-flex align-items-center">
        <div>
            <div class="text-muted">Số lần vé dò được người dùng dò</div>
            <div class="h4 font-weight-bold mb-0">${drawTimes}</div>
        </div>
        <div class="ml-auto">
            <c:choose>
                <c:when test="${ticket.published}">
                    <span class="text-muted">Vé dò đã công bố, không thể chuyển về chưa công bố.</span>
                </c:when>
                <c:otherwise>
                    <form method="post" action="${pageContext.request.contextPath}/admin/tickets/publish"
                          onsubmit="return confirm('Bạn có chắc muốn công bố vé dò này?');" class="mb-0">
                        <input type="hidden" name="id" value="${ticket.id}">
                        <input type="hidden" name="from" value="detail">
                        <button type="submit" class="btn btn-success">Publish</button>
                    </form>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</div>
<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
