<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="d-flex flex-wrap align-items-center mb-4">
    <h3 class="mb-0">Thêm vé dò mới</h3>
    <a href="${pageContext.request.contextPath}/admin/tickets" class="btn btn-secondary ml-auto">Quay lại danh sách</a>
</div>

<c:if test="${not empty success}">
    <div class="alert alert-success"><c:out value="${success}"/></div>
</c:if>
<c:if test="${not empty error}">
    <div class="alert alert-danger"><c:out value="${error}"/></div>
</c:if>

<div class="card shadow mb-4">
    <div class="card-header font-weight-bold">Bước 1: Chọn miền, tỉnh và ngày mở thưởng</div>
    <div class="card-body">
        <form method="get" action="${pageContext.request.contextPath}/admin/tickets/create" class="form-inline"
              data-busy="Đang lấy kết quả từ nguồn dữ liệu, vui lòng chờ...">
            <jsp:include page="/WEB-INF/views/admin/_company-select.jsp"/>
            <label for="date" class="mr-2 mb-2">Ngày mở thưởng</label>
            <input type="date" id="date" name="date" value="<c:out value='${dateValue}'/>"
                   max="<c:out value='${maxDate}'/>" class="form-control mr-3 mb-2" required>
            <button type="submit" class="btn btn-primary mb-2">Xem trước</button>
        </form>
        <p class="text-muted mt-2 mb-0">
            Kết quả được lấy tự động qua API. Chọn "Tất cả tỉnh" để lấy mọi tỉnh của miền xổ số trong ngày đó.
        </p>
    </div>
</div>

<c:if test="${not empty items}">
    <div class="card shadow mb-4">
        <div class="card-header d-flex flex-wrap align-items-center">
            <span class="font-weight-bold">Bước 2: Kiểm tra kết quả ngày <c:out value="${drawDateFormatted}"/></span>
            <form method="post" action="${pageContext.request.contextPath}/admin/tickets/create"
                  class="mb-0 ml-auto" data-busy="Đang xử lý vé dò, vui lòng chờ...">
                <input type="hidden" name="region" value="<c:out value='${selRegion}'/>">
                <input type="hidden" name="company" value="<c:out value='${selCompany}'/>">
                <input type="hidden" name="date" value="<c:out value='${dateValue}'/>">
                <button type="submit" name="action" value="save" class="btn btn-primary btn-sm mr-2"
                    ${successCount == 0 ? 'disabled' : ''}>
                    Lưu (${successCount})
                </button>
                <button type="submit" name="action" value="savePublish" class="btn btn-success btn-sm"
                    ${successCount == 0 ? 'disabled' : ''}
                        onclick="return confirm('Lưu và công bố ngay? Vé dò đã công bố sẽ không thể chuyển về chưa công bố.');">
                    Lưu và Publish (${successCount})
                </button>
            </form>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <span class="badge badge-primary mr-2">Sẵn sàng lưu: ${successCount}</span>
                <span class="badge badge-success mr-2">Publish: ${existsPublishedCount}</span>
                <span class="badge badge-secondary mr-2">Unpublish: ${existsUnpublishedCount}</span>
                <span class="badge badge-danger">Lỗi: ${errorCount}</span>
            </div>
            <c:forEach var="item" items="${items}">
                <div class="mb-4">
                    <div class="d-flex flex-wrap align-items-center mb-2">
                        <h5 class="mb-0 mr-3">
                            <c:choose>
                                <c:when test="${not empty item.companyName and item.status == 'EXISTS'}">
                                    <a href="${pageContext.request.contextPath}/admin/tickets/detail?id=${item.existingTicketId}"
                                       title="Xem vé dò đã có"><c:out value="${item.companyName}"/></a>
                                    <small class="text-muted">(<c:out value="${item.regionName}"/>)</small>
                                </c:when>
                                <c:when test="${not empty item.companyName}">
                                    <c:out value="${item.companyName}"/>
                                    <small class="text-muted">(<c:out value="${item.regionName}"/>)</small>
                                </c:when>
                                <c:otherwise>Tất cả tỉnh</c:otherwise>
                            </c:choose>
                        </h5>
                        <c:choose>
                            <c:when test="${item.status == 'OK'}">
                                <span class="badge badge-primary">Sẵn sàng lưu</span>
                            </c:when>
                            <c:when test="${item.status == 'EXISTS'}">
                                <span class="badge ${item.existingPublished ? 'badge-success' : 'badge-secondary'}">
                                        ${item.existingPublished ? 'Đã có - đã công bố' : 'Đã có - chưa công bố'}</span>
                            </c:when>
                            <c:otherwise>
                                <span class="badge badge-danger">Lỗi</span>
                            </c:otherwise>
                        </c:choose>
                    </div>
                    <c:choose>
                        <c:when test="${item.status == 'ERROR'}">
                            <div class="text-danger small"><c:out value="${item.message}"/></div>
                        </c:when>
                        <c:otherwise>
                            <c:set var="prizes" value="${item.prizes}" scope="request"/>
                            <jsp:include page="/WEB-INF/views/admin/_prize-table.jsp"/>
                        </c:otherwise>
                    </c:choose>
                </div>
            </c:forEach>
        </div>
    </div>
</c:if>

<jsp:include page="/WEB-INF/views/admin/_busy.jsp"/>
<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
