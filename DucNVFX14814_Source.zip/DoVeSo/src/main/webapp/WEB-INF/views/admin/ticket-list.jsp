<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>
<div class="list-page">
    <div class="d-flex flex-wrap align-items-center mb-3">
        <h3 class="mb-0">Quản lý vé dò</h3>
        <div class="ml-auto">
            <a href="${pageContext.request.contextPath}/admin/tickets/create" class="btn btn-primary">Thêm vé dò
                mới</a>
            <c:if test="${sessionScope.currentUser.id == 10000000}">
                <a href="${pageContext.request.contextPath}/admin/tickets/create-batch" class="btn btn-info mr-2">
                    <i class="fas fa-layer-group"></i> Thêm hàng loạt</a>
            </c:if>
        </div>
    </div>
    <p class="text-muted">Kết quả xổ số kiến thiết ba miền. Người dùng chỉ dò được các vé dò đã công bố.</p>

    <c:if test="${not empty success}">
        <div class="alert alert-success"><c:out value="${success}"/></div>
    </c:if>
    <c:if test="${not empty error}">
        <div class="alert alert-danger"><c:out value="${error}"/></div>
    </c:if>

    <div class="card shadow list-card">
        <div class="card-body">
            <form method="get" action="${pageContext.request.contextPath}/admin/tickets" class="form-inline mb-3">
                <jsp:include page="/WEB-INF/views/admin/_company-select.jsp"/>
                <label for="fromDate" class="mr-2 mb-2">Từ ngày</label>
                <input type="date" id="fromDate" name="fromDate" value="<c:out value='${fromDate}'/>"
                       class="form-control mr-3 mb-2">
                <label for="toDate" class="mr-2 mb-2">Đến ngày</label>
                <input type="date" id="toDate" name="toDate" value="<c:out value='${toDate}'/>"
                       class="form-control mr-3 mb-2">
                <label for="statusSel" class="mr-2 mb-2">Trạng thái</label>
                <select id="statusSel" name="status" class="form-control mr-3 mb-2">
                    <option value="">Tất cả trạng thái</option>
                    <option value="PUBLISH" ${selStatus == 'PUBLISH' ? 'selected' : ''}>Đã công bố</option>
                    <option value="UNPUBLISH" ${selStatus == 'UNPUBLISH' ? 'selected' : ''}>Chưa công bố</option>
                </select>
                <button type="submit" class="btn btn-primary mr-2 mb-2">Tìm kiếm</button>
                <a href="${pageContext.request.contextPath}/admin/tickets" class="btn btn-secondary mb-2">Xóa bộ lọc</a>
            </form>

            <c:choose>
                <c:when test="${empty tickets}">
                    <c:if test="${not filterInvalid}">
                        <div class="text-center text-muted py-5">
                            Không tìm thấy vé dò phù hợp.
                        </div>
                    </c:if>
                </c:when>
                <c:otherwise>
                    <div class="list-scroll">
                        <table class="table table-bordered table-hover mb-0">
                            <thead class="thead-light">
                            <tr>
                                <th>Ngày mở thưởng</th>
                                <th>Miền</th>
                                <th>Tỉnh</th>
                                <th style="width: 180px;">Trạng thái</th>
                                <th style="width: 200px;">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                            <c:forEach var="t" items="${tickets}">
                                <tr>
                                    <td><c:out value="${t.drawDateFormatted}"/></td>
                                    <td><c:out value="${t.regionName}"/></td>
                                    <td><c:out value="${t.companyName}"/></td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${t.published}">
                                                <span class="badge badge-success">Đã công bố</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge badge-warning">Chưa công bố</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <a href="${pageContext.request.contextPath}/admin/tickets/detail?id=${t.id}"
                                           class="btn btn-sm btn-outline-primary">Xem</a>
                                        <c:if test="${not t.published}">
                                            <form method="post" class="d-inline"
                                                  action="${pageContext.request.contextPath}/admin/tickets/publish"
                                                  onsubmit="return confirm('Bạn có chắc muốn công bố vé dò này?');">
                                                <input type="hidden" name="id" value="${t.id}">
                                                <input type="hidden" name="from" value="list">
                                                <input type="hidden" name="query"
                                                       value="<c:out value='${pageContext.request.queryString}'/>">
                                                <button type="submit" class="btn btn-sm btn-success">Publish</button>
                                            </form>
                                        </c:if>
                                    </td>
                                </tr>
                            </c:forEach>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex flex-wrap align-items-center mt-3">
                        <span class="text-muted">Tổng cộng ${total} vé dò - trang ${currentPage}/${totalPages}</span>
                        <c:if test="${totalPages > 1}">
                            <nav class="ml-auto">
                                <ul class="pagination mb-0">
                                    <c:forEach begin="1" end="${totalPages}" var="p">
                                        <li class="page-item ${p == currentPage ? 'active' : ''}">
                                            <a class="page-link"
                                               href="?region=<c:out value='${selRegion}'/>&company=<c:out value='${selCompany}'/>&fromDate=<c:out value='${fromDate}'/>&toDate=<c:out value='${toDate}'/>&status=<c:out value='${selStatus}'/>&page=${p}">${p}</a>
                                        </li>
                                    </c:forEach>
                                </ul>
                            </nav>
                        </c:if>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</div>
<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
