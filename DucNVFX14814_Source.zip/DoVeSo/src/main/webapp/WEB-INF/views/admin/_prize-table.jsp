<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- Bang cac giai cua 1 ve do. Yeu cau request attribute "prizes" (List<LotteryPrize>). --%>
<div class="table-responsive">
    <table class="table table-bordered lottery-prize-table mb-0">
        <tbody>
        <c:forEach var="p" items="${prizes}">
            <tr class="${p.prizeCode == 'DB' ? 'prize-row-special' : ''}">
                <td class="prize-label"><c:out value="${p.prizeName}"/></td>
                <td class="prize-numbers">
                    <c:forEach var="n" items="${p.numbers}">
                        <span class="prize-number ${p.prizeCode == 'DB' ? 'prize-number-special' : ''}"><c:out
                                value="${n}"/></span>
                    </c:forEach>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
