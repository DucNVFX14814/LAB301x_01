<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%-- Duong dan goc cua trang dang xem (trang duoc forward tu servlet nen phai lay tu attribute forward) --%>
<c:set var="currentUri" value="${requestScope['javax.servlet.forward.request_uri']}"/>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dò Vé Số - Tra cứu kết quả xổ số kiến thiết miền Bắc</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/admin/vendor/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <style>
        /* ===== Thanh dieu huong (header) trang nguoi dung ===== */
        .main-navbar {
            --bs-navbar-color: #fff;
            --bs-navbar-hover-color: #fff;
            --bs-navbar-active-color: #fff;
            padding-top: .6rem;
            padding-bottom: .6rem;
        }
        .main-navbar .navbar-brand { font-size: 1.4rem; font-weight: 800; letter-spacing: .02rem; }
        .main-navbar .nav-link {
            font-weight: 600;
            padding: .55rem .95rem;
            border-radius: .5rem;
            transition: background-color .15s ease;
        }
        .main-navbar .nav-link:hover,
        .main-navbar .nav-link:focus { background-color: rgba(255, 255, 255, .18); }
        .main-navbar .nav-link.active {
            background-color: rgba(255, 255, 255, .25);
            box-shadow: inset 0 -3px 0 #fff;
        }
        .main-navbar .nav-user { display: inline-flex; align-items: center; color: #fff; padding: .55rem .95rem; }
        .main-navbar .nav-user .greeting { opacity: .85; margin-right: .25rem; }
        .main-navbar .btn { font-weight: 600; }
        @media (max-width: 991.98px) {
            .main-navbar .navbar-nav { padding-top: .75rem; gap: .25rem; }
            .main-navbar .nav-link { padding: .7rem 1rem; }
            .main-navbar .btn { width: 100%; margin-top: .25rem; }
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary main-navbar shadow-sm">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="${pageContext.request.contextPath}/">
            <i class="fas fa-ticket-alt me-2"></i>Dò Vé Số
        </a>
        <%-- [Header] Các trang đăng nhập/đăng ký/quên & đặt lại mật khẩu đặt requestScope.hideNavActions=true:
             chỉ hiện logo, ẩn toàn bộ menu bên phải (kể cả khi trình duyệt còn session). Mở lại: bỏ c:if bên dưới. --%>
        <c:if test="${not hideNavActions}">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
                aria-controls="mainNav" aria-expanded="false" aria-label="Mở menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <%-- [CN3] Admin không hỗ trợ dò vé: ẩn link với ADMIN. Mở lại: bỏ thẻ c:if bên dưới --%>
                <c:if test="${sessionScope.currentUser.role != 'ADMIN'}">
                <li class="nav-item">
                    <a class="nav-link ${fn:contains(currentUri, '/check-ticket') ? 'active' : ''}"
                       href="${pageContext.request.contextPath}/check-ticket">
                        <i class="fas fa-search me-1"></i>Dò vé số</a>
                </li>
                </c:if>
                <c:choose>
                    <c:when test="${not empty sessionScope.currentUser}">
                        <%-- [CN3] Admin không dò vé nên không có lịch sử dò: ẩn với ADMIN. Mở lại: bỏ thẻ c:if --%>
                        <c:if test="${sessionScope.currentUser.role != 'ADMIN'}">
                        <li class="nav-item">
                            <a class="nav-link ${fn:contains(currentUri, '/user/history') ? 'active' : ''}"
                               href="${pageContext.request.contextPath}/user/history">
                                <i class="fas fa-history me-1"></i>Lịch sử dò vé</a>
                        </li>
                        </c:if>
                        <%-- [CN3] Gợi ý số không dành cho ADMIN: ẩn với ADMIN. Mở lại: bỏ thẻ c:if --%>
                        <c:if test="${sessionScope.currentUser.role != 'ADMIN'}">
                        <li class="nav-item">
                            <a class="nav-link ${fn:contains(currentUri, '/number-suggestion') ? 'active' : ''}"
                               href="${pageContext.request.contextPath}/user/number-suggestion">
                                <i class="fas fa-lightbulb me-1"></i>Gợi ý số</a>
                        </li>
                        </c:if>
                        <li class="nav-item">
                            <a class="nav-link ${fn:contains(currentUri, '/user/change-password') ? 'active' : ''}"
                               href="${pageContext.request.contextPath}/user/change-password">
                                <i class="fas fa-key me-1"></i>Đổi mật khẩu</a>
                        </li>
                        <li class="nav-item">
                            <span class="nav-user">
                                <i class="fas fa-user-circle me-2"></i>
                                <span class="greeting">Xin chào,</span>
                                <strong><c:out value="${sessionScope.currentUser.shortName}"/></strong>
                            </span>
                        </li>
                        <%-- [CN3] Ẩn nút "Quản lý" (ADMIN không dùng giao diện người dùng). Mở lại: bỏ comment khối này
                        <c:if test="${sessionScope.currentUser.role == 'ADMIN'}">
                            <li class="nav-item">
                                <a class="btn btn-outline-light ms-lg-2" href="${pageContext.request.contextPath}/admin/users">
                                    <i class="fas fa-user-shield me-1"></i>Quản lý</a>
                            </li>
                        </c:if>
                        --%>
                        <li class="nav-item">
                            <a class="btn btn-outline-light ms-lg-2" href="${pageContext.request.contextPath}/logout">
                                <i class="fas fa-sign-out-alt me-1"></i>Đăng xuất</a>
                        </li>
                    </c:when>
                    <c:otherwise>
                        <li class="nav-item">
                            <a class="nav-link ${fn:contains(currentUri, '/login') ? 'active' : ''}"
                               href="${pageContext.request.contextPath}/login">
                                <i class="fas fa-sign-in-alt me-1"></i>Đăng nhập</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-light text-primary ms-lg-2" href="${pageContext.request.contextPath}/register">
                                <i class="fas fa-user-plus me-1"></i>Đăng ký</a>
                        </li>
                    </c:otherwise>
                </c:choose>
            </ul>
        </div>
        </c:if>
    </div>
</nav>
<div class="container my-4 flex-grow-1">
