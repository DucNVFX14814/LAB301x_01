<%@ include file="/WEB-INF/views/common/header.jsp" %>
<div class="text-center py-5">
    <h1 class="display-4">404</h1>
    <p class="lead">Không tìm thấy trang bạn yêu cầu.</p>
    <a href="${pageContext.request.contextPath}/" class="btn btn-primary">Về trang chủ</a>
</div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
