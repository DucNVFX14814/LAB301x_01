<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%--
    Bo chon Mien + Tinh (dung chung cho Do ve, Lich su do ve, Goi y so - ngoai admin).
    Request attribute can co: regions, companies, selRegion, selCompany,
    allowAllCompany (boolean, mac dinh false):
        true  -> co them tuy chon "Tat ca tinh" (dung cho bo loc, khong bat buoc chon).
        false -> khong co tuy chon "Tat ca tinh", bat buoc phai chon 1 tinh cu the.
    Mien luon co tuy chon "Tat ca mien" - chi dung de loc nhanh danh sach Tinh hien thi, khong anh huong
    logic nghiep vu (chi Tinh moi quyet dinh du lieu tra ve).
    Ten tham so gui di: region, company.
    Yeu cau: sinh id duy nhat cho form neu 1 trang co nhieu form dung partial nay (truyen inputId).
--%>
<c:set var="regionSelId" value="${empty inputId ? 'regionSel' : inputId.concat('RegionSel')}"/>
<c:set var="companySelId" value="${empty inputId ? 'companySel' : inputId.concat('CompanySel')}"/>

<div class="col-6 mb-3 region-company-col">
    <label for="${regionSelId}" class="form-label">Miền</label>
    <select id="${regionSelId}" name="region" class="form-select form-select-sm">
        <option value="">Tất cả miền</option>
        <c:forEach var="r" items="${regions}">
            <option value="<c:out value='${r.regionCode}'/>" ${r.regionCode == selRegion ? 'selected' : ''}>
                <c:out value="${r.regionName}"/></option>
        </c:forEach>
    </select>
</div>
<div class="col-6 mb-3 region-company-col">
    <label for="${companySelId}" class="form-label">Tỉnh</label>
    <select id="${companySelId}" name="company" class="form-select form-select-sm" ${allowAllCompany ? '' : 'required'}>
        <c:choose>
            <c:when test="${allowAllCompany}">
                <option value="">Tất cả tỉnh</option>
            </c:when>
            <c:otherwise>
                <option value="" data-placeholder="1" ${empty selCompany ? 'selected' : ''} disabled>-- Chọn tỉnh --</option>
            </c:otherwise>
        </c:choose>
        <c:forEach var="c" items="${companies}">
            <option value="<c:out value='${c.companyCode}'/>" data-region="<c:out value='${c.regionCode}'/>"
                ${c.companyCode == selCompany ? 'selected' : ''}><c:out value="${c.companyName}"/></option>
        </c:forEach>
    </select>
</div>
<script>
    // Loc danh sach tinh theo mien dang chon (dung cach dung lai option thay vi an option de chay tot tren mobile)
    (function () {
        var region = document.getElementById('${regionSelId}');
        var company = document.getElementById('${companySelId}');
        var all = Array.prototype.slice.call(company.options);

        function rebuild(keepValue) {
            var r = region.value;
            company.innerHTML = '';
            all.forEach(function (o) {
                if (o.getAttribute('data-placeholder') || !r || o.getAttribute('data-region') === r || o.value === '') {
                    company.appendChild(o);
                }
            });
            var found = false;
            Array.prototype.forEach.call(company.options, function (o, i) {
                if (o.value === keepValue && keepValue !== '') {
                    company.selectedIndex = i;
                    found = true;
                }
            });
            if (!found) {
                company.selectedIndex = 0;
            }
        }

        region.addEventListener('change', function () {
            rebuild('');
        });
        rebuild(company.value);
    })();
</script>
