</div>
<footer class="bg-dark text-white py-3 mt-auto">
    <div class="container text-center">
        <div class="small fw-bold">&copy; 2026 Dò Vé Số - Đồ án môn LAB301x</div>
        <div class="small fw-bold">Học viên DucNVFX14814 - Nguyễn Việt Đức</div>
    </div>
</footer>
<script src="${pageContext.request.contextPath}/assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>