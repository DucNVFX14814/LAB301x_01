<%@ page isErrorPage="true" %>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<div class="text-center py-5">
    <h1 class="display-4">500</h1>
    <p class="lead">Đã có lỗi xảy ra phía máy chủ. Vui lòng thử lại sau.</p>
    <a href="${pageContext.request.contextPath}/" class="btn btn-primary">Về trang chủ</a>
</div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
