<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang quản trị - Dò Vé Số</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/admin/css/sb-admin-2.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/admin/vendor/fontawesome-free/css/all.min.css">
    <style>
        /* ===== Bo cuc chung (mac dinh, ap dung cho man hinh nho: dien thoai/tablet) =====
           Cuon tu nhien theo toan trang, khong ep chieu cao cua bat ky khoi nao, de tranh
           tinh trang noi dung (bang du lieu) bi bop qua nho tren man hinh nho.
           Rieng bo cuc "co dinh + cuon noi bo" (sidebar/topbar dung yen) chi ap dung cho
           man hinh may tinh, xem khoi @media (min-width: 768px) ben duoi. */
        html, body { height: 100%; }
        #content > .container-fluid { padding-top: 1rem; }
        .pagination { flex-wrap: wrap; }
        .list-page { padding-bottom: 1.5rem; }
        .list-scroll { overflow-x: auto; }
        .list-scroll th, .list-scroll td { white-space: nowrap; }
        #content h3 { font-size: 1.4rem; }

        /* ===== Thanh tren cung (chi hien tren mobile, < 768px). Khong sticky de khong "fix"
           chiem cho tren man hinh nho, cuon di theo trang nhu binh thuong. ===== */
        .topbar { display: flex; align-items: center; flex: 0 0 auto; height: 3.5rem; padding: 0 .75rem; background: #fff;
            box-shadow: 0 .15rem 1.75rem 0 rgba(58, 59, 69, .15); }
        .topbar-btn { border: 0; background: transparent; font-size: 1.6rem; line-height: 1; padding: .25rem .6rem; color: #4e73df; cursor: pointer; }
        .topbar-title { font-weight: 800; color: #4e73df; margin-left: .5rem; text-transform: uppercase; letter-spacing: .05rem; font-size: 1rem; }
        .sidebar-backdrop { display: none; }

        /* ===== Sidebar tren mobile: la ngan keo an (drawer), mo bang nut menu tren thanh tren cung.
           Dung position: fixed rieng cho ngan keo nay (khong lien quan bo cuc "fix" toan trang). ===== */
        @media (max-width: 767.98px) {
            #wrapper .sidebar { position: fixed; top: 0; bottom: 0; left: 0; width: 14rem; z-index: 1050;
                overflow-y: auto; transform: translateX(-100%); transition: transform .2s ease; }
            #wrapper .sidebar .sidebar-brand .sidebar-brand-text { display: inline; }
            #wrapper .sidebar .nav-item .nav-link { width: 100%; text-align: left; padding: 1rem; }
            #wrapper .sidebar .nav-item .nav-link span { font-size: .85rem; display: inline; }
            #wrapper .sidebar .nav-item .nav-link i { font-size: .85rem; margin-right: .25rem; }
            body.sidebar-open #wrapper .sidebar { transform: none; }
            body.sidebar-open .sidebar-backdrop { display: block; position: fixed; top: 0; right: 0; bottom: 0; left: 0;
                background: rgba(0, 0, 0, .45); z-index: 1040; }
        }

        /* ===== Man hinh may tinh (>= 768px): sidebar co dinh, chi vung noi dung ben phai cuon,
           trang danh sach dung yen phan tieu de/tim kiem/phan trang, chi bang du lieu cuon rieng. ===== */
        @media (min-width: 768px) {
            #wrapper { height: 100vh; height: 100dvh; overflow: hidden; }
            #wrapper .sidebar { flex-shrink: 0; height: 100vh; height: 100dvh; min-height: 0; overflow-y: auto; overflow-x: hidden; }
            #wrapper #content-wrapper { overflow-y: auto; }
            #content { flex: 1 0 auto; }

            .list-page { display: flex; flex-direction: column; height: calc(100vh - 1rem); height: calc(100dvh - 1rem); min-height: 520px; }
            .list-page > * { flex-shrink: 0; }
            .list-page > .list-card { flex: 1 1 auto; min-height: 0; margin-bottom: 0; }
            .list-card > .card-body { display: flex; flex-direction: column; min-height: 0; }
            .list-card .card-body > * { flex-shrink: 0; }
            .list-card .card-body > .list-scroll { flex: 1 1 auto; min-height: 0; overflow: auto; }
            .list-scroll thead th { position: sticky; top: 0; z-index: 1; box-shadow: inset 0 -2px 0 #e3e6f0; }
        }

        /* ===== Bang giai cua 1 ve do (dung o Chi tiet ve do, Them ve do, Them hang loat) ===== */
        .lottery-prize-table td { vertical-align: middle; padding: .55rem .75rem; }
        .lottery-prize-table .prize-label {
            width: 130px; font-weight: 700; color: #5a5c69; background-color: #f8f9fc; white-space: nowrap;
        }
        .lottery-prize-table .prize-numbers { text-align: center; }
        .lottery-prize-table .prize-number {
            display: inline-block; font-family: "Courier New", monospace; font-size: 1.1rem;
            font-weight: 600; letter-spacing: 1px; margin: 0 .8rem;
        }
        .lottery-prize-table .prize-row-special { background-color: #fff8e1; }
        .lottery-prize-table .prize-row-special .prize-label { background-color: #ffecb3; color: #7a5b00; }
        .lottery-prize-table .prize-number-special { color: #e02424; font-size: 1.4rem; font-weight: 800; }

        /* ===== inactive */
        .row-inactive { color: #535658; background-color: #ececec; }
        .row-inactive td { opacity: 0.8; }
        .row-inactive td select { opacity: 1; }
    </style>
    <script>
        // Mo/dong sidebar tren mobile (dung uy quyen su kien nen chay duoc du script nam trong head)
        (function () {
            function setOpen(open) {
                document.body.classList.toggle('sidebar-open', open);
                var btn = document.getElementById('sidebarOpenBtn');
                if (btn) {
                    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
                }
            }
            document.addEventListener('click', function (e) {
                var t = e.target;
                if (!t || !t.closest) {
                    return;
                }
                if (t.closest('#sidebarOpenBtn')) {
                    setOpen(!document.body.classList.contains('sidebar-open'));
                } else if (t.closest('#sidebarBackdrop') || t.closest('#accordionSidebar a')) {
                    setOpen(false);
                }
            });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') {
                    setOpen(false);
                }
            });
            window.addEventListener('resize', function () {
                if (window.innerWidth >= 768) {
                    setOpen(false);
                }
            });
        })();
    </script>
</head>
<body id="page-top">
<div id="wrapper">
    <!-- Sidebar (dua tren template SB Admin 2 - Bootstrap, MIT License) -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="${pageContext.request.contextPath}/admin/users">
            <div class="sidebar-brand-text mx-3">Dò Vé Số Admin</div>
        </a>
        <hr class="sidebar-divider my-0">
        <li class="nav-item">
            <a class="nav-link" href="${pageContext.request.contextPath}/admin/users">
                <i class="fas fa-fw fa-users"></i> <span>Quản lý người dùng</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="${pageContext.request.contextPath}/admin/tickets">
                <i class="fas fa-fw fa-ticket-alt"></i> <span>Quản lý vé dò</span></a>
        </li>
        <hr class="sidebar-divider">
        <%-- [CN3] Admin không hỗ trợ dò vé (theo SRS). Mở lại nếu cần: bỏ comment khối này
             và đặt ADMIN_CHECK_ENABLED = true trong AdminCheckTicketBlockFilter.
        <li class="nav-item">
            <a class="nav-link" href="${pageContext.request.contextPath}/check-ticket" target="_blank" rel="noopener">
                <i class="fas fa-fw fa-search"></i> <span>Dò vé số</span></a>
        </li>
        --%>
        <li class="nav-item">
            <a class="nav-link" href="${pageContext.request.contextPath}/user/change-password">
                <i class="fas fa-fw fa-key"></i> <span>Đổi mật khẩu</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="${pageContext.request.contextPath}/logout">
                <i class="fas fa-fw fa-sign-out-alt"></i> <span>Đăng xuất</span></a>
        </li>
        <hr class="sidebar-divider">
    </ul>
    <!-- End Sidebar -->
    <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

    <div id="content-wrapper" class="d-flex flex-column">
        <!-- Thanh tren cung: chi hien tren mobile -->
        <nav class="topbar d-md-none">
            <button type="button" id="sidebarOpenBtn" class="topbar-btn" aria-label="Mở menu"
                    aria-controls="accordionSidebar" aria-expanded="false">&#9776;</button>
            <span class="topbar-title">Dò Vé Số Admin</span>
        </nav>
        <div id="content">
            <div class="container-fluid">
