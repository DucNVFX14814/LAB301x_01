</div>
</div>
</div>
</div>
<script src="${pageContext.request.contextPath}/assets/admin/vendor/jquery/jquery.min.js"></script>
<script>
    // Khong nap Bootstrap JS o admin (sidebar mobile tu viet rieng), nhung sb-admin-2.min.js
    // van goi $(...).collapse("hide") khi resize. Bo sung ham rong de tranh loi console.
    if (!jQuery.fn.collapse) {
        jQuery.fn.collapse = function () {
            return this;
        };
    }
</script>
<script src="${pageContext.request.contextPath}/assets/admin/js/sb-admin-2.min.js"></script>
</body>
</html>
