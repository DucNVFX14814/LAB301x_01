<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- Trang không liên quan đến tài khoản đang đăng nhập: header chỉ hiện logo --%>
<% request.setAttribute("hideNavActions", Boolean.TRUE); %>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<div class="row justify-content-center">
    <div class="col-md-5">
        <h3 class="mb-2 text-center">Quên mật khẩu</h3>
        <p class="text-muted text-center mb-4">
            Nhập email đã đăng ký, chúng tôi sẽ gửi liên kết đặt lại mật khẩu (có hiệu lực 30 phút).
        </p>

        <c:if test="${not empty error}">
            <div class="alert alert-danger"><c:out value="${error}"/></div>
        </c:if>
        <c:if test="${not empty message}">
            <div class="alert alert-success"><c:out value="${message}"/></div>
        </c:if>

        <form method="post" action="${pageContext.request.contextPath}/forgot-password">
            <div class="mb-3">
                <label class="form-label" for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control"
                       value="<c:out value='${email}'/>" placeholder="ten@example.com" required autofocus>
            </div>
            <button type="submit" class="btn btn-primary w-100">
                <i class="fas fa-paper-plane me-1"></i>Gửi yêu cầu
            </button>
        </form>

        <div class="text-center mt-3">
            <a href="${pageContext.request.contextPath}/login">Quay lại đăng nhập</a>
        </div>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
