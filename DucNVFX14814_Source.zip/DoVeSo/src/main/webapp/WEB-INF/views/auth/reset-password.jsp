<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- Trang không liên quan đến tài khoản đang đăng nhập: header chỉ hiện logo --%>
<% request.setAttribute("hideNavActions", Boolean.TRUE); %>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<div class="row justify-content-center">
    <div class="col-md-5">
        <h3 class="mb-4 text-center">Đặt lại mật khẩu</h3>

        <c:choose>
            <c:when test="${invalid}">
                <div class="alert alert-danger">
                    Liên kết đặt lại mật khẩu không hợp lệ hoặc đã hết hạn.
                </div>
                <a href="${pageContext.request.contextPath}/forgot-password" class="btn btn-primary w-100">
                    <i class="fas fa-redo me-1"></i>Yêu cầu liên kết mới
                </a>
            </c:when>
            <c:otherwise>
                <p class="text-muted text-center">
                    Đặt mật khẩu mới cho tài khoản <strong><c:out value="${resetEmail}"/></strong>
                </p>

                <c:if test="${not empty error}">
                    <div class="alert alert-danger"><c:out value="${error}"/></div>
                </c:if>

                <form method="post" action="${pageContext.request.contextPath}/reset-password">
                    <input type="hidden" name="token" value="<c:out value='${token}'/>">
                    <div class="mb-3">
                        <label class="form-label" for="password">Mật khẩu mới</label>
                        <input type="password" id="password" name="password" class="form-control"
                               minlength="6" required autofocus
                               oninvalid="this.setCustomValidity('Vui lòng nhập mật khẩu dài từ 6 ký tự trở lên!')"
                               oninput="this.setCustomValidity('')">
                        <div class="form-text">Tối thiểu 6 ký tự.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="confirmPassword">Xác nhận mật khẩu mới</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" class="form-control"
                               minlength="6" required
                               oninvalid="this.setCustomValidity('Vui lòng nhập mật khẩu dài từ 6 ký tự trở lên!')"
                               oninput="this.setCustomValidity('')">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-key me-1"></i>Đặt lại mật khẩu
                    </button>
                </form>
            </c:otherwise>
        </c:choose>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
