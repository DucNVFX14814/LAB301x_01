<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%-- Trang không liên quan đến tài khoản đang đăng nhập: header chỉ hiện logo --%>
<% request.setAttribute("hideNavActions", Boolean.TRUE); %>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<div class="row justify-content-center">
    <div class="col-md-6">
        <h3 class="mb-4 text-center">Đăng ký tài khoản</h3>
        <p class="text-muted small mb-4">Các trường có dấu <span class="text-danger">(*)</span> là bắt buộc.</p>

        <c:if test="${not empty error}">
            <div class="alert alert-danger">${error}</div>
        </c:if>

        <form method="post" action="${pageContext.request.contextPath}/register">
            <div class="mb-3">
                <label class="form-label">Họ và tên <span class="text-danger">(*)</span></label>
                <input type="text" name="fullName" class="form-control" maxlength="150" required
                       value="${fn:escapeXml(param.fullName)}">
            </div>
            <div class="mb-3">
                <label class="form-label">Email <span class="text-danger">(*)</span></label>
                <input type="email" name="email" class="form-control" maxlength="150" required
                       value="${fn:escapeXml(param.email)}">
            </div>
            <div class="mb-3">
                <label class="form-label">Số điện thoại <span class="text-danger">(*)</span></label>
                <input type="text" name="phone" class="form-control" placeholder="0xxxxxxxxx"
                       pattern="0\d{9}" title="Bắt đầu bằng số 0 và có đúng 10 chữ số" required
                       value="${fn:escapeXml(param.phone)}">
            </div>
            <div class="mb-3">
                <label class="form-label">Mật khẩu <span class="text-danger">(*)</span></label>
                <input type="password" name="password" class="form-control" required minlength="6"
                       title="Tối thiểu 6 ký tự"
                       oninvalid="this.setCustomValidity('Vui lòng nhập mật khẩu dài từ 6 ký tự trở lên!')"
                       oninput="this.setCustomValidity('')">
            </div>
            <div class="mb-3">
                <label class="form-label">Xác nhận mật khẩu <span class="text-danger">(*)</span></label>
                <input type="password" name="confirmPassword" class="form-control" required minlength="6"
                       oninvalid="this.setCustomValidity('Vui lòng nhập mật khẩu dài từ 6 ký tự trở lên!')"
                       oninput="this.setCustomValidity('')">
            </div>
            <button type="submit" class="btn btn-primary w-100">Đăng ký</button>
        </form>

        <div class="text-center mt-3">
            <a href="${pageContext.request.contextPath}/login">Đã có tài khoản? Đăng nhập</a>
        </div>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
