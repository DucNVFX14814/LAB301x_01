<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<div class="row justify-content-center">
    <div class="col-md-10">
        <h3 class="mb-2 text-center">Đề xuất số vé số nên mua</h3>
        <p class="text-center text-muted">Thống kê tần suất về của 2 số cuối theo từng công ty xổ số</p>

        <c:if test="${not empty error}">
            <div class="alert alert-danger"><c:out value="${error}"/></div>
        </c:if>

        <div class="card shadow mb-4">
            <div class="card-body">
                <form method="get" action="${pageContext.request.contextPath}/user/number-suggestion">
                    <div class="row align-items-end">
                        <jsp:include page="/WEB-INF/views/common/_region-company-select.jsp"/>
                        <div class="col-12 col-md-3 mb-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-chart-column me-1"></i>Xem thống kê
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <c:if test="${not empty result}">
        <div class="alert alert-warning small">
            <i class="fas fa-triangle-exclamation me-1"></i>
            Đây chỉ là thống kê tham khảo dựa trên dữ liệu quá khứ trong hệ thống.
            Xổ số kiến thiết là trò chơi hoàn toàn ngẫu nhiên, kết quả các kỳ sau không phụ thuộc vào kỳ trước.
            Vui lòng cân nhắc và chơi có trách nhiệm.
        </div>

        <c:choose>
            <c:when test="${result.noData}">
                <div class="alert alert-info text-center">
                    Chưa có đủ dữ liệu vé dò đã công bố để thống kê. Vui lòng quay lại sau.
                </div>
            </c:when>
            <c:otherwise>
                <p class="text-muted text-center small mb-4">
                    <c:out value="${selCompanyName}"/> - dựa trên ${result.totalDraws} kỳ quay số,
                    gần nhất ngày ${result.latestDrawDateFormatted}.
                </p>

                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card shadow h-100">
                            <div class="card-header fw-bold text-success">
                                <i class="fas fa-fire me-1"></i>Top ${result.hotNumbers.size()} số về nhiều nhất
                            </div>
                            <div class="card-body">
                                <div class="number-grid number-grid-5">
                                    <c:forEach var="n" items="${result.hotNumbers}">
                                        <div class="number-pill number-pill-hot">
                                            <span class="number-pill-value"><c:out value="${n.number}"/></span>
                                            <span class="number-pill-meta">${n.frequency} lượt</span>
                                        </div>
                                    </c:forEach>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="card shadow h-100">
                            <div class="card-header fw-bold text-primary">
                                <i class="fas fa-snowflake me-1"></i>Top ${result.coldNumbers.size()} số lâu chưa về
                            </div>
                            <div class="card-body">
                                <div class="number-grid number-grid-5">
                                    <c:forEach var="n" items="${result.coldNumbers}">
                                        <div class="number-pill number-pill-cold">
                                            <span class="number-pill-value"><c:out value="${n.number}"/></span>
                                            <span class="number-pill-meta">
                                                <c:choose>
                                                    <c:when test="${n.neverSeen}">Chưa từng về</c:when>
                                                    <c:otherwise>${n.gapDraws} kỳ</c:otherwise>
                                                </c:choose>
                                            </span>
                                        </div>
                                    </c:forEach>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>
        </c:if>

<%--        <div class="text-center mt-2 mb-4">--%>
<%--            <a href="${pageContext.request.contextPath}/check-ticket" class="btn btn-outline-primary">Dò vé số</a>--%>
<%--        </div>--%>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
