<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<%-- Co dinh dinh dang so kieu Viet Nam (dau cham ngan cach hang nghin) bat ke ngon ngu trinh duyet --%>
<fmt:setLocale value="vi_VN"/>

<h3 class="mb-4">Lịch sử dò vé số</h3>

<div class="card shadow mb-3">
    <div class="card-body">
        <form method="get" action="${pageContext.request.contextPath}/user/history">
            <div class="row align-items-end">
                <jsp:include page="/WEB-INF/views/common/_region-company-select.jsp"/>
                <div class="col-6 col-md-2 mb-3">
                    <label for="fromDateInput" class="form-label">Từ ngày</label>
                    <input type="date" id="fromDateInput" name="from" class="form-control form-control-sm"
                           max="<c:out value='${maxDate}'/>" value="<c:out value='${fromDate}'/>">
                </div>
                <div class="col-6 col-md-2 mb-3">
                    <label for="toDateInput" class="form-label">Đến ngày</label>
                    <input type="date" id="toDateInput" name="to" class="form-control form-control-sm"
                           max="<c:out value='${maxDate}'/>" value="<c:out value='${toDate}'/>">
                </div>
                <div class="col-12 col-md-2 mb-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Tìm kiếm
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<c:if test="${empty history}">
    <div class="alert alert-info">Bạn chưa dò vé số lần nào phù hợp với bộ lọc đã chọn.</div>
</c:if>

<c:if test="${not empty history}">
    <div class="card shadow mb-3">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle mb-0">
                    <thead>
                    <tr>
                        <th>Miền</th>
                        <th>Tỉnh</th>
                        <th>Ngày quay số</th>
                        <th>Số vé đã dò</th>
                        <th>Kết quả</th>
                        <th>Tổng tiền thưởng</th>
                        <th>Thời điểm dò</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach var="h" items="${history}">
                        <tr class="${not empty h.prizeAmount ? 'row-won' : ''}">
                            <td><c:out value="${h.regionName}"/></td>
                            <td><c:out value="${h.companyName}"/></td>
                            <td><c:out value="${h.drawDateFormatted}"/></td>
                            <td><strong><c:out value="${h.ticketNumber}"/></strong></td>
                            <td><c:out value="${h.resultSummary}"/></td>
                            <td>
                                <c:choose>
                                    <c:when test="${not empty h.prizeAmount}">
                                        <fmt:formatNumber value="${h.prizeAmount}" groupingUsed="true"/> đ
                                    </c:when>
                                    <c:otherwise>-</c:otherwise>
                                </c:choose>
                            </td>
                            <td><c:out value="${h.checkedAtFormatted}"/></td>
                        </tr>
                    </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="d-flex flex-wrap align-items-center">
        <span class="text-muted">Tổng cộng ${total} lượt dò - trang ${currentPage}/${totalPages}</span>
        <c:if test="${totalPages > 1}">
            <nav class="ms-auto">
                <ul class="pagination mb-0">
                    <c:forEach begin="1" end="${totalPages}" var="p">
                        <li class="page-item ${p == currentPage ? 'active' : ''}">
                            <a class="page-link"
                               href="?page=${p}&region=<c:out value='${selRegion}'/>&company=<c:out value='${selCompany}'/>&from=<c:out value='${fromDate}'/>&to=<c:out value='${toDate}'/>">${p}</a>
                        </li>
                    </c:forEach>
                </ul>
            </nav>
        </c:if>
    </div>
</c:if>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
