<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- ADMIN dung khung giao dien quan tri, USER dung khung giao dien nguoi dung --%>
<c:set var="isAdmin" value="${sessionScope.currentUser.role == 'ADMIN'}"/>
<c:choose>
    <c:when test="${isAdmin}"><jsp:include page="/WEB-INF/views/common/admin-header.jsp"/></c:when>
    <c:otherwise><jsp:include page="/WEB-INF/views/common/header.jsp"/></c:otherwise>
</c:choose>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-5">
        <h3 class="mb-4 ${isAdmin ? '' : 'text-center'}">Đổi mật khẩu</h3>

        <c:if test="${not empty error}">
            <div class="alert alert-danger"><c:out value="${error}"/></div>
        </c:if>
        <c:if test="${not empty message}">
            <div class="alert alert-success"><c:out value="${message}"/></div>
        </c:if>

        <div class="card shadow-sm">
            <div class="card-body">
                <form method="post" action="${pageContext.request.contextPath}/user/change-password">
                    <div class="${isAdmin ? 'form-group' : 'mb-3'}">
                        <label for="currentPassword">Mật khẩu hiện tại</label>
                        <input type="password" id="currentPassword" name="currentPassword" class="form-control" required autofocus>
                    </div>
                    <div class="${isAdmin ? 'form-group' : 'mb-3'}">
                        <label for="newPassword">Mật khẩu mới</label>
                        <input type="password" id="newPassword" name="newPassword" class="form-control" minlength="6" required
                               oninvalid="this.setCustomValidity('Vui lòng nhập mật khẩu dài từ 6 ký tự trở lên!')"
                               oninput="this.setCustomValidity('')">
                        <small class="text-muted">Tối thiểu 6 ký tự.</small>
                    </div>
                    <div class="${isAdmin ? 'form-group' : 'mb-3'}">
                        <label for="confirmPassword">Xác nhận mật khẩu mới</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" minlength="6" required
                               oninvalid="this.setCustomValidity('Vui lòng nhập mật khẩu dài từ 6 ký tự trở lên!')"
                               oninput="this.setCustomValidity('')">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-save me-1 mr-1"></i>Lưu
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<c:choose>
    <c:when test="${isAdmin}"><jsp:include page="/WEB-INF/views/common/admin-footer.jsp"/></c:when>
    <c:otherwise><jsp:include page="/WEB-INF/views/common/footer.jsp"/></c:otherwise>
</c:choose>
