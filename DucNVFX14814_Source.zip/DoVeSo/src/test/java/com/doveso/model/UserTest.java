package com.doveso.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit test cac ham hien thi cua User: dang nhap gan nhat, ten goi. */
class UserTest {

    private static User loggedInAt(LocalDateTime t) {
        User u = new User();
        u.setLastLoginAt(t);
        return u;
    }

    @Test
    void getLastLoginRelative_neverLoggedIn() {
        assertEquals("Chưa từng đăng nhập", new User().getLastLoginRelative());
    }

    @Test
    void getLastLoginRelative_justNow() {
        assertEquals("Vừa đăng nhập", loggedInAt(LocalDateTime.now().minusSeconds(2)).getLastLoginRelative());
    }

    @Test
    void getLastLoginRelative_seconds() {
        assertTrue(loggedInAt(LocalDateTime.now().minusSeconds(30)).getLastLoginRelative().matches("\\d+ giây trước"));
    }

    @Test
    void getLastLoginRelative_minutesHoursDays() {
        assertEquals("15 phút trước", loggedInAt(LocalDateTime.now().minusMinutes(15)).getLastLoginRelative());
        assertEquals("3 giờ trước", loggedInAt(LocalDateTime.now().minusHours(3)).getLastLoginRelative());
        assertEquals("2 ngày trước", loggedInAt(LocalDateTime.now().minusDays(2)).getLastLoginRelative());
    }

    @Test
    void getLastLoginRelative_weeksMonthsYears() {
        assertEquals("2 tuần trước", loggedInAt(LocalDateTime.now().minusDays(15)).getLastLoginRelative());
        assertEquals("3 tháng trước", loggedInAt(LocalDateTime.now().minusMonths(3)).getLastLoginRelative());
        assertEquals("2 năm trước", loggedInAt(LocalDateTime.now().minusYears(2)).getLastLoginRelative());
    }

    @Test
    void getLastLoginAtFormatted() {
        assertEquals("", new User().getLastLoginAtFormatted());
        assertEquals("05/10/2026 08:03:09",
                loggedInAt(LocalDateTime.of(2026, 10, 5, 8, 3, 9)).getLastLoginAtFormatted());
    }

    @Test
    void getShortName_shouldBeLastWordOfFullName() {
        User u = new User();
        u.setFullName("Nguyễn Việt Đức");
        assertEquals("Đức", u.getShortName());
        u.setFullName("  An  ");
        assertEquals("An", u.getShortName());
        u.setFullName("   ");
        assertEquals("", u.getShortName());
        u.setFullName(null);
        assertEquals("", u.getShortName());
    }
}
