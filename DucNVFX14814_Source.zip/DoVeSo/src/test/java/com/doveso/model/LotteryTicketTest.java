package com.doveso.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit test cac ham hien thi / tra cuu cua LotteryTicket va TicketPreviewItem. */
class LotteryTicketTest {

    @Test
    void getDrawDateFormatted_shouldUseDayMonthYear() {
        LotteryTicket t = new LotteryTicket();
        assertEquals("", t.getDrawDateFormatted());
        t.setDrawDate(LocalDate.of(2026, 10, 5));
        assertEquals("05/10/2026", t.getDrawDateFormatted());
    }

    @Test
    void isPublished_dependsOnStatus() {
        LotteryTicket t = new LotteryTicket();
        t.setStatus(LotteryTicket.STATUS_PUBLISH);
        assertTrue(t.isPublished());
        t.setStatus(LotteryTicket.STATUS_UNPUBLISH);
        assertFalse(t.isPublished());
    }

    @Test
    void getPrizeByCode_shouldFindPrizeOrReturnNull() {
        LotteryTicket t = new LotteryTicket();
        List<LotteryPrize> prizes = new ArrayList<>();
        LotteryPrize db = new LotteryPrize("DB", "Đặc biệt", "19654");
        prizes.add(db);
        prizes.add(new LotteryPrize("G1", "Giải nhất", "62219"));
        t.setPrizes(prizes);

        assertSame(db, t.getPrizeByCode("DB"));
        assertNull(t.getPrizeByCode("G7"));
    }

    @Test
    void previewItem_shouldCopyCompanyInfoAndFormatDate() {
        LotteryCompany bac = new LotteryCompany("mien-bac", "Miền Bắc", "BAC");
        TicketPreviewItem item = new TicketPreviewItem(LocalDate.of(2026, 10, 5), bac, TicketPreviewItem.OK);

        assertEquals("mien-bac", item.getCompanyCode());
        assertEquals("Miền Bắc", item.getCompanyName());
        assertEquals("05/10/2026", item.getDateFormatted());
        assertTrue(item.isOk());
    }

    @Test
    void previewItem_withoutCompany_shouldHaveNoCompanyInfo() {
        TicketPreviewItem item = new TicketPreviewItem(LocalDate.of(2026, 10, 5), null, TicketPreviewItem.ERROR);

        assertNull(item.getCompanyCode());
        assertNull(item.getCompanyName());
        assertFalse(item.isOk());
    }
}
