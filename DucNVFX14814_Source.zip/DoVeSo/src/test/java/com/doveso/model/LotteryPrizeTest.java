package com.doveso.model;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit test LotteryPrize.getNumbers(): tach chuoi "so1-so2-..." thanh danh sach so cua giai. */
class LotteryPrizeTest {

    @Test
    void getNumbers_shouldSplitByDash() {
        assertEquals(List.of("92501", "22795"), new LotteryPrize("G2", "Giải nhì", "92501-22795").getNumbers());
        assertEquals(List.of("19654"), new LotteryPrize("DB", "Đặc biệt", "19654").getNumbers());
    }

    @Test
    void getNumbers_shouldIgnoreBlankPartsAndTrimSpaces() {
        assertEquals(List.of("44", "70", "72"), new LotteryPrize("G7", "Giải bảy", "44- 70 --72").getNumbers());
    }

    @Test
    void getNumbers_nullOrBlank_shouldBeEmpty() {
        assertTrue(new LotteryPrize("G7", "Giải bảy", null).getNumbers().isEmpty());
        assertTrue(new LotteryPrize("G7", "Giải bảy", "   ").getNumbers().isEmpty());
    }
}
