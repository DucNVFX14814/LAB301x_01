package com.doveso.filter;

import org.junit.jupiter.api.Test;

import javax.servlet.FilterChain;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/** Unit test CharacterEncodingFilter: dat UTF-8 cho request va response roi chuyen tiep (ho tro tieng Viet co dau). */
class CharacterEncodingFilterTest {

    @Test
    void doFilter_shouldSetUtf8OnRequestAndResponseAndContinueTheChain() throws Exception {
        ServletRequest req = mock(ServletRequest.class);
        ServletResponse resp = mock(ServletResponse.class);
        FilterChain chain = mock(FilterChain.class);

        new CharacterEncodingFilter().doFilter(req, resp, chain);

        verify(req).setCharacterEncoding("UTF-8");
        verify(resp).setCharacterEncoding("UTF-8");
        verify(chain).doFilter(req, resp);
    }
}
