package com.doveso.filter;

import com.doveso.model.User;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit test AdminCheckTicketBlockFilter: chuc nang do ve / lich su / de xuat so khong ho tro ADMIN
 * (ADMIN bi chuyen ve /admin/users); NO_USER va USER di qua binh thuong.
 */
class AdminCheckTicketBlockFilterTest {

    private HttpServletRequest req;
    private HttpServletResponse resp;
    private HttpSession session;
    private FilterChain chain;
    private final AdminCheckTicketBlockFilter filter = new AdminCheckTicketBlockFilter();

    @BeforeEach
    void setUp() {
        req = mock(HttpServletRequest.class);
        resp = mock(HttpServletResponse.class);
        session = mock(HttpSession.class);
        chain = mock(FilterChain.class);
        when(req.getContextPath()).thenReturn("/app");
    }

    private static User userWithRole(String role) {
        User u = new User();
        u.setRole(role);
        return u;
    }

    @Test
    void doFilter_admin_shouldBeRedirectedToAdminHome() throws Exception {
        when(req.getSession(false)).thenReturn(session);
        when(session.getAttribute("currentUser")).thenReturn(userWithRole("ADMIN"));

        filter.doFilter(req, resp, chain);

        verify(resp).sendRedirect("/app/admin/users");
        verify(chain, never()).doFilter(any(), any());
    }

    @Test
    void doFilter_normalUser_shouldPassThrough() throws Exception {
        when(req.getSession(false)).thenReturn(session);
        when(session.getAttribute("currentUser")).thenReturn(userWithRole("USER"));

        filter.doFilter(req, resp, chain);

        verify(chain).doFilter(req, resp);
        verify(resp, never()).sendRedirect(anyString());
    }

    @Test
    void doFilter_guestWithoutSession_shouldPassThrough() throws Exception {
        when(req.getSession(false)).thenReturn(null);

        filter.doFilter(req, resp, chain);

        verify(chain).doFilter(req, resp);
        verify(resp, never()).sendRedirect(anyString());
    }
}
