package com.doveso.filter;

import com.doveso.model.User;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Unit test AdminAuthorizationFilter (/admin/*): chi ADMIN duoc vao; chua dang nhap -> /login; USER -> 403. */
class AdminAuthorizationFilterTest {

    private HttpServletRequest req;
    private HttpServletResponse resp;
    private HttpSession session;
    private FilterChain chain;
    private final AdminAuthorizationFilter filter = new AdminAuthorizationFilter();

    @BeforeEach
    void setUp() {
        req = mock(HttpServletRequest.class);
        resp = mock(HttpServletResponse.class);
        session = mock(HttpSession.class);
        chain = mock(FilterChain.class);
        when(req.getContextPath()).thenReturn("/app");
    }

    private static User userWithRole(String role) {
        User u = new User();
        u.setRole(role);
        return u;
    }

    @Test
    void doFilter_admin_shouldPassThrough() throws Exception {
        when(req.getSession(false)).thenReturn(session);
        when(session.getAttribute("currentUser")).thenReturn(userWithRole("ADMIN"));

        filter.doFilter(req, resp, chain);

        verify(chain).doFilter(req, resp);
        verify(resp, never()).sendRedirect(anyString());
        verify(resp, never()).sendError(org.mockito.ArgumentMatchers.anyInt(), anyString());
    }

    @Test
    void doFilter_noSession_shouldRedirectToLogin() throws Exception {
        when(req.getSession(false)).thenReturn(null);

        filter.doFilter(req, resp, chain);

        verify(resp).sendRedirect("/app/login");
        verify(chain, never()).doFilter(any(), any());
    }

    @Test
    void doFilter_sessionWithoutUser_shouldRedirectToLogin() throws Exception {
        when(req.getSession(false)).thenReturn(session);
        when(session.getAttribute("currentUser")).thenReturn(null);

        filter.doFilter(req, resp, chain);

        verify(resp).sendRedirect("/app/login");
        verify(chain, never()).doFilter(any(), any());
    }

    @Test
    void doFilter_normalUser_shouldBeForbidden() throws Exception {
        when(req.getSession(false)).thenReturn(session);
        when(session.getAttribute("currentUser")).thenReturn(userWithRole("USER"));

        filter.doFilter(req, resp, chain);

        verify(resp).sendError(eq(HttpServletResponse.SC_FORBIDDEN), anyString());
        verify(chain, never()).doFilter(any(), any());
    }
}
