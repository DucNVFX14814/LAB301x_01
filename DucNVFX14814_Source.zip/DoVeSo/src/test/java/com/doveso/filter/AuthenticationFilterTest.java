package com.doveso.filter;

import com.doveso.model.User;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Unit test AuthenticationFilter (/user/*): chi nguoi da dang nhap duoc vao, con lai ve /login. */
class AuthenticationFilterTest {

    private HttpServletRequest req;
    private HttpServletResponse resp;
    private HttpSession session;
    private FilterChain chain;
    private final AuthenticationFilter filter = new AuthenticationFilter();

    @BeforeEach
    void setUp() {
        req = mock(HttpServletRequest.class);
        resp = mock(HttpServletResponse.class);
        session = mock(HttpSession.class);
        chain = mock(FilterChain.class);
        when(req.getContextPath()).thenReturn("/app");
    }

    @Test
    void doFilter_loggedIn_shouldPassThrough() throws Exception {
        when(req.getSession(false)).thenReturn(session);
        when(session.getAttribute("currentUser")).thenReturn(new User());

        filter.doFilter(req, resp, chain);

        verify(chain).doFilter(req, resp);
    }

    @Test
    void doFilter_noSession_shouldRedirectToLogin() throws Exception {
        when(req.getSession(false)).thenReturn(null);

        filter.doFilter(req, resp, chain);

        verify(resp).sendRedirect("/app/login");
        verify(chain, never()).doFilter(any(), any());
    }

    @Test
    void doFilter_sessionWithoutUser_shouldRedirectToLogin() throws Exception {
        when(req.getSession(false)).thenReturn(session);
        when(session.getAttribute("currentUser")).thenReturn(null);

        filter.doFilter(req, resp, chain);

        verify(resp).sendRedirect("/app/login");
        verify(chain, never()).doFilter(any(), any());
    }
}
