package com.doveso.util;

import org.junit.jupiter.api.Test;

import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

/** Unit test ConfigUtil: bien moi truong ghi de len gia tri trong file properties. */
class ConfigUtilTest {

    private static final String MISSING_ENV = "DOVESO_TEST_BIEN_KHONG_TON_TAI_9f3a";

    @Test
    void env_unsetVariable_shouldReturnNull() {
        assertNull(ConfigUtil.env(MISSING_ENV));
    }

    @Test
    void overrideFromEnv_unsetVariable_shouldKeepFileValue() {
        Properties props = new Properties();
        props.setProperty("db.password", "tu-file");

        ConfigUtil.overrideFromEnv(props, "db.password", MISSING_ENV);

        assertEquals("tu-file", props.getProperty("db.password"));
    }

    @Test
    void overrideFromEnv_existingVariable_shouldOverrideFileValue() {
        String path = ConfigUtil.env("PATH");
        if (path == null) {
            return; // moi truong khong co bien PATH: bo qua
        }
        Properties props = new Properties();
        props.setProperty("x", "tu-file");

        ConfigUtil.overrideFromEnv(props, "x", "PATH");

        assertNotNull(props.getProperty("x"));
        assertEquals(path, props.getProperty("x"));
    }
}
