package com.doveso.util;

import com.doveso.model.LotteryPrize;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit test thuat toan doi chieu trung giai LotteryCheckUtil (ham thuan, khong can CSDL / mang). */
class LotteryCheckUtilTest {

    private static final Map<String, Long> AMOUNTS = Map.of(
            "DB", 1_000_000_000L, "G1", 30_000_000L, "G2", 15_000_000L, "G3", 10_000_000L,
            "G4", 3_000_000L, "G5", 1_000_000L, "G6", 400_000L, "G7", 200_000L);

    /** Ve do thuc te cua ky 05/10/2026 (mien Bac). */
    private static List<LotteryPrize> realDraw() {
        List<LotteryPrize> p = new ArrayList<>();
        p.add(new LotteryPrize("DB", "Đặc biệt", "19654"));
        p.add(new LotteryPrize("G1", "Giải nhất", "62219"));
        p.add(new LotteryPrize("G2", "Giải nhì", "92501-22795"));
        p.add(new LotteryPrize("G3", "Giải ba", "67752-15062-61353-69038-81889-00945"));
        p.add(new LotteryPrize("G4", "Giải tư", "0166-4647-0994-1272"));
        p.add(new LotteryPrize("G5", "Giải năm", "1025-6151-9374-9380-4735-9347"));
        p.add(new LotteryPrize("G6", "Giải sáu", "553-648-231"));
        p.add(new LotteryPrize("G7", "Giải bảy", "44-70-72-15"));
        return p;
    }

    private static LotteryPrize prize(String code, String name, String numbers) {
        return new LotteryPrize(code, name, numbers);
    }

    @Test
    void check_noMatch_shouldNotWin() {
        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("00000", realDraw(), AMOUNTS);

        assertFalse(r.isWon());
        assertTrue(r.getMatches().isEmpty());
        assertEquals(0L, r.getTotalAmount());
        assertNull(r.getPrizeAmount());
        assertEquals("Không trúng giải", r.getSummary());
        assertFalse(r.isSpecialMatched());
    }

    @Test
    void check_matchesSpecialPrize_shouldWinSpecial() {
        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("19654", realDraw(), AMOUNTS);

        assertTrue(r.isWon());
        assertTrue(r.isSpecialMatched());
        assertEquals(1, r.getMatches().size());
        assertEquals("DB", r.getMatches().get(0).getCode());
        assertEquals(1_000_000_000L, r.getTotalAmount());
        assertEquals("Trúng Đặc biệt", r.getSummary());
    }

    @Test
    void check_matchesFirstPrize_shouldWinOnlyFirstPrize() {
        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("62219", realDraw(), AMOUNTS);

        assertEquals(1, r.getMatches().size());
        assertEquals("G1", r.getMatches().get(0).getCode());
        assertEquals(30_000_000L, r.getPrizeAmount());
        assertEquals("Trúng Giải nhất", r.getSummary());
    }

    @Test
    void check_matchesTwoNumbersOfSamePrize_shouldWinThatPrize() {
        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("22795", realDraw(), AMOUNTS);

        assertEquals(1, r.getMatches().size());
        assertEquals("G2", r.getMatches().get(0).getCode());
        assertEquals(15_000_000L, r.getTotalAmount());
    }

    @Test
    void check_matchesLastTwoDigits_shouldWinSeventhPrize() {
        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("31172", realDraw(), AMOUNTS);

        assertEquals(1, r.getMatches().size());
        assertEquals("G7", r.getMatches().get(0).getCode());
        assertEquals(200_000L, r.getTotalAmount());
    }

    @Test
    void check_specialMatchedAndAlsoEndsLikeSeventhPrize_shouldCountSpecialOnly() {
        List<LotteryPrize> prizes = new ArrayList<>();
        prizes.add(prize("DB", "Đặc biệt", "12345"));
        prizes.add(prize("G7", "Giải bảy", "45"));

        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("12345", prizes, AMOUNTS);

        assertEquals(1, r.getMatches().size());
        assertEquals("DB", r.getMatches().get(0).getCode());
        assertEquals(1_000_000_000L, r.getTotalAmount());
    }

    @Test
    void check_matchesSeveralPrizes_shouldSumAmountsInPrizeOrder() {
        List<LotteryPrize> prizes = new ArrayList<>();
        prizes.add(prize("G7", "Giải bảy", "25"));
        prizes.add(prize("G5", "Giải năm", "1025"));

        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("11025", prizes, AMOUNTS);

        assertEquals(2, r.getMatches().size());
        assertEquals("G5", r.getMatches().get(0).getCode());
        assertEquals("G7", r.getMatches().get(1).getCode());
        assertEquals(1_200_000L, r.getTotalAmount());
        assertEquals("Trúng Giải năm, Giải bảy", r.getSummary());
    }

    @Test
    void check_sameNumberTwiceInSamePrize_shouldCountTwiceInSummary() {
        List<LotteryPrize> prizes = new ArrayList<>();
        prizes.add(prize("G7", "Giải bảy", "44-44"));

        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("12344", prizes, AMOUNTS);

        assertEquals(2, r.getMatches().size());
        assertEquals(400_000L, r.getTotalAmount());
        assertEquals("Trúng Giải bảy (2 lần)", r.getSummary());
    }

    @Test
    void check_prizeMissingInAmountConfig_shouldWinWithZeroAmount() {
        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("62219", realDraw(), Map.of());

        assertTrue(r.isWon());
        assertEquals(0L, r.getTotalAmount());
        assertNotNull(r.getPrizeAmount());
        assertEquals(0L, r.getPrizeAmount());
    }

    @Test
    void check_ticketNumberWithSpaces_shouldBeTrimmed() {
        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check(" 19654 ", realDraw(), AMOUNTS);

        assertEquals("19654", r.getTicketNumber());
        assertTrue(r.isSpecialMatched());
    }

    @Test
    void check_ticketDrawWithoutSomePrizes_shouldNotFail() {
        List<LotteryPrize> prizes = new ArrayList<>();
        prizes.add(prize("DB", "Đặc biệt", "12345"));

        LotteryCheckUtil.CheckResult r = LotteryCheckUtil.check("99999", prizes, AMOUNTS);

        assertFalse(r.isWon());
    }
}
