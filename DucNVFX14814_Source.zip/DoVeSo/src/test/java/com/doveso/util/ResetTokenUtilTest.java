package com.doveso.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit test ResetTokenUtil (token quen mat khau). */
class ResetTokenUtilTest {

    @Test
    void generateToken_shouldBeUrlSafeWith43Characters() {
        String token = ResetTokenUtil.generateToken();

        assertEquals(43, token.length());
        assertTrue(token.matches("[A-Za-z0-9_-]{43}"));
    }

    @Test
    void generateToken_twoCalls_shouldDiffer() {
        assertNotEquals(ResetTokenUtil.generateToken(), ResetTokenUtil.generateToken());
    }

    @Test
    void hash_shouldMatchKnownSha256Vector() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
                ResetTokenUtil.hash("abc"));
    }

    @Test
    void hash_shouldBe64LowerCaseHexAndDeterministic() {
        String h1 = ResetTokenUtil.hash("token-1");

        assertTrue(h1.matches("[0-9a-f]{64}"));
        assertEquals(h1, ResetTokenUtil.hash("token-1"));
        assertNotEquals(h1, ResetTokenUtil.hash("token-2"));
    }

    @Test
    void expireMinutes_shouldBeThirty() {
        assertEquals(30, ResetTokenUtil.EXPIRE_MINUTES);
    }
}
