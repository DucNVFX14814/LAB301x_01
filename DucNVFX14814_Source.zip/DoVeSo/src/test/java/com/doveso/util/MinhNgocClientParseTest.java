package com.doveso.util;

import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryPrize;
import com.doveso.util.MinhNgocClient.RegionResult;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit test phan tich HTML cua MinhNgocClient tren file mau (cat tu trang ket qua mien Bac that, 2 ngay
 * 05/10/2026 va 04/10/2026) - khong can mang, khong can CSDL.
 * Neu trang nguon doi cau truc HTML, test tren file mau that (chup lai trang moi) se bao loi som.
 */
class MinhNgocClientParseTest {

    private static final LocalDate D1005 = LocalDate.of(2026, 10, 5);
    private static final LocalDate D1004 = LocalDate.of(2026, 10, 4);

    private String html;
    private List<LotteryCompany> companies;

    @BeforeEach
    void setUp() throws IOException {
        try (InputStream in = MinhNgocClientParseTest.class.getResourceAsStream("/minhngoc-mien-bac.html")) {
            assertNotNull(in, "Thieu file mau minhngoc-mien-bac.html");
            html = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
        companies = List.of(new LotteryCompany("mien-bac", "Miền Bắc", "BAC"));
    }

    private static String numbersOf(List<LotteryPrize> prizes, String code) {
        for (LotteryPrize p : prizes) {
            if (code.equals(p.getPrizeCode())) {
                return p.getPrizeNumber();
            }
        }
        return null;
    }

    @Test
    void parseRegionPage_realBacPage_shouldReadBothDays() {
        Map<LocalDate, RegionResult> days = MinhNgocClient.parseRegionPage(html, "BAC", companies);

        assertEquals(2, days.size());
        assertTrue(days.containsKey(D1005));
        assertTrue(days.containsKey(D1004));
    }

    @Test
    void parseRegionPage_realBacPage_shouldReadAllEightPrizesInOrder() {
        RegionResult day = MinhNgocClient.parseRegionPage(html, "BAC", companies).get(D1005);

        assertTrue(day.getErrors().isEmpty());
        List<LotteryPrize> prizes = day.getPrizes().get("mien-bac");
        assertEquals(8, prizes.size());
        List<String> codes = new ArrayList<>();
        for (LotteryPrize p : prizes) {
            codes.add(p.getPrizeCode());
        }
        assertEquals(List.of("DB", "G1", "G2", "G3", "G4", "G5", "G6", "G7"), codes);
    }

    @Test
    void parseRegionPage_realBacPage_shouldReadPrizeNumbersOfLatestDay() {
        List<LotteryPrize> prizes = MinhNgocClient.parseRegionPage(html, "BAC", companies)
                .get(D1005).getPrizes().get("mien-bac");

        assertEquals("19654", numbersOf(prizes, "DB"));
        assertEquals("62219", numbersOf(prizes, "G1"));
        assertEquals("92501-22795", numbersOf(prizes, "G2"));
        assertEquals("67752-15062-61353-69038-81889-00945", numbersOf(prizes, "G3"));
        assertEquals("0166-4647-0994-1272", numbersOf(prizes, "G4"));
        assertEquals("1025-6151-9374-9380-4735-9347", numbersOf(prizes, "G5"));
        assertEquals("553-648-231", numbersOf(prizes, "G6"));
        assertEquals("44-70-72-15", numbersOf(prizes, "G7"));
    }

    @Test
    void parseRegionPage_realBacPage_shouldReadPreviousDayIndependently() {
        List<LotteryPrize> prizes = MinhNgocClient.parseRegionPage(html, "BAC", companies)
                .get(D1004).getPrizes().get("mien-bac");

        assertEquals("82951", numbersOf(prizes, "DB"));
        assertEquals("90-89-26-59", numbersOf(prizes, "G7"));
    }

    @Test
    void parseRegionPage_tableRenamed_shouldReportStructureErrorForThatDayOnly() {
        String changed = html.replaceFirst(Pattern.quote("class=\"bkqtinhmienbac\""), "class=\"khac\"");

        Map<LocalDate, RegionResult> days = MinhNgocClient.parseRegionPage(changed, "BAC", companies);

        RegionResult broken = days.get(D1005);
        assertTrue(broken.getPrizes().isEmpty());
        assertTrue(broken.getErrors().get("mien-bac").contains("Không đọc được bảng kết quả"));
        assertTrue(days.get(D1004).getErrors().isEmpty());
        assertFalse(days.get(D1004).getPrizes().isEmpty());
    }

    @Test
    void parseRegionPage_missingThirdPrizeNumber_shouldReportIncompleteResult() {
        String changed = html.replace("<div>67752</div>", "");

        RegionResult day = MinhNgocClient.parseRegionPage(changed, "BAC", companies).get(D1005);

        assertTrue(day.getPrizes().isEmpty());
        String error = day.getErrors().get("mien-bac");
        assertTrue(error.contains("chưa đầy đủ"));
        assertTrue(error.contains("giải ba"));
    }

    @Test
    void parseRegionPage_nonNumericPrizeNumber_shouldReportInvalidNumber() {
        String changed = html.replace("<div>19654</div>", "<div>19A54</div>");

        RegionResult day = MinhNgocClient.parseRegionPage(changed, "BAC", companies).get(D1005);

        assertTrue(day.getPrizes().isEmpty());
        assertTrue(day.getErrors().get("mien-bac").contains("không hợp lệ"));
    }

    @Test
    void parseRegionPage_pageWithoutResultBoxes_shouldReturnEmptyMap() {
        assertTrue(MinhNgocClient.parseRegionPage("<html><body><p>Bao tri</p></body></html>", "BAC", companies)
                .isEmpty());
    }

    @Test
    void parseProvincePage_bacPageHasNoProvinceTable_shouldReturnEmptyMap() {
        LotteryCompany danang = new LotteryCompany("da-nang", "Đà Nẵng", "TRUNG");

        assertTrue(MinhNgocClient.parseProvincePage(html, danang).isEmpty());
    }

    @Test
    void regionLabel_shouldReturnVietnameseNames() {
        assertEquals("miền Bắc", MinhNgocClient.regionLabel("BAC"));
        assertEquals("miền Trung", MinhNgocClient.regionLabel("TRUNG"));
        assertEquals("miền Nam", MinhNgocClient.regionLabel("NAM"));
    }
}
