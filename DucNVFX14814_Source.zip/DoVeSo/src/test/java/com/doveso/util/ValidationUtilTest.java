package com.doveso.util;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit test ValidationUtil: ham thuan, khong can CSDL / mang. */
class ValidationUtilTest {

    @Test
    void isValidFullName_vietnameseNameWithDiacritics_shouldBeValid() {
        assertTrue(ValidationUtil.isValidFullName("Nguyễn Việt Đức"));
        assertTrue(ValidationUtil.isValidFullName("  An  "));
    }

    @Test
    void isValidFullName_tooShortDigitsOrNull_shouldBeInvalid() {
        assertFalse(ValidationUtil.isValidFullName("A"));
        assertFalse(ValidationUtil.isValidFullName("Nguyen123"));
        assertFalse(ValidationUtil.isValidFullName(null));
    }

    @Test
    void isValidFullName_longerThan150Characters_shouldBeInvalid() {
        assertTrue(ValidationUtil.isValidFullName("a".repeat(150)));
        assertFalse(ValidationUtil.isValidFullName("a".repeat(151)));
    }

    @Test
    void isValidEmail_wellFormedAddress_shouldBeValid() {
        assertTrue(ValidationUtil.isValidEmail("a.b+c@mail.com"));
        assertTrue(ValidationUtil.isValidEmail(" user@gmail.com "));
    }

    @Test
    void isValidEmail_multiLevelDomain_shouldBeValid() {
        assertTrue(ValidationUtil.isValidEmail("abc@funix.edu.vn"));
        assertTrue(ValidationUtil.isValidEmail("ducnvfx14814@funix.edu.vn"));
        assertTrue(ValidationUtil.isValidEmail("x@mail.co.uk"));
        assertTrue(ValidationUtil.isValidEmail("a_b-c@sub.domain-name.example.org"));
        assertTrue(ValidationUtil.isValidEmail(" abc@funix.edu.vn "));
    }

    @Test
    void isValidEmail_malformedOrNull_shouldBeInvalid() {
        assertFalse(ValidationUtil.isValidEmail("abc@"));
        assertFalse(ValidationUtil.isValidEmail("abc@mail"));
        assertFalse(ValidationUtil.isValidEmail("abc.mail.com"));
        assertFalse(ValidationUtil.isValidEmail("@mail.com"));
        assertFalse(ValidationUtil.isValidEmail(null));
    }

    @Test
    void isValidEmail_badDomainLabels_shouldBeInvalid() {
        assertFalse(ValidationUtil.isValidEmail("a@b..com"));      // 2 dau cham lien tiep
        assertFalse(ValidationUtil.isValidEmail("a@.mail.com"));   // bat dau bang dau cham
        assertFalse(ValidationUtil.isValidEmail("a@mail.com."));   // ket thuc bang dau cham
        assertFalse(ValidationUtil.isValidEmail("a@-mail.com"));   // nhan bat dau bang gach noi
        assertFalse(ValidationUtil.isValidEmail("a@mail-.com"));   // nhan ket thuc bang gach noi
        assertFalse(ValidationUtil.isValidEmail("a@mail.c"));      // duoi qua ngan
        assertFalse(ValidationUtil.isValidEmail("a@mail.123"));    // duoi khong phai chu
        assertFalse(ValidationUtil.isValidEmail("a b@mail.com"));  // co khoang trang
    }

    @Test
    void isValidPhone_startsWithZeroAndTenDigits_shouldBeValid() {
        assertTrue(ValidationUtil.isValidPhone("0912345678"));
    }

    @Test
    void isValidPhone_wrongLengthPrefixOrLetters_shouldBeInvalid() {
        assertFalse(ValidationUtil.isValidPhone("912345678"));
        assertFalse(ValidationUtil.isValidPhone("09123456789"));
        assertFalse(ValidationUtil.isValidPhone("091234567a"));
        assertFalse(ValidationUtil.isValidPhone(null));
    }

    @Test
    void isValidPassword_boundaryAtSixCharacters() {
        assertFalse(ValidationUtil.isValidPassword("12345"));
        assertTrue(ValidationUtil.isValidPassword("123456"));
        assertFalse(ValidationUtil.isValidPassword(null));
    }

    @Test
    void isValidTicketNumber_fiveDigitsExpected() {
        assertTrue(ValidationUtil.isValidTicketNumber("12345", 5));
        assertTrue(ValidationUtil.isValidTicketNumber(" 12345 ", 5));
        assertFalse(ValidationUtil.isValidTicketNumber("1234", 5));
        assertFalse(ValidationUtil.isValidTicketNumber("123456", 5));
        assertFalse(ValidationUtil.isValidTicketNumber("12a45", 5));
        assertFalse(ValidationUtil.isValidTicketNumber(null, 5));
    }

    @Test
    void isValidTicketNumber_sixDigitsExpected_andOtherLengthsTreatedAsSix() {
        assertTrue(ValidationUtil.isValidTicketNumber("123456", 6));
        assertFalse(ValidationUtil.isValidTicketNumber("12345", 6));
        assertTrue(ValidationUtil.isValidTicketNumber("123456", 7));
    }

    @Test
    void isBlank_andTrimToEmpty() {
        assertTrue(ValidationUtil.isBlank(null));
        assertTrue(ValidationUtil.isBlank("   "));
        assertFalse(ValidationUtil.isBlank(" a "));
        assertEquals("", ValidationUtil.trimToEmpty(null));
        assertEquals("abc", ValidationUtil.trimToEmpty("  abc "));
    }

    @Test
    void parseIsoDate_validAndInvalidInput() {
        assertEquals(LocalDate.of(2026, 10, 5), ValidationUtil.parseIsoDate("2026-10-05"));
        assertNull(ValidationUtil.parseIsoDate("05/10/2026"));
        assertNull(ValidationUtil.parseIsoDate("2026-02-30"));
        assertNull(ValidationUtil.parseIsoDate(""));
        assertNull(ValidationUtil.parseIsoDate(null));
    }
}
