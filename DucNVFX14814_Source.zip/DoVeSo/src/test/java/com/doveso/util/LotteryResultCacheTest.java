package com.doveso.util;

import com.doveso.util.MinhNgocClient.RegionResult;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

/** Unit test LotteryResultCache: bo nho dem trang nguon trong 1 request (khong can mang). */
class LotteryResultCacheTest {

    private static final String KEY = "REGION:BAC";
    private static final LocalDate D5 = LocalDate.of(2026, 10, 5);

    private final LotteryResultCache cache = new LotteryResultCache();
    private final AtomicInteger fetchCount = new AtomicInteger();

    /** Trang nguon tra ve days ngay lien tiep tinh tu ngay duoc yeu cau lui ve truoc. */
    private LotteryResultCache.Fetcher pageOf(int days, Map<LocalDate, RegionResult> store) {
        return date -> {
            fetchCount.incrementAndGet();
            Map<LocalDate, RegionResult> page = new HashMap<>();
            for (int i = 0; i < days; i++) {
                LocalDate d = date.minusDays(i);
                page.put(d, store.computeIfAbsent(d, x -> new RegionResult()));
            }
            return page;
        };
    }

    @Test
    void get_shouldFetchOnceAndReuseCoveredDates() throws Exception {
        Map<LocalDate, RegionResult> store = new HashMap<>();
        LotteryResultCache.Fetcher fetcher = pageOf(3, store);

        RegionResult r5 = cache.get(KEY, D5, fetcher);
        RegionResult r4 = cache.get(KEY, D5.minusDays(1), fetcher);
        RegionResult r3 = cache.get(KEY, D5.minusDays(2), fetcher);

        assertSame(store.get(D5), r5);
        assertSame(store.get(D5.minusDays(1)), r4);
        assertNotNull(r3);
        assertEquals(1, fetchCount.get());
    }

    @Test
    void get_dateCoveredByPageButMissingInIt_shouldReturnNullWithoutRefetch() throws Exception {
        Map<LocalDate, RegionResult> page = new HashMap<>();
        page.put(D5, new RegionResult());
        page.put(D5.minusDays(2), new RegionResult()); // thieu ngay D5 - 1: nguon khong co ket qua ngay do
        LotteryResultCache.Fetcher fetcher = d -> {
            fetchCount.incrementAndGet();
            return page;
        };

        assertNotNull(cache.get(KEY, D5, fetcher));
        assertNull(cache.get(KEY, D5.minusDays(1), fetcher));
        assertEquals(1, fetchCount.get());
    }

    @Test
    void get_differentKeys_shouldNotShareResults() throws Exception {
        Map<LocalDate, RegionResult> store = new HashMap<>();
        LotteryResultCache.Fetcher fetcher = pageOf(1, store);

        cache.get("REGION:BAC", D5, fetcher);
        cache.get("REGION:NAM", D5, fetcher);

        assertEquals(2, fetchCount.get());
    }

    @Test
    void get_fetchFails_shouldThrowAndRememberTheFailure() {
        LotteryResultCache.Fetcher failing = d -> {
            fetchCount.incrementAndGet();
            throw new LotteryFetchException("Không kết nối được nguồn dữ liệu.");
        };

        LotteryFetchException first = assertThrows(LotteryFetchException.class, () -> cache.get(KEY, D5, failing));
        LotteryFetchException second = assertThrows(LotteryFetchException.class, () -> cache.get(KEY, D5, failing));

        assertEquals("Không kết nối được nguồn dữ liệu.", first.getMessage());
        assertEquals(first.getMessage(), second.getMessage());
        assertEquals(1, fetchCount.get()); // lan 2 khong goi lai nguon
    }

    @Test
    void prefetch_pageCoveringWholeRange_shouldFetchOnce() throws Exception {
        Map<LocalDate, RegionResult> store = new HashMap<>();
        LotteryResultCache.Fetcher fetcher = pageOf(7, store);

        cache.prefetch(KEY, D5.minusDays(6), D5, fetcher);
        for (int i = 0; i < 7; i++) {
            assertNotNull(cache.get(KEY, D5.minusDays(i), fetcher));
        }

        assertEquals(1, fetchCount.get());
    }

    @Test
    void prefetch_pageCoveringOnlyRequestedDay_shouldFetchOncePerDay() throws Exception {
        Map<LocalDate, RegionResult> store = new HashMap<>();
        LotteryResultCache.Fetcher fetcher = pageOf(1, store);

        cache.prefetch(KEY, D5.minusDays(2), D5, fetcher);

        assertEquals(3, fetchCount.get());
        cache.get(KEY, D5.minusDays(1), fetcher);
        assertEquals(3, fetchCount.get());
    }

    @Test
    void prefetch_fetchFails_shouldNotThrowButGetReportsTheFailureWithoutRefetch() {
        LotteryResultCache.Fetcher failing = d -> {
            fetchCount.incrementAndGet();
            throw new LotteryFetchException("Nguồn lỗi");
        };

        cache.prefetch(KEY, D5.minusDays(2), D5, failing); // khong nem exception ra ngoai

        LotteryFetchException e = assertThrows(LotteryFetchException.class,
                () -> cache.get(KEY, D5.minusDays(1), failing));
        assertEquals("Nguồn lỗi", e.getMessage());
        assertEquals(1, fetchCount.get());
    }
}
