package com.doveso.util;

import com.doveso.model.NumberStat;
import com.doveso.model.PrizeDrawRow;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit test NumberSuggestionUtil.analyze() (thong ke de xuat so, ham thuan). */
class NumberSuggestionUtilTest {

    private static final LocalDate D2 = LocalDate.of(2026, 10, 5);
    private static final LocalDate D1 = LocalDate.of(2026, 10, 4);

    private static NumberStat find(List<NumberStat> list, String number) {
        for (NumberStat s : list) {
            if (s.getNumber().equals(number)) {
                return s;
            }
        }
        return null;
    }

    @Test
    void analyze_emptyRows_shouldReportNoData() {
        NumberSuggestionUtil.Result r = NumberSuggestionUtil.analyze(new ArrayList<>(), 10);

        assertTrue(r.isNoData());
        assertEquals(0, r.getTotalDraws());
        assertTrue(r.getHotNumbers().isEmpty());
        assertTrue(r.getColdNumbers().isEmpty());
        assertNull(r.getLatestDrawDateFormatted());
    }

    @Test
    void analyze_twoDraws_shouldRankHotByFrequencyThenRecencyThenNumber() {
        List<PrizeDrawRow> rows = List.of(
                new PrizeDrawRow(D2, "19654-62219"),
                new PrizeDrawRow(D1, "82951-28235"));

        NumberSuggestionUtil.Result r = NumberSuggestionUtil.analyze(rows, 3);

        assertFalse(r.isNoData());
        assertEquals(2, r.getTotalDraws());
        assertEquals("05/10/2026", r.getLatestDrawDateFormatted());
        // cung tan suat 1: so ve ky moi nhat (gap 0) truoc, roi theo thu tu so
        assertEquals("19", r.getHotNumbers().get(0).getNumber());
        assertEquals("54", r.getHotNumbers().get(1).getNumber());
        assertEquals("35", r.getHotNumbers().get(2).getNumber());
        assertEquals(3, r.getHotNumbers().size());
    }

    @Test
    void analyze_neverSeenNumbers_shouldBeColdestWithGapEqualTotalDraws() {
        List<PrizeDrawRow> rows = List.of(
                new PrizeDrawRow(D2, "19654-62219"),
                new PrizeDrawRow(D1, "82951-28235"));

        NumberSuggestionUtil.Result r = NumberSuggestionUtil.analyze(rows, 3);

        assertEquals("00", r.getColdNumbers().get(0).getNumber());
        assertEquals("01", r.getColdNumbers().get(1).getNumber());
        assertEquals("02", r.getColdNumbers().get(2).getNumber());
        assertTrue(r.getColdNumbers().get(0).isNeverSeen());
        assertEquals(2, r.getColdNumbers().get(0).getGapDraws());
    }

    @Test
    void analyze_numberSeenInSeveralDraws_shouldHaveHigherFrequencyAndLastSeenDate() {
        List<PrizeDrawRow> rows = List.of(
                new PrizeDrawRow(D2, "10054"),
                new PrizeDrawRow(D1, "20054-30031"));

        NumberSuggestionUtil.Result r = NumberSuggestionUtil.analyze(rows, 5);

        NumberStat n54 = find(r.getHotNumbers(), "54");
        assertEquals(2, n54.getFrequency());
        assertEquals("05/10/2026", n54.getLastSeenDrawDateFormatted());
        assertEquals(0, n54.getGapDraws());
        assertEquals("54", r.getHotNumbers().get(0).getNumber());
        NumberStat n31 = find(r.getHotNumbers(), "31");
        assertEquals(1, n31.getFrequency());
        assertEquals(1, n31.getGapDraws());
        assertEquals("04/10/2026", n31.getLastSeenDrawDateFormatted());
    }

    @Test
    void analyze_tokensShorterThanTwoCharactersOrBlank_shouldBeIgnored() {
        List<PrizeDrawRow> rows = List.of(
                new PrizeDrawRow(D2, "5-12-"),
                new PrizeDrawRow(D1, ""));

        NumberSuggestionUtil.Result r = NumberSuggestionUtil.analyze(rows, 10);

        assertEquals(1, r.getHotNumbers().size());
        assertEquals("12", r.getHotNumbers().get(0).getNumber());
        assertEquals(2, r.getTotalDraws());
    }

    @Test
    void analyze_moreThanFiftyDraws_shouldUseOnlyFiftyMostRecent() {
        List<PrizeDrawRow> rows = new ArrayList<>();
        for (int i = 0; i < 60; i++) {
            LocalDate date = D2.minusDays(i);
            rows.add(new PrizeDrawRow(date, i < 50 ? "11100" : "11177"));
        }

        NumberSuggestionUtil.Result r = NumberSuggestionUtil.analyze(rows, 10);

        assertEquals(50, r.getTotalDraws());
        assertEquals("00", r.getHotNumbers().get(0).getNumber());
        assertEquals(50, r.getHotNumbers().get(0).getFrequency());
        assertEquals(1, r.getHotNumbers().size()); // "77" chi co o cac ky cu hon 50 ky gan nhat
        assertNull(find(r.getHotNumbers(), "77"));
    }

    @Test
    void analyze_topNLargerThanAvailable_shouldReturnAllHotNumbers() {
        List<PrizeDrawRow> rows = List.of(new PrizeDrawRow(D2, "19654"));

        NumberSuggestionUtil.Result r = NumberSuggestionUtil.analyze(rows, 50);

        assertEquals(1, r.getHotNumbers().size());
        assertEquals(50, r.getColdNumbers().size());
    }
}
