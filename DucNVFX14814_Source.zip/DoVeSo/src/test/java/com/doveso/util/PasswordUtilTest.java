package com.doveso.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Unit test PasswordUtil (BCrypt). Chi hash it lan vi BCrypt cost 12 cham co chu dich. */
class PasswordUtilTest {

    @Test
    void hash_shouldNotStoreThePlainPasswordAndShouldVerify() {
        String hash = PasswordUtil.hash("matkhau123");

        assertNotEquals("matkhau123", hash);
        assertTrue(hash.startsWith("$2"));
        assertTrue(PasswordUtil.verify("matkhau123", hash));
    }

    @Test
    void verify_wrongPassword_shouldReturnFalse() {
        String hash = PasswordUtil.hash("matkhau123");

        assertFalse(PasswordUtil.verify("matkhau124", hash));
    }

    @Test
    void hash_samePasswordTwice_shouldGiveDifferentHashesBecauseOfSalt() {
        assertNotEquals(PasswordUtil.hash("abcdef"), PasswordUtil.hash("abcdef"));
    }

    @Test
    void verify_nullArguments_shouldReturnFalse() {
        assertFalse(PasswordUtil.verify(null, "$2a$12$abcdefghijklmnopqrstuuabcdefghijklmnopqrstuvwxyz01234"));
        assertFalse(PasswordUtil.verify("abc", null));
    }
}
