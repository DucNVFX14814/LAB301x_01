package com.doveso.dao.impl;

import com.doveso.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Tien ich dung chung cho cac test DAO (integration test tren CSDL MySQL that: doveso_db).
 * Dung de:
 *  - thuc thi truc tiep cau lenh UPDATE/DELETE/INSERT khi chuan bi hoac don dep du lieu test
 *    (khong di qua tang DAO dang duoc test, tranh phu thuoc vong).
 *  - sinh chuoi so ngau nhien, khong trung nhau trong 1 lan chay, dung lam email/so dien thoai/
 *    ma cong ty test de khong dung do voi du lieu that hoac du lieu cua test khac.
 */
final class TestSupport {

    private static final AtomicLong COUNTER = new AtomicLong();

    private TestSupport() {
    }

    static void update(String sql, Object... params) {
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Loi chuan bi/don dep du lieu test: " + e.getMessage(), e);
        }
    }

    /** Chuoi so co do dai co dinh, khong trung nhau giua cac lan goi trong cung 1 lan chay test. */
    static String uniqueDigits(int length) {
        long v = Math.abs(System.nanoTime() ^ (COUNTER.incrementAndGet() * 7919L));
        String s = Long.toString(v);
        if (s.length() < length) {
            s = "0".repeat(length - s.length()) + s;
        }
        return s.substring(s.length() - length);
    }
}
