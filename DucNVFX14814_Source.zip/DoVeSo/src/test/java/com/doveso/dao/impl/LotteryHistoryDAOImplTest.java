package com.doveso.dao.impl;

import com.doveso.model.LotteryHistory;
import com.doveso.model.LotteryTicket;
import com.doveso.model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cho LotteryHistoryDAOImpl (bang lottery_history) - CN3: Thuc hien do ve so (USER da dang nhap).
 * Tu tao 1 user USER va 1 ve do PUBLISH cua 'mien-bac' lam du lieu nen, roi luu 1 lan do vao lich su
 * de kiem tra danh sach/dem lich su co loc theo cong ty va khoang thoi gian.
 */
class LotteryHistoryDAOImplTest {

    private final LotteryHistoryDAOImpl dao = new LotteryHistoryDAOImpl();
    private final TicketDAOImpl ticketDao = new TicketDAOImpl();
    private final UserDAOImpl userDao = new UserDAOImpl();

    private Long userId;
    private Long ticketId;
    private Long historyId;
    private LocalDate drawDate;

    @BeforeEach
    void setUp() {
        String suffix = TestSupport.uniqueDigits(9);
        User user = new User("User Test", "us_" + suffix + "@test.local", "0" + suffix, "hash");
        userId = userDao.insert(user);

        drawDate = LocalDate.now().plusYears(5).plusDays(Long.parseLong(suffix) % 3000);
        LotteryTicket t = new LotteryTicket();
        t.setCompanyCode("mien-bac");
        t.setDrawDate(drawDate);
        t.setCreatedBy(userId); // tang DAO khong ep buoc phai la ADMIN, chi can ton tai trong bang users
        ticketId = ticketDao.insertWithPrizes(t, List.of(), true);

        historyId = null;
    }

    @AfterEach
    void tearDown() {
        if (historyId != null) {
            TestSupport.update("DELETE FROM lottery_history WHERE id = ?", historyId);
        }
        TestSupport.update("DELETE FROM lottery_tickets WHERE id = ?", ticketId);
        TestSupport.update("DELETE FROM users WHERE id = ?", userId);
    }

    private LotteryHistory newHistory(Long prizeAmount) {
        LotteryHistory h = new LotteryHistory();
        h.setUserId(userId);
        h.setTicketId(ticketId);
        h.setTicketNumber("12345678");
        h.setResultSummary(prizeAmount == null ? "Không trúng giải" : "Trúng Giải Ba");
        h.setPrizeAmount(prizeAmount);
        return h;
    }

    @Test
    void insert_thenFindByUserId_shouldReturnHistoryJoinedWithTicketInfo() {
        historyId = dao.insert(newHistory(1_000_000L));

        List<LotteryHistory> results = dao.findByUserId(userId, null, null, null, null, 1, 20);

        assertEquals(1, results.size());
        LotteryHistory h = results.get(0);
        assertEquals(historyId, h.getId());
        assertEquals(drawDate, h.getDrawDate());
        assertEquals("mien-bac", h.getCompanyCode());
        assertEquals(Long.valueOf(1_000_000L), h.getPrizeAmount());
    }

    @Test
    void insert_withoutPrizeAmount_shouldStoreNull() {
        historyId = dao.insert(newHistory(null));

        LotteryHistory h = dao.findByUserId(userId, null, null, null, null, 1, 20).get(0);

        assertNull(h.getPrizeAmount());
    }

    @Test
    void countByUserId_shouldMatchNumberOfHistoryRecords() {
        historyId = dao.insert(newHistory(500_000L));

        assertEquals(1, dao.countByUserId(userId, null, null, null, null));
    }

    @Test
    void findByUserId_filterByMatchingCompanyCode_shouldReturnHistory() {
        historyId = dao.insert(newHistory(null));

        List<LotteryHistory> results = dao.findByUserId(userId, null, "mien-bac", null, null, 1, 20);

        assertEquals(1, results.size());
    }

    @Test
    void findByUserId_filterByOtherCompanyCode_shouldReturnEmpty() {
        historyId = dao.insert(newHistory(null));

        List<LotteryHistory> results = dao.findByUserId(userId, null, "da-nang", null, null, 1, 20);

        assertTrue(results.isEmpty());
    }

    @Test
    void findByUserId_filterByPastDateRange_shouldReturnEmpty() {
        historyId = dao.insert(newHistory(null));

        // checked_at la thoi diem hien tai luc insert -> loc mot khoang hoan toan trong qua khu se khong khop
        List<LotteryHistory> results = dao.findByUserId(userId, null, null,
                LocalDate.now().minusDays(10), LocalDate.now().minusDays(5), 1, 20);

        assertTrue(results.isEmpty());
    }
}
