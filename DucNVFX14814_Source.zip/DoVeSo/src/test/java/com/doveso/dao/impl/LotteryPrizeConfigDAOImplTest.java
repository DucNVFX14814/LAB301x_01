package com.doveso.dao.impl;

import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cho LotteryPrizeConfigDAOImpl (bang lottery_prize_configs).
 * Dua tren co cau giai mien Bac (region_code = 'BAC') da co san trong database/schema.sql:
 * DB=500,000,000 ... G7=40,000 (8 giai). Chi DOC, khong tao/xoa du lieu.
 */
class LotteryPrizeConfigDAOImplTest {

    private final LotteryPrizeConfigDAOImpl dao = new LotteryPrizeConfigDAOImpl();

    @Test
    void findAmountsByRegion_BAC_shouldReturnCorrectAmountsForDacBietAndGiaiNhat() {
        Map<String, Long> amounts = dao.findAmountsByRegion("BAC");

        assertEquals(Long.valueOf(500_000_000L), amounts.get("DB"));
        assertEquals(Long.valueOf(10_000_000L), amounts.get("G1"));
    }

    @Test
    void findAmountsByRegion_BAC_shouldContainExactlyEightPrizeLevels() {
        // Mien Bac: DB, G1..G7 (khong co G8 nhu mien Trung/Nam)
        Map<String, Long> amounts = dao.findAmountsByRegion("BAC");

        assertEquals(8, amounts.size());
    }

    @Test
    void findAmountsByRegion_nonExistingRegion_shouldReturnEmptyMap() {
        assertTrue(dao.findAmountsByRegion("KHONG_TON_TAI").isEmpty());
    }
}
