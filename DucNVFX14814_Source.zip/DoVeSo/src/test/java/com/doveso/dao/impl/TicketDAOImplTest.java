package com.doveso.dao.impl;

import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryTicket;
import com.doveso.model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cho TicketDAOImpl (bang lottery_tickets, lottery_ticket_items) - CN2: Quan ly ve do.
 * Dung cong ty co san 'mien-bac' (schema.sql) lam khoa ngoai; tu tao 1 user ADMIN rieng lam
 * created_by va 1 ngay quay so ngau nhien o rat xa tuong lai de khong trung du lieu ve do that
 * (rang buoc UNIQUE(company_code, draw_date)). Don dep toan bo du lieu tao ra sau moi test.
 */
class TicketDAOImplTest {

    private static final String COMPANY_CODE = "mien-bac";

    private final TicketDAOImpl dao = new TicketDAOImpl();
    private final UserDAOImpl userDao = new UserDAOImpl();

    private Long adminUserId;
    private Long ticketId;
    private LocalDate drawDate;

    @BeforeEach
    void setUp() {
        String suffix = TestSupport.uniqueDigits(9);
        User admin = new User("Admin Test", "tk_" + suffix + "@test.local", "0" + suffix, "hash");
        admin.setRole("ADMIN");
        adminUserId = userDao.insert(admin);

        drawDate = LocalDate.now().plusYears(5).plusDays(Long.parseLong(suffix) % 3000);
        ticketId = null;
    }

    @AfterEach
    void tearDown() {
        if (ticketId != null) {
            TestSupport.update("DELETE FROM lottery_ticket_items WHERE ticket_id = ?", ticketId);
            TestSupport.update("DELETE FROM lottery_tickets WHERE id = ?", ticketId);
        }
        TestSupport.update("DELETE FROM users WHERE id = ?", adminUserId);
    }

    private List<LotteryPrize> samplePrizes() {
        return List.of(
                new LotteryPrize("DB", "Đặc biệt", "123456"),
                new LotteryPrize("G1", "Giải nhất", "654321")
        );
    }

    private LotteryTicket newTicket() {
        LotteryTicket t = new LotteryTicket();
        t.setCompanyCode(COMPANY_CODE);
        t.setDrawDate(drawDate);
        t.setCreatedBy(adminUserId);
        return t;
    }

    @Test
    void insertWithPrizes_unpublished_thenFindById_shouldReturnTicketWithUnpublishStatus() {
        ticketId = dao.insertWithPrizes(newTicket(), samplePrizes(), false);

        LotteryTicket found = dao.findById(ticketId);

        assertNotNull(found);
        assertEquals(COMPANY_CODE, found.getCompanyCode());
        assertEquals(drawDate, found.getDrawDate());
        assertEquals(LotteryTicket.STATUS_UNPUBLISH, found.getStatus());
    }

    @Test
    void insertWithPrizes_publishTrue_shouldSetStatusPublishImmediately() {
        ticketId = dao.insertWithPrizes(newTicket(), samplePrizes(), true);

        assertEquals(LotteryTicket.STATUS_PUBLISH, dao.findById(ticketId).getStatus());
    }

    @Test
    void findByCompanyAndDate_shouldReturnTicketRegardlessOfStatus() {
        ticketId = dao.insertWithPrizes(newTicket(), samplePrizes(), false);

        LotteryTicket found = dao.findByCompanyAndDate(COMPANY_CODE, drawDate);

        assertNotNull(found);
        assertEquals(ticketId, found.getId());
    }

    @Test
    void findPublishedByCompanyAndDate_whenStillUnpublish_shouldReturnNull() {
        ticketId = dao.insertWithPrizes(newTicket(), samplePrizes(), false);

        assertNull(dao.findPublishedByCompanyAndDate(COMPANY_CODE, drawDate));
    }

    @Test
    void publish_shouldChangeStatusFromUnpublishToPublish() {
        ticketId = dao.insertWithPrizes(newTicket(), samplePrizes(), false);

        dao.publish(ticketId);

        assertEquals(LotteryTicket.STATUS_PUBLISH, dao.findById(ticketId).getStatus());
        assertNotNull(dao.findPublishedByCompanyAndDate(COMPANY_CODE, drawDate));
    }

    @Test
    void listPublishedDrawDates_shouldIncludeOurPublishedDrawDate() {
        ticketId = dao.insertWithPrizes(newTicket(), samplePrizes(), true);

        List<LocalDate> dates = dao.listPublishedDrawDates(1000);

        assertTrue(dates.contains(drawDate));
    }

    @Test
    void search_and_count_byCompanyAndDateRange_shouldFindExactlyOurTicket() {
        ticketId = dao.insertWithPrizes(newTicket(), samplePrizes(), false);

        List<LotteryTicket> results = dao.search(null, COMPANY_CODE, drawDate, drawDate, null, 1, 20);
        long total = dao.count(null, COMPANY_CODE, drawDate, drawDate, null);

        assertEquals(1, results.size());
        assertEquals(ticketId, results.get(0).getId());
        assertEquals(1, total);
    }

    @Test
    void countDrawTimes_withoutAnyHistory_shouldReturnZero() {
        ticketId = dao.insertWithPrizes(newTicket(), samplePrizes(), false);

        assertEquals(0, dao.countDrawTimes(ticketId));
    }
}
