package com.doveso.dao.impl;

import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryRegion;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cho CompanyDAOImpl (bang lottery_regions, lottery_companies).
 * Day la du lieu tham chieu tinh (seed) da co san trong database/schema.sql
 * (BAC/TRUNG/NAM, cong ty 'mien-bac'...) nen cac test chi DOC, khong tao/xoa gi.
 */
class CompanyDAOImplTest {

    private final CompanyDAOImpl dao = new CompanyDAOImpl();

    @Test
    void findAllRegions_shouldReturnBacTrungNamInThatOrder() {
        List<LotteryRegion> regions = dao.findAllRegions();

        assertTrue(regions.size() >= 3);
        assertEquals("BAC", regions.get(0).getRegionCode());
        assertEquals("TRUNG", regions.get(1).getRegionCode());
        assertEquals("NAM", regions.get(2).getRegionCode());
    }

    @Test
    void findActiveCompanies_shouldContainMienBac() {
        List<LotteryCompany> companies = dao.findActiveCompanies();

        assertTrue(companies.stream().anyMatch(c -> "mien-bac".equals(c.getCompanyCode())));
    }

    @Test
    void findByCode_existingCode_shouldReturnCompanyJoinedWithRegionName() {
        LotteryCompany company = dao.findByCode("mien-bac");

        assertNotNull(company);
        assertEquals("BAC", company.getRegionCode());
        assertEquals("Miền Bắc", company.getRegionName());
    }

    @Test
    void findByCode_nonExistingCode_shouldReturnNull() {
        assertNull(dao.findByCode("khong-ton-tai-xyz"));
    }
}
