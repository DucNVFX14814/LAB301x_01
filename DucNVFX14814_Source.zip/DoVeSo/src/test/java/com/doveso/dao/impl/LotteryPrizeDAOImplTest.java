package com.doveso.dao.impl;

import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryTicket;
import com.doveso.model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cho LotteryPrizeDAOImpl (bang lottery_ticket_items).
 * Can 1 ve do (lottery_tickets) lam khoa ngoai: tu tao 1 user ADMIN + 1 ve do rong (chua co giai)
 * bang TicketDAOImpl, sau do dung LotteryPrizeDAOImpl de them/doc cac giai cua ve do do.
 */
class LotteryPrizeDAOImplTest {

    private final LotteryPrizeDAOImpl dao = new LotteryPrizeDAOImpl();
    private final TicketDAOImpl ticketDao = new TicketDAOImpl();
    private final UserDAOImpl userDao = new UserDAOImpl();

    private Long adminUserId;
    private Long ticketId;

    @BeforeEach
    void setUp() {
        String suffix = TestSupport.uniqueDigits(9);
        User admin = new User("Admin Test", "tk_" + suffix + "@test.local", "0" + suffix, "hash");
        admin.setRole("ADMIN");
        adminUserId = userDao.insert(admin);

        LotteryTicket t = new LotteryTicket();
        t.setCompanyCode("mien-bac");
        t.setDrawDate(LocalDate.now().plusYears(5).plusDays(Long.parseLong(suffix) % 3000));
        t.setCreatedBy(adminUserId);
        ticketId = ticketDao.insertWithPrizes(t, List.of(), false); // ve do chua co giai nao
    }

    @AfterEach
    void tearDown() {
        TestSupport.update("DELETE FROM lottery_ticket_items WHERE ticket_id = ?", ticketId);
        TestSupport.update("DELETE FROM lottery_tickets WHERE id = ?", ticketId);
        TestSupport.update("DELETE FROM users WHERE id = ?", adminUserId);
    }

    @Test
    void insertAll_thenFindByTicketId_shouldReturnAllInsertedPrizes() {
        dao.insertAll(ticketId, List.of(
                new LotteryPrize("DB", "Đặc biệt", "111111"),
                new LotteryPrize("G1", "Giải nhất", "222222")
        ));

        List<LotteryPrize> prizes = dao.findByTicketId(ticketId);

        assertEquals(2, prizes.size());
        assertTrue(prizes.stream().anyMatch(p -> "DB".equals(p.getPrizeCode()) && "111111".equals(p.getPrizeNumber())));
        assertTrue(prizes.stream().anyMatch(p -> "G1".equals(p.getPrizeCode()) && "222222".equals(p.getPrizeNumber())));
    }

    @Test
    void findByTicketId_whenNoPrizeInserted_shouldReturnEmptyList() {
        assertTrue(dao.findByTicketId(ticketId).isEmpty());
    }
}
