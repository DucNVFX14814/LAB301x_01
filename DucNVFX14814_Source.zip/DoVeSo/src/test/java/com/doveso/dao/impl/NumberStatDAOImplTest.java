package com.doveso.dao.impl;

import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryTicket;
import com.doveso.model.PrizeDrawRow;
import com.doveso.model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cho NumberStatDAOImpl - CN4 (*): thong ke/de xuat so ve so nen mua.
 * Tao rieng 1 cong ty xo so tam thoi (khong dung 'mien-bac' that) de findAllPublishedPrizeNumbers
 * chi tra ve dung du lieu test, khong bi anh huong boi cac ve do that da co san trong CSDL.
 */
class NumberStatDAOImplTest {

    private final NumberStatDAOImpl dao = new NumberStatDAOImpl();
    private final TicketDAOImpl ticketDao = new TicketDAOImpl();
    private final UserDAOImpl userDao = new UserDAOImpl();

    private String companyCode;
    private Long adminUserId;
    private Long ticketId;
    private LocalDate drawDate;

    @BeforeEach
    void setUp() {
        String suffix = TestSupport.uniqueDigits(9);

        companyCode = "test-co-" + suffix;
        TestSupport.update("INSERT INTO lottery_companies (company_code, company_name, region_code, active) "
                + "VALUES (?, ?, 'BAC', TRUE)", companyCode, "Test Company " + suffix);

        User admin = new User("Admin Test", "tk_" + suffix + "@test.local", "0" + suffix, "hash");
        admin.setRole("ADMIN");
        adminUserId = userDao.insert(admin);

        drawDate = LocalDate.now().plusYears(5).plusDays(Long.parseLong(suffix) % 3000);
        LotteryTicket t = new LotteryTicket();
        t.setCompanyCode(companyCode);
        t.setDrawDate(drawDate);
        t.setCreatedBy(adminUserId);
        ticketId = ticketDao.insertWithPrizes(t, List.of(
                new LotteryPrize("DB", "Đặc biệt", "888888"),
                new LotteryPrize("G1", "Giải nhất", "111222")
        ), true); // publish luon vi ham can kiem tra chi doc ve do PUBLISH
    }

    @AfterEach
    void tearDown() {
        TestSupport.update("DELETE FROM lottery_ticket_items WHERE ticket_id = ?", ticketId);
        TestSupport.update("DELETE FROM lottery_tickets WHERE id = ?", ticketId);
        TestSupport.update("DELETE FROM users WHERE id = ?", adminUserId);
        TestSupport.update("DELETE FROM lottery_companies WHERE company_code = ?", companyCode);
    }

    @Test
    void findAllPublishedPrizeNumbers_shouldReturnExactlyOurTwoPrizeRows() {
        List<PrizeDrawRow> rows = dao.findAllPublishedPrizeNumbers(companyCode);

        assertEquals(2, rows.size());
        assertTrue(rows.stream().anyMatch(r -> r.getDrawDate().equals(drawDate) && "888888".equals(r.getPrizeNumber())));
        assertTrue(rows.stream().anyMatch(r -> r.getDrawDate().equals(drawDate) && "111222".equals(r.getPrizeNumber())));
    }

    @Test
    void findAllPublishedPrizeNumbers_unknownCompany_shouldReturnEmptyList() {
        assertTrue(dao.findAllPublishedPrizeNumbers("khong-ton-tai-xyz").isEmpty());
    }
}
