package com.doveso.dao.impl;

import com.doveso.model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cho UserDAOImpl (bang users) - CN1: Quan ly nguoi dung.
 * Day la integration test: chay tren CSDL MySQL that (doveso_db) qua DBConnectionUtil
 * (cau hinh trong src/main/resources/db.properties), KHONG dung mock.
 * Moi test tu tao du lieu rieng (email/phone co hau to ngau nhien, khong trung du lieu that)
 * va tu xoa lai trong tearDown() de khong lam ban CSDL.
 */
class UserDAOImplTest {

    private final UserDAOImpl dao = new UserDAOImpl();

    private String email;
    private String phone;
    private Long createdUserId;

    @BeforeEach
    void setUp() {
        String suffix = TestSupport.uniqueDigits(9);
        email = "ut_" + suffix + "@test.local";
        phone = "0" + suffix;
        createdUserId = null;
    }

    @AfterEach
    void tearDown() {
        if (createdUserId != null) {
            TestSupport.update("DELETE FROM users WHERE id = ?", createdUserId);
        }
    }

    private User newUser() {
        return new User("Nguyen Van Test", email, phone, "hash123");
    }

    @Test
    void insert_thenFindById_shouldReturnSameUserWithDefaultRoleAndActive() {
        createdUserId = dao.insert(newUser());

        User found = dao.findById(createdUserId);

        assertNotNull(found);
        assertEquals(email, found.getEmail());
        assertEquals(phone, found.getPhone());
        assertEquals("USER", found.getRole());
        assertTrue(found.isActive());
    }

    @Test
    void insert_thenFindByEmail_shouldReturnSameUser() {
        createdUserId = dao.insert(newUser());

        User found = dao.findByEmail(email);

        assertNotNull(found);
        assertEquals(createdUserId, found.getId());
    }

    @Test
    void existsByEmail_and_existsByPhone_shouldDistinguishExistingFromNonExisting() {
        createdUserId = dao.insert(newUser());

        assertTrue(dao.existsByEmail(email));
        assertTrue(dao.existsByPhone(phone));
        assertFalse(dao.existsByEmail("khongtontai_" + email));
        assertFalse(dao.existsByPhone("0999999999"));
    }

    @Test
    void updatePassword_shouldChangePasswordHash() {
        createdUserId = dao.insert(newUser());

        dao.updatePassword(createdUserId, "new_hash_456");

        assertEquals("new_hash_456", dao.findById(createdUserId).getPasswordHash());
    }

    @Test
    void updateRoleAndStatus_shouldUpdateBothRoleAndActiveInOneCall() {
        createdUserId = dao.insert(newUser());

        dao.updateRoleAndStatus(createdUserId, "ADMIN", false);

        User found = dao.findById(createdUserId);
        assertEquals("ADMIN", found.getRole());
        assertFalse(found.isActive());
    }

    @Test
    void updateLastLogin_shouldSetLastLoginTimestamp() {
        createdUserId = dao.insert(newUser());
        assertNull(dao.findById(createdUserId).getLastLoginAt());

        dao.updateLastLogin(createdUserId);

        assertNotNull(dao.findById(createdUserId).getLastLoginAt());
    }

    @Test
    void search_byEmailKeyword_shouldReturnOnlyMatchingUser() {
        createdUserId = dao.insert(newUser());

        List<User> results = dao.search(email, null, false, 1, 20);

        assertEquals(1, results.size());
        assertEquals(createdUserId, results.get(0).getId());
    }

    @Test
    void count_byEmailKeyword_shouldMatchSearchResultSize() {
        createdUserId = dao.insert(newUser());

        assertEquals(1, dao.count(email, null, false));
    }

    @Test
    void search_neverLoggedIn_shouldIncludeUserThatNeverLoggedIn() {
        createdUserId = dao.insert(newUser());

        List<User> results = dao.search(email, null, true, 1, 20);

        assertEquals(1, results.size());
    }

    @Test
    void search_neverLoggedIn_shouldExcludeUserThatAlreadyLoggedIn() {
        createdUserId = dao.insert(newUser());
        dao.updateLastLogin(createdUserId);

        List<User> results = dao.search(email, null, true, 1, 20);

        assertTrue(results.isEmpty());
    }

    @Test
    void saveResetToken_thenFindByValidResetToken_shouldReturnUser() {
        createdUserId = dao.insert(newUser());
        String tokenHash = "token_hash_" + TestSupport.uniqueDigits(9);

        dao.saveResetToken(createdUserId, tokenHash, LocalDateTime.now().plusMinutes(30));
        User found = dao.findByValidResetToken(tokenHash);

        assertNotNull(found);
        assertEquals(createdUserId, found.getId());
    }

    @Test
    void findByValidResetToken_expiredToken_shouldReturnNull() {
        createdUserId = dao.insert(newUser());
        String tokenHash = "token_hash_" + TestSupport.uniqueDigits(9);
        dao.saveResetToken(createdUserId, tokenHash, LocalDateTime.now().minusMinutes(1));

        assertNull(dao.findByValidResetToken(tokenHash));
    }

    @Test
    void resetPasswordWithToken_validToken_shouldUpdatePasswordAndInvalidateToken() {
        createdUserId = dao.insert(newUser());
        String tokenHash = "token_hash_" + TestSupport.uniqueDigits(9);
        dao.saveResetToken(createdUserId, tokenHash, LocalDateTime.now().plusMinutes(30));

        boolean updated = dao.resetPasswordWithToken(tokenHash, "reset_hash_789");

        assertTrue(updated);
        assertEquals("reset_hash_789", dao.findById(createdUserId).getPasswordHash());
        // Token chi dung duoc 1 lan: sau khi dung, tim lai theo token cu phai tra ve null
        assertNull(dao.findByValidResetToken(tokenHash));
    }

    @Test
    void resetPasswordWithToken_invalidToken_shouldReturnFalseAndKeepOldPassword() {
        createdUserId = dao.insert(newUser());

        boolean updated = dao.resetPasswordWithToken("token_khong_ton_tai", "reset_hash_000");

        assertFalse(updated);
        assertEquals("hash123", dao.findById(createdUserId).getPasswordHash());
    }
}
