package com.doveso.bo;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.NumberStatDAO;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryRegion;
import com.doveso.model.PrizeDrawRow;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Unit test NumberSuggestionBOImpl (Chuc nang 4) voi cac DAO duoc mock - khong can CSDL. */
class NumberSuggestionBOImplTest {

    private NumberStatDAO statDAO;
    private CompanyDAO companyDAO;
    private NumberSuggestionBOImpl bo;
    private LotteryCompany bac;

    @BeforeEach
    void setUp() {
        statDAO = mock(NumberStatDAO.class);
        companyDAO = mock(CompanyDAO.class);
        bo = new NumberSuggestionBOImpl(statDAO, companyDAO);
        bac = new LotteryCompany("mien-bac", "Miền Bắc", "BAC");
        bac.setActive(true);
    }

    @Test
    void suggest_noCompanySelected_shouldReturnNothingAndNotQueryDatabase() {
        NumberSuggestionBO.Suggestion s1 = bo.suggest("");
        NumberSuggestionBO.Suggestion s2 = bo.suggest(null);
        NumberSuggestionBO.Suggestion s3 = bo.suggest("   ");

        for (NumberSuggestionBO.Suggestion s : List.of(s1, s2, s3)) {
            assertNull(s.getError());
            assertNull(s.getCompany());
            assertNull(s.getResult());
        }
        verify(companyDAO, never()).findByCode(any());
        verify(statDAO, never()).findAllPublishedPrizeNumbers(any());
    }

    @Test
    void suggest_unknownCompany_shouldReturnError() {
        when(companyDAO.findByCode("khong-co")).thenReturn(null);

        NumberSuggestionBO.Suggestion s = bo.suggest("khong-co");

        assertEquals("Vui lòng chọn tỉnh xổ số hợp lệ.", s.getError());
        assertNull(s.getCompany());
        assertNull(s.getResult());
        verify(statDAO, never()).findAllPublishedPrizeNumbers(any());
    }

    @Test
    void suggest_inactiveCompany_shouldReturnError() {
        bac.setActive(false);
        when(companyDAO.findByCode("mien-bac")).thenReturn(bac);

        NumberSuggestionBO.Suggestion s = bo.suggest("mien-bac");

        assertEquals("Vui lòng chọn tỉnh xổ số hợp lệ.", s.getError());
        verify(statDAO, never()).findAllPublishedPrizeNumbers(any());
    }

    @Test
    void suggest_validCompany_shouldAnalyzePublishedDrawsOfThatCompany() {
        when(companyDAO.findByCode("mien-bac")).thenReturn(bac);
        when(statDAO.findAllPublishedPrizeNumbers("mien-bac")).thenReturn(List.of(
                new PrizeDrawRow(LocalDate.of(2026, 10, 5), "19654-62219"),
                new PrizeDrawRow(LocalDate.of(2026, 10, 4), "82951-28235")));

        NumberSuggestionBO.Suggestion s = bo.suggest("  mien-bac ");

        assertNull(s.getError());
        assertSame(bac, s.getCompany());
        assertFalse(s.getResult().isNoData());
        assertEquals(2, s.getResult().getTotalDraws());
        assertEquals("19", s.getResult().getHotNumbers().get(0).getNumber());
        assertTrue(s.getResult().getHotNumbers().size() <= NumberSuggestionBO.TOP_N);
    }

    @Test
    void suggest_companyWithoutPublishedDraws_shouldReportNoData() {
        when(companyDAO.findByCode("mien-bac")).thenReturn(bac);
        when(statDAO.findAllPublishedPrizeNumbers("mien-bac")).thenReturn(List.of());

        NumberSuggestionBO.Suggestion s = bo.suggest("mien-bac");

        assertNull(s.getError());
        assertTrue(s.getResult().isNoData());
    }

    @Test
    void getRegionsAndCompanies_shouldDelegateToCompanyDao() {
        List<LotteryRegion> regions = List.of(new LotteryRegion("BAC", "Miền Bắc"));
        when(companyDAO.findAllRegions()).thenReturn(regions);
        when(companyDAO.findActiveCompanies()).thenReturn(List.of(bac));

        assertSame(regions, bo.getRegions());
        assertEquals(List.of(bac), bo.getCompanies());
    }
}
