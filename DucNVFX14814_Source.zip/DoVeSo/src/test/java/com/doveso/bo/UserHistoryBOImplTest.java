package com.doveso.bo;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryHistoryDAO;
import com.doveso.model.LotteryHistory;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit test UserHistoryBOImpl (UC16 xem lich su do ve) voi cac DAO duoc mock - khong can CSDL.
 * Dung "hom nay" co dinh (2026-10-07) de ket qua khong phu thuoc ngay chay test.
 */
class UserHistoryBOImplTest {

    private static final LocalDate TODAY = LocalDate.of(2026, 10, 7);

    private LotteryHistoryDAO historyDAO;
    private CompanyDAO companyDAO;
    private UserHistoryBOImpl bo;

    @BeforeEach
    void setUp() {
        historyDAO = mock(LotteryHistoryDAO.class);
        companyDAO = mock(CompanyDAO.class);
        bo = new UserHistoryBOImpl(historyDAO, companyDAO);
    }

    @Test
    void getHistory_noParameters_shouldDefaultToCurrentMonthAndFirstPage() {
        when(historyDAO.countByUserId(5L, "", "", LocalDate.of(2026, 10, 1), TODAY)).thenReturn(3L);
        List<LotteryHistory> rows = new ArrayList<>();
        when(historyDAO.findByUserId(5L, "", "", LocalDate.of(2026, 10, 1), TODAY, 1, 10)).thenReturn(rows);

        UserHistoryBO.HistoryPage p = bo.getHistory(5L, null, null, null, null, null, TODAY);

        assertEquals(LocalDate.of(2026, 10, 1), p.getFromDate());
        assertEquals(TODAY, p.getToDate());
        assertEquals(TODAY, p.getToday());
        assertEquals("", p.getRegion());
        assertEquals("", p.getCompany());
        assertEquals(3L, p.getTotal());
        assertEquals(1, p.getPage());
        assertEquals(1, p.getTotalPages());
        assertSame(rows, p.getHistory());
    }

    @Test
    void getHistory_explicitFilters_shouldBeTrimmedAndPassedToDao() {
        when(historyDAO.countByUserId(5L, "BAC", "mien-bac", LocalDate.of(2026, 9, 1), LocalDate.of(2026, 9, 30)))
                .thenReturn(25L);

        UserHistoryBO.HistoryPage p = bo.getHistory(5L, " BAC ", " mien-bac ", "2026-09-01", "2026-09-30", "2", TODAY);

        assertEquals("BAC", p.getRegion());
        assertEquals("mien-bac", p.getCompany());
        assertEquals(3, p.getTotalPages());
        assertEquals(2, p.getPage());
        verify(historyDAO).findByUserId(5L, "BAC", "mien-bac", LocalDate.of(2026, 9, 1),
                LocalDate.of(2026, 9, 30), 2, UserHistoryBO.PAGE_SIZE);
    }

    @Test
    void getHistory_invalidOrBlankDates_shouldFallBackToDefaults() {
        UserHistoryBO.HistoryPage p = bo.getHistory(5L, "", "", "abc", "  ", "1", TODAY);

        assertEquals(LocalDate.of(2026, 10, 1), p.getFromDate());
        assertEquals(TODAY, p.getToDate());
    }

    @Test
    void getHistory_toDateInTheFuture_shouldBeCappedAtToday() {
        UserHistoryBO.HistoryPage p = bo.getHistory(5L, "", "", "2026-10-01", "2030-01-01", "1", TODAY);

        assertEquals(TODAY, p.getToDate());
    }

    @Test
    void getHistory_fromDateAfterToDate_shouldBeMovedToToDate() {
        UserHistoryBO.HistoryPage p = bo.getHistory(5L, "", "", "2026-10-06", "2026-10-02", "1", TODAY);

        assertEquals(LocalDate.of(2026, 10, 2), p.getFromDate());
        assertEquals(LocalDate.of(2026, 10, 2), p.getToDate());
    }

    @Test
    void getHistory_pageIsClampedToValidRange() {
        when(historyDAO.countByUserId(anyLong(), anyString(), anyString(), any(LocalDate.class),
                any(LocalDate.class))).thenReturn(25L); // 3 trang

        assertEquals(3, bo.getHistory(5L, "", "", null, null, "99", TODAY).getPage());
        assertEquals(1, bo.getHistory(5L, "", "", null, null, "0", TODAY).getPage());
        assertEquals(1, bo.getHistory(5L, "", "", null, null, "-4", TODAY).getPage());
        assertEquals(1, bo.getHistory(5L, "", "", null, null, "abc", TODAY).getPage());
        assertEquals(1, bo.getHistory(5L, "", "", null, null, null, TODAY).getPage());
    }

    @Test
    void getHistory_noHistory_shouldStillHaveOnePage() {
        UserHistoryBO.HistoryPage p = bo.getHistory(5L, "", "", null, null, "7", TODAY);

        assertEquals(0L, p.getTotal());
        assertEquals(1, p.getTotalPages());
        assertEquals(1, p.getPage());
        verify(historyDAO).findByUserId(anyLong(), anyString(), anyString(), any(LocalDate.class),
                any(LocalDate.class), anyInt(), anyInt());
    }

    @Test
    void pageSize_shouldBeTen() {
        assertEquals(10, UserHistoryBO.PAGE_SIZE);
    }
}
