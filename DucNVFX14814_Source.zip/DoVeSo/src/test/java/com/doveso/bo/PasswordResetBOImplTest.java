package com.doveso.bo;

import com.doveso.dao.UserDAO;
import com.doveso.model.User;
import com.doveso.util.PasswordUtil;
import com.doveso.util.ResetMailSender;
import com.doveso.util.ResetTokenUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit test PasswordResetBOImpl (UC05 quen mat khau) voi UserDAO va ResetMailSender duoc mock,
 * executor chay dong bo (Runnable::run) nen khong can CSDL, khong can SMTP, khong can mang.
 */
class PasswordResetBOImplTest {

    private static final String FALLBACK = "http://localhost:8080/doveso";

    private UserDAO dao;
    private ResetMailSender sender;
    private PasswordResetBOImpl bo;

    @BeforeEach
    void setUp() {
        dao = mock(UserDAO.class);
        sender = mock(ResetMailSender.class);
        bo = new PasswordResetBOImpl(dao, sender, Runnable::run);
    }

    private static User user(Long id, boolean active) {
        User u = new User();
        u.setId(id);
        u.setFullName("Nguyen An");
        u.setEmail("an@funix.edu.vn");
        u.setActive(active);
        return u;
    }

    // ------------------------------------------------------------------ requestReset

    @Test
    void requestReset_blankOrInvalidEmail_shouldFailWithoutTouchingDatabase() {
        assertEquals("Email không hợp lệ.", bo.requestReset("", FALLBACK).getError());
        assertEquals("Email không hợp lệ.", bo.requestReset("   ", FALLBACK).getError());
        assertEquals("Email không hợp lệ.", bo.requestReset("khongphaiemail", FALLBACK).getError());
        assertEquals("Email không hợp lệ.", bo.requestReset(null, FALLBACK).getError());
        verify(dao, never()).findByEmail(any());
    }

    @Test
    void requestReset_unknownEmail_shouldSucceedSilentlyWithoutSendingMail() throws Exception {
        when(dao.findByEmail("an@funix.edu.vn")).thenReturn(null);

        BoResult<Void> r = bo.requestReset("an@funix.edu.vn", FALLBACK);

        assertTrue(r.isOk());
        verify(dao, never()).saveResetToken(anyLong(), anyString(), any(LocalDateTime.class));
        verify(sender, never()).sendResetPasswordMail(anyString(), anyString(), anyString(), anyInt());
    }

    @Test
    void requestReset_lockedAccount_shouldSucceedSilentlyWithoutSendingMail() throws Exception {
        when(dao.findByEmail("an@funix.edu.vn")).thenReturn(user(1L, false));
        when(sender.isConfigured()).thenReturn(true);

        BoResult<Void> r = bo.requestReset("an@funix.edu.vn", FALLBACK);

        assertTrue(r.isOk());
        verify(dao, never()).saveResetToken(anyLong(), anyString(), any(LocalDateTime.class));
        verify(sender, never()).sendResetPasswordMail(anyString(), anyString(), anyString(), anyInt());
    }

    @Test
    void requestReset_mailNotConfigured_shouldSucceedSilentlyWithoutSendingMail() throws Exception {
        when(dao.findByEmail("an@funix.edu.vn")).thenReturn(user(1L, true));
        when(sender.isConfigured()).thenReturn(false);

        BoResult<Void> r = bo.requestReset("an@funix.edu.vn", FALLBACK);

        assertTrue(r.isOk());
        verify(dao, never()).saveResetToken(anyLong(), anyString(), any(LocalDateTime.class));
        verify(sender, never()).sendResetPasswordMail(anyString(), anyString(), anyString(), anyInt());
    }

    @Test
    void requestReset_activeUser_shouldStoreHashedTokenAndMailLinkWithTheSameToken() throws Exception {
        when(dao.findByEmail("an@funix.edu.vn")).thenReturn(user(1L, true));
        when(sender.isConfigured()).thenReturn(true);
        when(sender.getConfiguredBaseUrl()).thenReturn(null);
        LocalDateTime before = LocalDateTime.now();

        BoResult<Void> r = bo.requestReset("an@funix.edu.vn", FALLBACK);

        assertTrue(r.isOk());
        ArgumentCaptor<String> hash = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<LocalDateTime> expireAt = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(dao).saveResetToken(eq(1L), hash.capture(), expireAt.capture());
        ArgumentCaptor<String> link = ArgumentCaptor.forClass(String.class);
        verify(sender).sendResetPasswordMail(eq("an@funix.edu.vn"), eq("Nguyen An"), link.capture(),
                eq(ResetTokenUtil.EXPIRE_MINUTES));

        String prefix = FALLBACK + "/reset-password?token=";
        assertTrue(link.getValue().startsWith(prefix));
        String token = link.getValue().substring(prefix.length());
        assertEquals(hash.getValue(), ResetTokenUtil.hash(token)); // DB chi luu ban bam, khong luu token goc
        assertTrue(expireAt.getValue().isAfter(before.plusMinutes(ResetTokenUtil.EXPIRE_MINUTES - 1)));
        assertTrue(expireAt.getValue().isBefore(LocalDateTime.now().plusMinutes(ResetTokenUtil.EXPIRE_MINUTES + 1)));
    }

    @Test
    void requestReset_configuredBaseUrl_shouldBeUsedInsteadOfFallback() throws Exception {
        when(dao.findByEmail("an@funix.edu.vn")).thenReturn(user(1L, true));
        when(sender.isConfigured()).thenReturn(true);
        when(sender.getConfiguredBaseUrl()).thenReturn("https://doveso.example.com");

        bo.requestReset("an@funix.edu.vn", FALLBACK);

        ArgumentCaptor<String> link = ArgumentCaptor.forClass(String.class);
        verify(sender).sendResetPasswordMail(anyString(), anyString(), link.capture(), anyInt());
        assertTrue(link.getValue().startsWith("https://doveso.example.com/reset-password?token="));
    }

    @Test
    void requestReset_mailSendingFails_shouldStillSucceed() throws Exception {
        when(dao.findByEmail("an@funix.edu.vn")).thenReturn(user(1L, true));
        when(sender.isConfigured()).thenReturn(true);
        org.mockito.Mockito.doThrow(new RuntimeException("smtp down")).when(sender)
                .sendResetPasswordMail(anyString(), anyString(), anyString(), anyInt());

        BoResult<Void> r = bo.requestReset("an@funix.edu.vn", FALLBACK);

        assertTrue(r.isOk());
    }

    @Test
    void requestReset_savingTokenFails_shouldStillSucceedAndNotSendMail() throws Exception {
        when(dao.findByEmail("an@funix.edu.vn")).thenReturn(user(1L, true));
        when(sender.isConfigured()).thenReturn(true);
        org.mockito.Mockito.doThrow(new RuntimeException("db down")).when(dao)
                .saveResetToken(anyLong(), anyString(), any(LocalDateTime.class));

        BoResult<Void> r = bo.requestReset("an@funix.edu.vn", FALLBACK);

        assertTrue(r.isOk());
        verify(sender, never()).sendResetPasswordMail(anyString(), anyString(), anyString(), anyInt());
    }

    // ------------------------------------------------------------------ findUserByToken

    @Test
    void findUserByToken_blankOrNull_shouldReturnNullWithoutQuery() {
        assertNull(bo.findUserByToken(null));
        assertNull(bo.findUserByToken("   "));
        verify(dao, never()).findByValidResetToken(any());
    }

    @Test
    void findUserByToken_shouldLookUpByHashOfTrimmedToken() {
        User u = user(1L, true);
        when(dao.findByValidResetToken(ResetTokenUtil.hash("tok123"))).thenReturn(u);

        assertSame(u, bo.findUserByToken("  tok123 "));
        assertNull(bo.findUserByToken("khac"));
    }

    // ------------------------------------------------------------------ resetPassword

    @Test
    void resetPassword_invalidToken_shouldReportInvalidToken() {
        PasswordResetBO.ResetResult r = bo.resetPassword("khongco", "123456", "123456");

        assertEquals(PasswordResetBO.Status.INVALID_TOKEN, r.getStatus());
        assertNull(r.getUser());
        verify(dao, never()).resetPasswordWithToken(any(), any());
    }

    @Test
    void resetPassword_shortOrMismatchedPassword_shouldReportInputErrorWithUser() {
        User u = user(1L, true);
        when(dao.findByValidResetToken(ResetTokenUtil.hash("tok"))).thenReturn(u);

        PasswordResetBO.ResetResult shortPw = bo.resetPassword("tok", "123", "123");
        PasswordResetBO.ResetResult mismatch = bo.resetPassword("tok", "abcdef", "abcdeg");

        assertEquals(PasswordResetBO.Status.INVALID_INPUT, shortPw.getStatus());
        assertEquals("Mật khẩu phải có ít nhất 6 ký tự.", shortPw.getError());
        assertSame(u, shortPw.getUser());
        assertEquals(PasswordResetBO.Status.INVALID_INPUT, mismatch.getStatus());
        assertEquals("Mật khẩu xác nhận không khớp.", mismatch.getError());
        verify(dao, never()).resetPasswordWithToken(any(), any());
    }

    @Test
    void resetPassword_valid_shouldSaveBcryptHashOfNewPasswordUsingTokenHash() {
        when(dao.findByValidResetToken(ResetTokenUtil.hash("tok"))).thenReturn(user(1L, true));
        when(dao.resetPasswordWithToken(eq(ResetTokenUtil.hash("tok")), anyString())).thenReturn(true);

        PasswordResetBO.ResetResult r = bo.resetPassword(" tok ", "newpass1", "newpass1");

        assertEquals(PasswordResetBO.Status.SUCCESS, r.getStatus());
        assertFalse(r.getUser() == null);
        ArgumentCaptor<String> pwHash = ArgumentCaptor.forClass(String.class);
        verify(dao).resetPasswordWithToken(eq(ResetTokenUtil.hash("tok")), pwHash.capture());
        assertTrue(PasswordUtil.verify("newpass1", pwHash.getValue()));
    }

    @Test
    void resetPassword_tokenAlreadyUsedByAnotherRequest_shouldReportInvalidToken() {
        when(dao.findByValidResetToken(ResetTokenUtil.hash("tok"))).thenReturn(user(1L, true));
        when(dao.resetPasswordWithToken(eq(ResetTokenUtil.hash("tok")), anyString())).thenReturn(false);

        PasswordResetBO.ResetResult r = bo.resetPassword("tok", "newpass1", "newpass1");

        assertEquals(PasswordResetBO.Status.INVALID_TOKEN, r.getStatus());
    }

    @Test
    void genericMessage_shouldMentionExpiryMinutes() {
        assertTrue(PasswordResetBO.GENERIC_MESSAGE.contains(ResetTokenUtil.EXPIRE_MINUTES + " phút"));
    }
}
