package com.doveso.bo;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryHistoryDAO;
import com.doveso.dao.LotteryPrizeConfigDAO;
import com.doveso.dao.LotteryPrizeDAO;
import com.doveso.dao.TicketDAO;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryHistory;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryTicket;
import com.doveso.model.User;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit test LotteryCheckBOImpl (Chuc nang 3 - do ve so) voi cac DAO duoc mock: khong can CSDL.
 * Bao gom business rule "chi do khi ve do PUBLISH", gioi han so ve, kiem tra do dai so ve theo mien,
 * va chi luu lich su cho USER da dang nhap.
 */
class LotteryCheckBOImplTest {

    private static final LocalDate DRAW_DATE = LocalDate.of(2026, 10, 5);
    private static final String DATE = "2026-10-05";

    private TicketDAO ticketDAO;
    private LotteryPrizeDAO prizeDAO;
    private LotteryPrizeConfigDAO prizeConfigDAO;
    private LotteryHistoryDAO historyDAO;
    private CompanyDAO companyDAO;
    private LotteryCheckBOImpl bo;

    private LotteryCompany bac;
    private LotteryTicket ticket;

    @BeforeEach
    void setUp() {
        ticketDAO = mock(TicketDAO.class);
        prizeDAO = mock(LotteryPrizeDAO.class);
        prizeConfigDAO = mock(LotteryPrizeConfigDAO.class);
        historyDAO = mock(LotteryHistoryDAO.class);
        companyDAO = mock(CompanyDAO.class);
        bo = new LotteryCheckBOImpl(ticketDAO, prizeDAO, prizeConfigDAO, historyDAO, companyDAO);

        bac = new LotteryCompany("mien-bac", "Miền Bắc", "BAC");
        bac.setActive(true);
        ticket = new LotteryTicket();
        ticket.setId(9L);
        ticket.setDrawDate(DRAW_DATE);
        ticket.setStatus(LotteryTicket.STATUS_PUBLISH);

        when(companyDAO.findByCode("mien-bac")).thenReturn(bac);
        when(ticketDAO.findPublishedByCompanyAndDate("mien-bac", DRAW_DATE)).thenReturn(ticket);
        List<LotteryPrize> prizes = new ArrayList<>();
        prizes.add(new LotteryPrize("DB", "Đặc biệt", "19654"));
        prizes.add(new LotteryPrize("G1", "Giải nhất", "62219"));
        prizes.add(new LotteryPrize("G7", "Giải bảy", "44-70-72-15"));
        when(prizeDAO.findByTicketId(9L)).thenReturn(prizes);
        when(prizeConfigDAO.findAmountsByRegion("BAC")).thenReturn(
                Map.of("DB", 1_000_000_000L, "G1", 30_000_000L, "G7", 200_000L));
    }

    private static User loggedInUser() {
        User u = new User();
        u.setId(3L);
        return u;
    }

    // ------------------------------------------------------------------ kiem tra dau vao

    @Test
    void check_invalidCompany_shouldAskForValidProvinceAndHaveNoCompany() {
        LotteryCheckBO.CheckOutcome blank = bo.check("  ", DATE, "19654", null, null);
        LotteryCheckBO.CheckOutcome unknown = bo.check("khong-co", DATE, "19654", null, null);

        assertEquals("Vui lòng chọn tỉnh xổ số hợp lệ.", blank.getError());
        assertNull(blank.getCompany());
        assertEquals("Vui lòng chọn tỉnh xổ số hợp lệ.", unknown.getError());
    }

    @Test
    void check_inactiveCompany_shouldBeRejected() {
        bac.setActive(false);

        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, "19654", null, null);

        assertEquals("Vui lòng chọn tỉnh xổ số hợp lệ.", r.getError());
        assertNull(r.getCompany());
    }

    @Test
    void check_invalidOrMissingDate_shouldAskForValidDate() {
        assertEquals("Vui lòng chọn ngày quay số hợp lệ.", bo.check("mien-bac", "05/10/2026", "19654", null, null).getError());
        assertEquals("Vui lòng chọn ngày quay số hợp lệ.", bo.check("mien-bac", null, "19654", null, null).getError());
        assertSame(bac, bo.check("mien-bac", null, "19654", null, null).getCompany());
    }

    @Test
    void check_ticketNotPublishedOrMissing_shouldBeRejectedByBusinessRule() {
        when(ticketDAO.findPublishedByCompanyAndDate("mien-bac", DRAW_DATE)).thenReturn(null);

        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, "19654", null, null);

        assertEquals("Vé dò Miền Bắc ngày 05/10/2026 không tồn tại hoặc chưa được công bố kết quả.", r.getError());
        verify(historyDAO, never()).insert(any(LotteryHistory.class));
    }

    @Test
    void check_noTicketNumberEntered_shouldAskForAtLeastOne() {
        assertEquals("Vui lòng nhập ít nhất 1 số vé số.", bo.check("mien-bac", DATE, "  ", null, null).getError());
        assertEquals("Vui lòng nhập ít nhất 1 số vé số.",
                bo.check("mien-bac", DATE, null, " \n , ", loggedInUser()).getError());
    }

    @Test
    void check_wrongLengthForNorthRegion_shouldExplainExpectedLength() {
        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, "123456", null, null);

        assertEquals("Số vé số \"123456\" không hợp lệ. Số vé Miền Bắc phải gồm đúng 5 chữ số.", r.getError());
    }

    @Test
    void check_southOrCentralTicketNeedsSixDigits() {
        LotteryCompany daNang = new LotteryCompany("da-nang", "Đà Nẵng", "TRUNG");
        daNang.setActive(true);
        when(companyDAO.findByCode("da-nang")).thenReturn(daNang);
        when(ticketDAO.findPublishedByCompanyAndDate("da-nang", DRAW_DATE)).thenReturn(ticket);

        LotteryCheckBO.CheckOutcome r = bo.check("da-nang", DATE, "12345", null, null);

        assertEquals("Số vé số \"12345\" không hợp lệ. Số vé Đà Nẵng phải gồm đúng 6 chữ số.", r.getError());
    }

    @Test
    void check_veryLongInvalidNumber_shouldBeAbbreviatedInMessage() {
        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, "abcdefghijklmnopqrstuvwxyz", null, null);

        assertTrue(r.getError().startsWith("Số vé số \"abcdefghijkl...\" không hợp lệ."));
    }

    // ------------------------------------------------------------------ NO_USER

    @Test
    void check_guest_shouldCheckSingleNumberAndNotSaveHistory() {
        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, " 19654 ", "62219\n11111", null);

        assertNull(r.getError());
        assertSame(bac, r.getCompany());
        assertSame(ticket, r.getTicket());
        assertEquals(1, r.getResults().size()); // NO_USER chi do 1 so, bo qua textarea
        assertEquals("19654", r.getResults().get(0).getTicketNumber());
        assertTrue(r.getResults().get(0).isSpecialMatched());
        assertEquals(1_000_000_000L, r.getGrandTotal());
        verify(historyDAO, never()).insert(any(LotteryHistory.class));
    }

    @Test
    void check_guestWithNoMatch_shouldHaveZeroTotal() {
        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, "00000", null, null);

        assertNull(r.getError());
        assertEquals(0L, r.getGrandTotal());
        assertEquals("Không trúng giải", r.getResults().get(0).getSummary());
    }

    @Test
    void check_shouldAttachPrizesToTicket() {
        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, "19654", null, null);

        assertNotNull(r.getTicket().getPrizes());
        assertEquals(3, r.getTicket().getPrizes().size());
    }

    // ------------------------------------------------------------------ USER

    @Test
    void check_loggedInUser_shouldCheckSeveralNumbersWithoutDuplicatesAndSaveHistory() {
        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, "ignored",
                "19654\n62219, 19654\r\n00000", loggedInUser());

        assertNull(r.getError());
        assertEquals(3, r.getResults().size()); // 19654 bi trung nen chi tinh 1 lan
        assertEquals(1_030_000_000L, r.getGrandTotal());
        ArgumentCaptor<LotteryHistory> captor = ArgumentCaptor.forClass(LotteryHistory.class);
        verify(historyDAO, times(3)).insert(captor.capture());
        LotteryHistory first = captor.getAllValues().get(0);
        assertEquals(3L, first.getUserId());
        assertEquals(9L, first.getTicketId());
        assertEquals("19654", first.getTicketNumber());
        assertEquals("Trúng Đặc biệt", first.getResultSummary());
        assertEquals(1_000_000_000L, first.getPrizeAmount());
        LotteryHistory lost = captor.getAllValues().get(2);
        assertEquals("00000", lost.getTicketNumber());
        assertNull(lost.getPrizeAmount());
    }

    @Test
    void check_loggedInUserEntersMoreThanTwentyNumbers_shouldBeRejected() {
        StringBuilder numbers = new StringBuilder();
        for (int i = 0; i < 21; i++) {
            numbers.append(String.format("%05d", i)).append('\n');
        }

        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, null, numbers.toString(), loggedInUser());

        assertEquals("Mỗi lần chỉ được dò tối đa 20 số vé (bạn đã nhập 21 số).", r.getError());
        verify(historyDAO, never()).insert(any(LotteryHistory.class));
    }

    @Test
    void check_loggedInUserEntersExactlyTwentyNumbers_shouldBeAccepted() {
        StringBuilder numbers = new StringBuilder();
        for (int i = 0; i < 20; i++) {
            numbers.append(String.format("%05d", i)).append('\n');
        }

        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, null, numbers.toString(), loggedInUser());

        assertNull(r.getError());
        assertEquals(20, r.getResults().size());
        verify(historyDAO, times(20)).insert(any(LotteryHistory.class));
    }

    @Test
    void check_loggedInUserInputTooLong_shouldBeRejectedBeforeParsing() {
        String tooLong = "1".repeat(LotteryCheckBO.MAX_INPUT_LENGTH + 1);

        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, null, tooLong, loggedInUser());

        assertEquals("Dữ liệu nhập quá dài, vui lòng chỉ nhập tối đa 20 số vé.", r.getError());
    }

    @Test
    void check_oneInvalidNumberAmongMany_shouldRejectWholeRequestAndSaveNothing() {
        LotteryCheckBO.CheckOutcome r = bo.check("mien-bac", DATE, null, "19654\n123", loggedInUser());

        assertEquals("Số vé số \"123\" không hợp lệ. Số vé Miền Bắc phải gồm đúng 5 chữ số.", r.getError());
        verify(historyDAO, never()).insert(any(LotteryHistory.class));
    }

    @Test
    void extractTicketNumbers_guestAndUserModes() {
        assertEquals(List.of("12345"), LotteryCheckBOImpl.extractTicketNumbers(" 12345 ", "99999", false));
        assertTrue(LotteryCheckBOImpl.extractTicketNumbers(null, "99999", false).isEmpty());
        assertEquals(List.of("11111", "22222", "33333"),
                LotteryCheckBOImpl.extractTicketNumbers(null, "11111,22222\n\n33333\r\n11111", true));
        assertTrue(LotteryCheckBOImpl.extractTicketNumbers("12345", null, true).isEmpty());
    }

    @Test
    void getRegionsAndCompanies_shouldDelegateToCompanyDao() {
        when(companyDAO.findActiveCompanies()).thenReturn(List.of(bac));

        assertEquals(List.of(bac), bo.getCompanies());
        verify(companyDAO).findActiveCompanies();
        assertNotNull(bo.getRegions());
    }
}
