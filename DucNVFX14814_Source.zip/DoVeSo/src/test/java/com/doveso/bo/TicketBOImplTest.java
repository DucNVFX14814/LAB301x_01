package com.doveso.bo;

import com.doveso.dao.CompanyDAO;
import com.doveso.dao.LotteryPrizeDAO;
import com.doveso.dao.TicketDAO;
import com.doveso.model.LotteryCompany;
import com.doveso.model.LotteryPrize;
import com.doveso.model.LotteryRegion;
import com.doveso.model.LotteryTicket;
import com.doveso.model.TicketPreviewItem;
import com.doveso.model.User;
import com.doveso.util.LotteryFetchException;
import com.doveso.util.LotteryResultSource;
import com.doveso.util.MinhNgocClient.RegionResult;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit test TicketBOImpl (Chuc nang 2 - quan ly ve do) voi DAO va nguon ket qua (LotteryResultSource) duoc mock:
 * khong can CSDL, khong can mang. Bao gom dung xem truoc, luu ve do, kiem tra tham so, tim kiem + phan trang,
 * publish va chi tiet.
 */
class TicketBOImplTest {

    private static final LocalDate D1005 = LocalDate.of(2026, 10, 5);

    private CompanyDAO companyDAO;
    private TicketDAO ticketDAO;
    private LotteryPrizeDAO prizeDAO;
    private LotteryResultSource source;
    private TicketBOImpl bo;

    private final LotteryCompany bac = new LotteryCompany("mien-bac", "Miền Bắc", "BAC");
    private final LotteryCompany daNang = new LotteryCompany("da-nang", "Đà Nẵng", "TRUNG");
    private final LotteryCompany hue = new LotteryCompany("hue", "Huế", "TRUNG");

    @BeforeEach
    void setUp() {
        companyDAO = mock(CompanyDAO.class);
        ticketDAO = mock(TicketDAO.class);
        prizeDAO = mock(LotteryPrizeDAO.class);
        source = mock(LotteryResultSource.class);
        when(companyDAO.findAllRegions()).thenReturn(List.of(
                new LotteryRegion("BAC", "Miền Bắc"), new LotteryRegion("TRUNG", "Miền Trung"),
                new LotteryRegion("NAM", "Miền Nam")));
        when(companyDAO.findActiveCompanies()).thenReturn(List.of(bac, daNang, hue));
        bo = new TicketBOImpl(companyDAO, ticketDAO, prizeDAO, source);
    }

    private static List<LotteryPrize> prizes(String... codesAndNumbers) {
        List<LotteryPrize> list = new ArrayList<>();
        for (int i = 0; i < codesAndNumbers.length; i += 2) {
            list.add(new LotteryPrize(codesAndNumbers[i], "Giải " + codesAndNumbers[i], codesAndNumbers[i + 1]));
        }
        return list;
    }

    private static RegionResult resultWith(LotteryCompany company, List<LotteryPrize> prizes) {
        RegionResult r = new RegionResult();
        r.getPrizes().put(company.getCompanyCode(), prizes);
        return r;
    }

    private static User admin() {
        User u = new User();
        u.setId(2L);
        return u;
    }

    private static LotteryTicket ticket(Long id, boolean published) {
        LotteryTicket t = new LotteryTicket();
        t.setId(id);
        t.setDrawDate(D1005);
        t.setStatus(published ? LotteryTicket.STATUS_PUBLISH : LotteryTicket.STATUS_UNPUBLISH);
        return t;
    }

    // ------------------------------------------------------------------ resolveTargets / validate

    @Test
    void resolveTargets_invalidRegionOrCompany_shouldReturnNull() {
        assertNull(bo.resolveTargets("XX", "mien-bac"));
        assertNull(bo.resolveTargets("BAC", "khong-co"));
        assertNull(bo.resolveTargets("BAC", "da-nang")); // dai thuoc mien khac
        assertNull(bo.resolveTargets("NAM", TicketBO.ALL_COMPANIES)); // mien khong co dai nao
    }

    @Test
    void resolveTargets_allAndSingle_shouldReturnTheRightCompanies() {
        assertEquals(List.of(daNang, hue), bo.resolveTargets("TRUNG", TicketBO.ALL_COMPANIES));
        assertEquals(List.of(hue), bo.resolveTargets("TRUNG", "hue"));
        assertEquals(List.of(bac), bo.resolveTargets("BAC", "mien-bac"));
    }

    @Test
    void validateSingleDay_shouldReportTheFirstProblem() {
        assertEquals("Vui lòng chọn miền và tỉnh hợp lệ.", bo.validateSingleDay("XX", "mien-bac", "2026-10-05"));
        assertEquals("Ngày không hợp lệ.", bo.validateSingleDay("BAC", "mien-bac", "05/10/2026"));
        assertEquals("Ngày không hợp lệ.", bo.validateSingleDay("BAC", "mien-bac", ""));
        assertEquals("Không thể tạo vé dò cho ngày trong tương lai.",
                bo.validateSingleDay("BAC", "mien-bac", LocalDate.now().plusDays(1).toString()));
        assertNull(bo.validateSingleDay("BAC", "mien-bac", "2026-10-05"));
        assertNull(bo.validateSingleDay("BAC", "mien-bac", LocalDate.now().toString()));
    }

    @Test
    void validateRange_shouldCheckNullOrderFutureAndSameMonth() {
        assertEquals("Vui lòng chọn đầy đủ ngày bắt đầu và ngày kết thúc.",
                bo.validateRange(null, D1005));
        assertEquals("Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.",
                bo.validateRange(D1005, D1005.minusDays(1)));
        LocalDate tomorrow = LocalDate.now().plusDays(1);
        assertEquals("Không thể tạo vé dò cho ngày trong tương lai.", bo.validateRange(tomorrow, tomorrow));
        assertEquals("Khoảng ngày phải nằm trong cùng 1 tháng.",
                bo.validateRange(LocalDate.of(2026, 9, 30), LocalDate.of(2026, 10, 1)));
        assertNull(bo.validateRange(LocalDate.of(2026, 9, 1), LocalDate.of(2026, 9, 30)));
        assertNull(bo.validateRange(D1005, D1005));
    }

    // ------------------------------------------------------------------ xem truoc

    @Test
    void previewDay_newTicketFromSource_shouldBeOkWithSortedPrizes() throws Exception {
        when(source.fetchRegionPage(eq("BAC"), any(LocalDate.class), any())).thenReturn(
                Map.of(D1005, resultWith(bac, prizes("G7", "44-70-72-15", "DB", "19654"))));

        List<TicketPreviewItem> items = bo.previewDay("BAC", "mien-bac", D1005);

        assertEquals(1, items.size());
        TicketPreviewItem item = items.get(0);
        assertEquals(TicketPreviewItem.OK, item.getStatus());
        assertEquals("DB", item.getPrizes().get(0).getPrizeCode());
        assertEquals("G7", item.getPrizes().get(1).getPrizeCode());
    }

    @Test
    void previewDay_ticketAlreadyExists_shouldNotCallSource() throws Exception {
        when(ticketDAO.findByCompanyAndDate("mien-bac", D1005)).thenReturn(ticket(9L, true));
        when(prizeDAO.findByTicketId(9L)).thenReturn(prizes("DB", "19654"));

        List<TicketPreviewItem> items = bo.previewDay("BAC", "mien-bac", D1005);

        assertEquals(TicketPreviewItem.EXISTS, items.get(0).getStatus());
        assertTrue(items.get(0).isExistingPublished());
        assertEquals(9L, items.get(0).getExistingTicketId());
        verify(source, never()).fetchRegionPage(any(), any(LocalDate.class), any());
    }

    @Test
    void previewDay_sourceFails_singleCompany_shouldGiveErrorItemForThatCompany() throws Exception {
        when(source.fetchRegionPage(eq("BAC"), any(LocalDate.class), any()))
                .thenThrow(new LotteryFetchException("Không kết nối được nguồn dữ liệu."));

        List<TicketPreviewItem> items = bo.previewDay("BAC", "mien-bac", D1005);

        assertEquals(1, items.size());
        assertEquals(TicketPreviewItem.ERROR, items.get(0).getStatus());
        assertEquals("Không kết nối được nguồn dữ liệu.", items.get(0).getMessage());
        assertEquals("Miền Bắc", items.get(0).getCompanyName());
    }

    @Test
    void previewDay_sourceFails_allCompanies_shouldGiveSingleErrorForWholeDay() throws Exception {
        when(source.fetchRegionPage(eq("TRUNG"), any(LocalDate.class), any()))
                .thenThrow(new LotteryFetchException("Không kết nối được nguồn dữ liệu."));

        List<TicketPreviewItem> items = bo.previewDay("TRUNG", TicketBO.ALL_COMPANIES, D1005);

        assertEquals(1, items.size());
        assertEquals(TicketPreviewItem.ERROR, items.get(0).getStatus());
        assertNull(items.get(0).getCompanyName());
    }

    @Test
    void previewDay_sourceHasNoResultForThatDay_shouldExplainInVietnamese() throws Exception {
        when(source.fetchRegionPage(eq("BAC"), any(LocalDate.class), any())).thenReturn(Map.of());

        List<TicketPreviewItem> items = bo.previewDay("BAC", "mien-bac", D1005);

        assertEquals("Nguồn dữ liệu chưa có kết quả xổ số miền Bắc ngày 05/10/2026.", items.get(0).getMessage());
    }

    @Test
    void previewDay_sourceReportsErrorForCompany_shouldShowThatErrorOnly() throws Exception {
        RegionResult broken = new RegionResult();
        broken.getErrors().put("mien-bac", "Kết quả ngày 05/10/2026 chưa đầy đủ.");
        when(source.fetchRegionPage(eq("BAC"), any(LocalDate.class), any())).thenReturn(Map.of(D1005, broken));

        List<TicketPreviewItem> items = bo.previewDay("BAC", "mien-bac", D1005);

        assertEquals(TicketPreviewItem.ERROR, items.get(0).getStatus());
        assertEquals("Kết quả ngày 05/10/2026 chưa đầy đủ.", items.get(0).getMessage());
    }

    @Test
    void previewDay_singleProvinceOfCentralRegion_shouldUseProvincePage() throws Exception {
        when(source.fetchProvincePage(eq(daNang), any(LocalDate.class))).thenReturn(
                Map.of(D1005, resultWith(daNang, prizes("DB", "123456"))));

        List<TicketPreviewItem> items = bo.previewDay("TRUNG", "da-nang", D1005);

        assertEquals(TicketPreviewItem.OK, items.get(0).getStatus());
        verify(source, never()).fetchRegionPage(any(), any(LocalDate.class), any());
    }

    @Test
    void previewDay_provincePageFails_shouldFallBackToRegionPage() throws Exception {
        when(source.fetchProvincePage(eq(daNang), any(LocalDate.class)))
                .thenThrow(new LotteryFetchException("Loi trang rieng cua tinh"));
        when(source.fetchRegionPage(eq("TRUNG"), any(LocalDate.class), any())).thenReturn(
                Map.of(D1005, resultWith(daNang, prizes("DB", "123456"))));

        List<TicketPreviewItem> items = bo.previewDay("TRUNG", "da-nang", D1005);

        assertEquals(TicketPreviewItem.OK, items.get(0).getStatus());
        verify(source).fetchRegionPage(eq("TRUNG"), any(LocalDate.class), any());
    }

    @Test
    void previewDay_provinceDoesNotDrawThatDay_shouldReportNoDraw() throws Exception {
        when(source.fetchProvincePage(eq(daNang), any(LocalDate.class))).thenReturn(Map.of());

        List<TicketPreviewItem> items = bo.previewDay("TRUNG", "da-nang", D1005);

        assertEquals(TicketPreviewItem.ERROR, items.get(0).getStatus());
        assertEquals("Tỉnh Đà Nẵng không mở thưởng ngày 05/10/2026.", items.get(0).getMessage());
    }

    @Test
    void previewRange_provinceNotDrawingOnSomeDays_shouldSkipThoseDaysWithoutError() throws Exception {
        when(source.fetchRegionPage(eq("TRUNG"), any(LocalDate.class), any())).thenReturn(
                Map.of(D1005, resultWith(daNang, prizes("DB", "123456"))));

        List<TicketPreviewItem> items = bo.previewRange("TRUNG", TicketBO.ALL_COMPANIES, D1005, D1005);

        assertEquals(1, items.size()); // Hue khong xo ngay do -> bo qua, khong tinh la loi
        assertEquals("da-nang", items.get(0).getCompanyCode());
    }

    // ------------------------------------------------------------------ luu ve do

    @Test
    void saveOkItems_shouldSaveOnlyOkItemsWithAdminAndPublishFlag() {
        TicketPreviewItem ok = new TicketPreviewItem(D1005, bac, TicketPreviewItem.OK);
        ok.setPrizes(prizes("DB", "19654"));
        TicketPreviewItem exists = new TicketPreviewItem(D1005, daNang, TicketPreviewItem.EXISTS);
        TicketPreviewItem error = new TicketPreviewItem(D1005, hue, TicketPreviewItem.ERROR);
        when(ticketDAO.insertWithPrizes(any(LotteryTicket.class), any(), eq(true))).thenReturn(77L);
        List<Long> saved = new ArrayList<>();
        List<String> failed = new ArrayList<>();

        bo.saveOkItems(List.of(ok, exists, error), admin(), true, saved, failed);

        assertEquals(List.of(77L), saved);
        assertTrue(failed.isEmpty());
        ArgumentCaptor<LotteryTicket> captor = ArgumentCaptor.forClass(LotteryTicket.class);
        verify(ticketDAO, times(1)).insertWithPrizes(captor.capture(), any(), eq(true));
        assertEquals("mien-bac", captor.getValue().getCompanyCode());
        assertEquals(D1005, captor.getValue().getDrawDate());
        assertEquals(2L, captor.getValue().getCreatedBy());
    }

    @Test
    void saveOkItems_insertFails_shouldRecordFailureAndContinue() {
        TicketPreviewItem ok = new TicketPreviewItem(D1005, bac, TicketPreviewItem.OK);
        ok.setPrizes(prizes("DB", "19654"));
        when(ticketDAO.insertWithPrizes(any(LotteryTicket.class), any(), anyBoolean()))
                .thenThrow(new RuntimeException("db down"));
        List<Long> saved = new ArrayList<>();
        List<String> failed = new ArrayList<>();

        bo.saveOkItems(List.of(ok), admin(), false, saved, failed);

        assertTrue(saved.isEmpty());
        assertEquals(List.of("Miền Bắc 05/10/2026"), failed);
    }

    @Test
    void saveBatch_noPairsOrOnlyInvalidPairs_shouldReportNothingToSave() {
        assertEquals("Không có vé dò nào để lưu.", bo.saveBatch(admin(), "BAC", "ALL", null, false).getError());
        assertEquals("Không có vé dò nào để lưu.",
                bo.saveBatch(admin(), "BAC", "ALL", new String[0], false).getError());
        FlashResult invalid = bo.saveBatch(admin(), "BAC", "ALL",
                new String[]{"khong-co-gach", "da-nang|2026-10-05", "mien-bac|not-a-date"}, false);
        assertEquals("Không có vé dò nào để lưu.", invalid.getError());
        assertNull(invalid.getSuccess());
        verify(ticketDAO, never()).insertWithPrizes(any(LotteryTicket.class), any(), anyBoolean());
    }

    @Test
    void saveBatch_validPair_shouldSaveAndReportSuccess() throws Exception {
        when(source.fetchRegionPage(eq("BAC"), any(LocalDate.class), any())).thenReturn(
                Map.of(D1005, resultWith(bac, prizes("DB", "19654"))));
        when(ticketDAO.insertWithPrizes(any(LotteryTicket.class), any(), eq(false))).thenReturn(1L);

        FlashResult r = bo.saveBatch(admin(), "BAC", "ALL", new String[]{"mien-bac|2026-10-05"}, false);

        assertEquals("Đã lưu 1 vé dò.", r.getSuccess());
        assertNull(r.getError());
    }

    @Test
    void saveBatch_withPublish_shouldMentionPublishing() throws Exception {
        when(source.fetchRegionPage(eq("BAC"), any(LocalDate.class), any())).thenReturn(
                Map.of(D1005, resultWith(bac, prizes("DB", "19654"))));
        when(ticketDAO.insertWithPrizes(any(LotteryTicket.class), any(), eq(true))).thenReturn(1L);

        FlashResult r = bo.saveBatch(admin(), "BAC", "ALL", new String[]{"mien-bac|2026-10-05"}, true);

        assertEquals("Đã lưu và công bố 1 vé dò.", r.getSuccess());
    }

    @Test
    void saveBatch_futureDate_shouldBeReportedAsFailure() {
        String tomorrow = LocalDate.now().plusDays(1).toString();

        FlashResult r = bo.saveBatch(admin(), "BAC", "ALL", new String[]{"mien-bac|" + tomorrow}, false);

        assertNull(r.getSuccess());
        assertTrue(r.getError().contains("(ngày trong tương lai)"));
        verify(ticketDAO, never()).insertWithPrizes(any(LotteryTicket.class), any(), anyBoolean());
    }

    @Test
    void saveBatch_oneDaySavedAndOneDayMissingInSource_shouldReportBoth() throws Exception {
        when(source.fetchRegionPage(eq("BAC"), any(LocalDate.class), any())).thenReturn(
                Map.of(D1005, resultWith(bac, prizes("DB", "19654"))));
        when(ticketDAO.insertWithPrizes(any(LotteryTicket.class), any(), anyBoolean())).thenReturn(1L);

        FlashResult r = bo.saveBatch(admin(), "BAC", "ALL",
                new String[]{"mien-bac|2026-10-05", "mien-bac|2026-09-30"}, false);

        assertEquals("Đã lưu 1 vé dò.", r.getSuccess());
        assertEquals("Không lưu được 1 vé dò: Miền Bắc 30/09/2026", r.getError());
    }

    // ------------------------------------------------------------------ publish hang loat / don le

    @Test
    void publishExisting_noIds_shouldReportNothingToPublish() {
        assertEquals("Không có vé dò nào cần công bố.", bo.publishExisting(null).getError());
        assertEquals("Không có vé dò nào cần công bố.", bo.publishExisting(new String[0]).getError());
    }

    @Test
    void publishExisting_validIds_shouldPublishEachAndCount() {
        FlashResult r = bo.publishExisting(new String[]{"1", "2"});

        assertEquals("Đã công bố 2 vé dò.", r.getSuccess());
        assertNull(r.getError());
        verify(ticketDAO).publish(1L);
        verify(ticketDAO).publish(2L);
    }

    @Test
    void publishExisting_invalidIdsAreIgnored_andAllInvalidMeansNothingPublished() {
        FlashResult r = bo.publishExisting(new String[]{"abc", "x1"});

        assertNull(r.getSuccess());
        assertEquals("Không có vé dò nào được công bố.", r.getError());
        verify(ticketDAO, never()).publish(anyLong());
    }

    @Test
    void publishExisting_oneFails_shouldReportSuccessAndFailureCounts() {
        doThrow(new RuntimeException("db down")).when(ticketDAO).publish(2L);

        FlashResult r = bo.publishExisting(new String[]{"1", "2"});

        assertEquals("Đã công bố 1 vé dò.", r.getSuccess());
        assertEquals("Không công bố được 1 vé dò.", r.getError());
    }

    @Test
    void publish_unknownOrNullId_shouldReportNotFound() {
        TicketBO.PublishResult unknown = bo.publish(5L);
        TicketBO.PublishResult none = bo.publish(null);

        assertFalse(unknown.isTicketFound());
        assertEquals("Không tìm thấy vé dò cần công bố.", unknown.getError());
        assertFalse(none.isTicketFound());
        verify(ticketDAO, never()).publish(anyLong());
    }

    @Test
    void publish_alreadyPublished_shouldNotChangeStatus() {
        when(ticketDAO.findById(5L)).thenReturn(ticket(5L, true));

        TicketBO.PublishResult r = bo.publish(5L);

        assertTrue(r.isTicketFound());
        assertEquals("Vé dò ngày 05/10/2026 đã được công bố, không thể thay đổi trạng thái.", r.getError());
        verify(ticketDAO, never()).publish(anyLong());
    }

    @Test
    void publish_unpublishedTicket_shouldPublish() {
        when(ticketDAO.findById(5L)).thenReturn(ticket(5L, false));

        TicketBO.PublishResult r = bo.publish(5L);

        assertTrue(r.isTicketFound());
        assertEquals("Đã công bố vé dò ngày 05/10/2026.", r.getSuccess());
        assertNull(r.getError());
        verify(ticketDAO).publish(5L);
    }

    @Test
    void publish_daoFails_shouldReturnFriendlyError() {
        when(ticketDAO.findById(5L)).thenReturn(ticket(5L, false));
        doThrow(new RuntimeException("db down")).when(ticketDAO).publish(5L);

        TicketBO.PublishResult r = bo.publish(5L);

        assertTrue(r.isTicketFound());
        assertEquals("Không thể công bố vé dò, vui lòng thử lại.", r.getError());
    }

    // ------------------------------------------------------------------ chi tiet + so lan do

    @Test
    void getDetail_unknownOrNullId_shouldReturnNull() {
        assertNull(bo.getDetail(5L));
        assertNull(bo.getDetail(null));
    }

    @Test
    void getDetail_shouldReturnSortedPrizesAndDrawTimes() {
        when(ticketDAO.findById(5L)).thenReturn(ticket(5L, true));
        when(prizeDAO.findByTicketId(5L)).thenReturn(new ArrayList<>(prizes("G7", "44", "DB", "19654", "G1", "62219")));
        when(ticketDAO.countDrawTimes(5L)).thenReturn(12L);

        TicketBO.TicketDetail detail = bo.getDetail(5L);

        assertNotNull(detail);
        assertEquals(12L, detail.getDrawTimes());
        assertEquals("DB", detail.getPrizes().get(0).getPrizeCode());
        assertEquals("G1", detail.getPrizes().get(1).getPrizeCode());
        assertEquals("G7", detail.getPrizes().get(2).getPrizeCode());
    }

    // ------------------------------------------------------------------ tim kiem + phan trang

    @Test
    void search_firstVisit_shouldDefaultToCurrentMonthAndNoRegionFilter() {
        LocalDate today = LocalDate.now();
        when(ticketDAO.count("", "", today.withDayOfMonth(1), today, "")).thenReturn(25L);

        TicketBO.TicketSearchResult r = bo.search(null, null, null, null, null, null);

        assertNull(r.getError());
        assertEquals("", r.getRegion());
        assertEquals(today.withDayOfMonth(1).toString(), r.getFromDate());
        assertEquals(today.toString(), r.getToDate());
        assertEquals(25L, r.getTotal());
        assertEquals(3, r.getTotalPages());
        assertEquals(1, r.getPage());
    }

    @Test
    void search_pageIsClampedToValidRange() {
        when(ticketDAO.count(any(), any(), any(LocalDate.class), any(LocalDate.class), any())).thenReturn(25L);

        assertEquals(3, bo.search("", "", "", "2026-10-01", "2026-10-31", "99").getPage());
        assertEquals(1, bo.search("", "", "", "2026-10-01", "2026-10-31", "0").getPage());
        assertEquals(1, bo.search("", "", "", "2026-10-01", "2026-10-31", "abc").getPage());
        assertEquals(2, bo.search("", "", "", "2026-10-01", "2026-10-31", "2").getPage());
    }

    @Test
    void search_noResults_shouldHaveZeroPagesAndPageOne() {
        TicketBO.TicketSearchResult r = bo.search("", "", "", "2026-10-01", "2026-10-31", "5");

        assertEquals(0L, r.getTotal());
        assertEquals(0, r.getTotalPages());
        assertEquals(1, r.getPage());
        assertTrue(r.getTickets().isEmpty());
    }

    @Test
    void search_onlyFromDate_shouldSearchUpToMaxDate() {
        when(ticketDAO.count("BAC", "", LocalDate.of(2026, 10, 1), LocalDate.of(9999, 12, 31), "")).thenReturn(5L);

        TicketBO.TicketSearchResult r = bo.search("BAC", "", "", "2026-10-01", "", "1");

        assertNull(r.getError());
        assertEquals(5L, r.getTotal());
    }

    @Test
    void search_invalidFilters_shouldReturnVietnameseErrorWithoutQueryingDatabase() {
        assertEquals("Ngày tìm kiếm không hợp lệ.",
                bo.search("", "", "", "01/10/2026", "2026-10-31", "1").getError());
        assertEquals("Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.",
                bo.search("", "", "", "2026-10-31", "2026-10-01", "1").getError());
        assertEquals("Miền không hợp lệ.", bo.search("XX", "", "", "2026-10-01", "2026-10-31", "1").getError());
        assertEquals("Tỉnh không hợp lệ.", bo.search("", "khong-co", "", "2026-10-01", "2026-10-31", "1").getError());
        assertEquals("Trạng thái không hợp lệ.",
                bo.search("", "", "DELETED", "2026-10-01", "2026-10-31", "1").getError());
        verify(ticketDAO, never()).count(any(), any(), any(LocalDate.class), any(LocalDate.class), any());
    }

    // ------------------------------------------------------------------ tien ich thuan

    @Test
    void countByStatus_shouldCountEachStatus() {
        TicketPreviewItem ok = new TicketPreviewItem(D1005, bac, TicketPreviewItem.OK);
        TicketPreviewItem existsPublished = new TicketPreviewItem(D1005, daNang, TicketPreviewItem.EXISTS);
        existsPublished.setExistingPublished(true);
        TicketPreviewItem existsUnpublished = new TicketPreviewItem(D1005, hue, TicketPreviewItem.EXISTS);
        TicketPreviewItem error = new TicketPreviewItem(D1005, bac, TicketPreviewItem.ERROR);

        TicketBO.PreviewCounts counts = TicketBO.countByStatus(
                List.of(ok, ok, existsPublished, existsUnpublished, error));

        assertEquals(2, counts.successCount);
        assertEquals(1, counts.existsPublishedCount);
        assertEquals(1, counts.existsUnpublishedCount);
        assertEquals(1, counts.errorCount);
    }

    @Test
    void sortPrizes_shouldOrderByPrizeOrder() {
        List<LotteryPrize> sorted = TicketBO.sortPrizes(new ArrayList<>(prizes("G7", "1", "G2", "2", "DB", "3")));

        assertEquals("DB", sorted.get(0).getPrizeCode());
        assertEquals("G2", sorted.get(1).getPrizeCode());
        assertEquals("G7", sorted.get(2).getPrizeCode());
    }
}
