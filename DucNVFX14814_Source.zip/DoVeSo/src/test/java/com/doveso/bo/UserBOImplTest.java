package com.doveso.bo;

import com.doveso.dao.UserDAO;
import com.doveso.model.User;
import com.doveso.util.PasswordUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit test UserBOImpl (Chuc nang 1) voi UserDAO duoc mock - khong can CSDL.
 * Gom cac quy tac: dang nhap, dang ky, doi mat khau, quy tac cap quyen / khoa tai khoan (UpdateUsers), tim kiem.
 */
class UserBOImplTest {

    /** BCrypt cost 12 cham nen chi hash 1 lan cho ca lop test. */
    private static final String PASSWORD = "matkhau123";
    private static final String PASSWORD_HASH = PasswordUtil.hash(PASSWORD);

    private UserDAO dao;
    private UserBOImpl bo;

    @BeforeEach
    void setUp() {
        dao = mock(UserDAO.class);
        bo = new UserBOImpl(dao);
    }

    private static User user(Long id, String name, String role, boolean active) {
        User u = new User();
        u.setId(id);
        u.setFullName(name);
        u.setEmail(name.toLowerCase().replace(' ', '.') + "@mail.com");
        u.setRole(role);
        u.setActive(active);
        u.setPasswordHash(PASSWORD_HASH);
        return u;
    }

    private static UserBO.RoleChange change(Long id, String role, boolean active) {
        return new UserBO.RoleChange(id, role, active);
    }

    // ------------------------------------------------------------------ login

    @Test
    void login_unknownEmail_shouldFailWithoutTouchingLastLogin() {
        when(dao.findByEmail("x@mail.com")).thenReturn(null);

        BoResult<User> r = bo.login("x@mail.com", PASSWORD);

        assertFalse(r.isOk());
        assertEquals("Sai tên đăng nhập hoặc mật khẩu.", r.getError());
        verify(dao, never()).updateLastLogin(anyLong());
    }

    @Test
    void login_wrongPassword_shouldFail() {
        when(dao.findByEmail("a@mail.com")).thenReturn(user(1L, "An", "USER", true));

        BoResult<User> r = bo.login("a@mail.com", "saimatkhau");

        assertFalse(r.isOk());
        assertEquals("Sai tên đăng nhập hoặc mật khẩu.", r.getError());
        verify(dao, never()).updateLastLogin(anyLong());
    }

    @Test
    void login_lockedAccountWithCorrectPassword_shouldReportLocked() {
        when(dao.findByEmail("a@mail.com")).thenReturn(user(1L, "An", "USER", false));

        BoResult<User> r = bo.login("a@mail.com", PASSWORD);

        assertFalse(r.isOk());
        assertEquals("Tài khoản của bạn đã bị khóa, vui lòng liên hệ quản trị viên.", r.getError());
        verify(dao, never()).updateLastLogin(anyLong());
    }

    @Test
    void login_lockedAccountWithWrongPassword_shouldNotRevealLockedState() {
        when(dao.findByEmail("a@mail.com")).thenReturn(user(1L, "An", "USER", false));

        BoResult<User> r = bo.login("a@mail.com", "saimatkhau");

        assertEquals("Sai tên đăng nhập hoặc mật khẩu.", r.getError());
    }

    @Test
    void login_validCredentials_shouldReturnUserAndUpdateLastLogin() {
        User u = user(7L, "An", "USER", true);
        when(dao.findByEmail("a@mail.com")).thenReturn(u);

        BoResult<User> r = bo.login("a@mail.com", PASSWORD);

        assertTrue(r.isOk());
        assertSame(u, r.getValue());
        verify(dao).updateLastLogin(7L);
    }

    // ------------------------------------------------------------------ register

    @Test
    void register_invalidFields_shouldReturnFieldSpecificErrorAndNotInsert() {
        assertEquals("Họ và tên không hợp lệ (2-150 ký tự, chỉ gồm chữ cái và khoảng trắng).",
                bo.register("A1", "a@mail.com", "0912345678", "123456", "123456").getError());
        assertEquals("Email không đúng định dạng.",
                bo.register("Nguyen An", "khongphaiemail", "0912345678", "123456", "123456").getError());
        assertEquals("Số điện thoại phải bắt đầu bằng số 0 và có đúng 10 chữ số.",
                bo.register("Nguyen An", "a@mail.com", "123", "123456", "123456").getError());
        assertEquals("Mật khẩu phải có ít nhất 6 ký tự.",
                bo.register("Nguyen An", "a@mail.com", "0912345678", "123", "123").getError());
        assertEquals("Mật khẩu xác nhận không khớp.",
                bo.register("Nguyen An", "a@mail.com", "0912345678", "123456", "654321").getError());
        verify(dao, never()).insert(any(User.class));
    }

    @Test
    void register_emailAlreadyUsed_shouldFail() {
        when(dao.existsByEmail("a@mail.com")).thenReturn(true);

        BoResult<Void> r = bo.register("Nguyen An", "a@mail.com", "0912345678", "123456", "123456");

        assertFalse(r.isOk());
        assertEquals("Email đã được sử dụng.", r.getError());
        verify(dao, never()).insert(any(User.class));
    }

    @Test
    void register_phoneAlreadyUsed_shouldFail() {
        when(dao.existsByPhone("0912345678")).thenReturn(true);

        BoResult<Void> r = bo.register("Nguyen An", "a@mail.com", "0912345678", "123456", "123456");

        assertEquals("Số điện thoại đã được sử dụng.", r.getError());
        verify(dao, never()).insert(any(User.class));
    }

    @Test
    void register_validData_shouldInsertTrimmedUserWithHashedPasswordAndDefaultRole() {
        BoResult<Void> r = bo.register("  Nguyen An ", "a@mail.com", "0912345678", "123456", "123456");

        assertTrue(r.isOk());
        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(dao).insert(captor.capture());
        User saved = captor.getValue();
        assertEquals("Nguyen An", saved.getFullName());
        assertEquals("a@mail.com", saved.getEmail());
        assertEquals("0912345678", saved.getPhone());
        assertNotEquals("123456", saved.getPasswordHash());
        assertTrue(PasswordUtil.verify("123456", saved.getPasswordHash()));
        assertEquals("USER", saved.getRole());
    }

    @Test
    void register_insertFailsBecauseOfConcurrentDuplicate_shouldReturnFriendlyError() {
        when(dao.insert(any(User.class))).thenThrow(new RuntimeException("duplicate key"));

        BoResult<Void> r = bo.register("Nguyen An", "a@mail.com", "0912345678", "123456", "123456");

        assertFalse(r.isOk());
        assertEquals("Email hoặc số điện thoại đã được sử dụng. Vui lòng kiểm tra lại.", r.getError());
    }

    // ------------------------------------------------------------------ changePassword

    @Test
    void changePassword_blankCurrentPassword_shouldFail() {
        when(dao.findById(1L)).thenReturn(user(1L, "An", "USER", true));

        assertEquals("Vui lòng nhập mật khẩu hiện tại.",
                bo.changePassword(1L, "  ", "newpass1", "newpass1").getError());
        verify(dao, never()).updatePassword(anyLong(), anyString());
    }

    @Test
    void changePassword_wrongCurrentPasswordOrUnknownUser_shouldFail() {
        when(dao.findById(1L)).thenReturn(user(1L, "An", "USER", true));

        assertEquals("Mật khẩu hiện tại không đúng",
                bo.changePassword(1L, "saimatkhau", "newpass1", "newpass1").getError());
        assertEquals("Mật khẩu hiện tại không đúng",
                bo.changePassword(2L, PASSWORD, "newpass1", "newpass1").getError());
        verify(dao, never()).updatePassword(anyLong(), anyString());
    }

    @Test
    void changePassword_invalidNewPassword_shouldFail() {
        when(dao.findById(1L)).thenReturn(user(1L, "An", "USER", true));

        assertEquals("Mật khẩu mới phải có ít nhất 6 ký tự.",
                bo.changePassword(1L, PASSWORD, "123", "123").getError());
        assertEquals("Mật khẩu xác nhận không khớp.",
                bo.changePassword(1L, PASSWORD, "newpass1", "newpass2").getError());
        assertEquals("Mật khẩu mới phải khác mật khẩu hiện tại.",
                bo.changePassword(1L, PASSWORD, PASSWORD, PASSWORD).getError());
        verify(dao, never()).updatePassword(anyLong(), anyString());
    }

    @Test
    void changePassword_valid_shouldStoreHashOfNewPassword() {
        when(dao.findById(1L)).thenReturn(user(1L, "An", "USER", true));

        BoResult<Void> r = bo.changePassword(1L, PASSWORD, "newpass1", "newpass1");

        assertTrue(r.isOk());
        ArgumentCaptor<String> hash = ArgumentCaptor.forClass(String.class);
        verify(dao).updatePassword(eq(1L), hash.capture());
        assertTrue(PasswordUtil.verify("newpass1", hash.getValue()));
    }

    // ------------------------------------------------------------------ updateRoleAndStatus (3 quy tac)

    @Test
    void updateRoleAndStatus_lockingAnAdmin_shouldCancelEverything() {
        when(dao.findById(1L)).thenReturn(user(1L, "Admin A", "ADMIN", true));
        User requester = user(10000000L, "Master", "ADMIN", true);

        BoResult<Void> r = bo.updateRoleAndStatus(requester, List.of(change(1L, "ADMIN", false)));

        assertFalse(r.isOk());
        assertTrue(r.getError().startsWith("Không thể lưu thay đổi ("));
        assertTrue(r.getError().contains("không thể khóa hoặc hạ quyền tài khoản ADMIN: Admin A"));
        assertTrue(r.getError().endsWith("Không có thay đổi nào được lưu, vui lòng bỏ chọn các thay đổi "
                + "này rồi thử lại."));
        verify(dao, never()).updateRoleAndStatus(anyLong(), anyString(), anyBoolean());
    }

    @Test
    void updateRoleAndStatus_demotingAnAdmin_shouldBeRejected() {
        when(dao.findById(1L)).thenReturn(user(1L, "Admin A", "ADMIN", true));

        BoResult<Void> r = bo.updateRoleAndStatus(user(10000000L, "Master", "ADMIN", true),
                List.of(change(1L, "USER", true)));

        assertFalse(r.isOk());
        assertTrue(r.getError().contains("không thể khóa hoặc hạ quyền tài khoản ADMIN: Admin A"));
        verify(dao, never()).updateRoleAndStatus(anyLong(), anyString(), anyBoolean());
    }

    @Test
    void updateRoleAndStatus_keepingAdminUnchanged_shouldBeAllowed() {
        when(dao.findById(1L)).thenReturn(user(1L, "Admin A", "ADMIN", true));

        BoResult<Void> r = bo.updateRoleAndStatus(user(2L, "Admin B", "ADMIN", true),
                List.of(change(1L, "ADMIN", true)));

        assertTrue(r.isOk());
        verify(dao).updateRoleAndStatus(1L, "ADMIN", true);
    }

    @Test
    void updateRoleAndStatus_changingRoleOfLockedUser_shouldBeRejected() {
        when(dao.findById(3L)).thenReturn(user(3L, "Binh", "USER", false));

        BoResult<Void> r = bo.updateRoleAndStatus(user(10000000L, "Master", "ADMIN", true),
                List.of(change(3L, "ADMIN", false)));

        assertFalse(r.isOk());
        assertTrue(r.getError().contains(
                "tài khoản đang bị khóa nên không thể đổi ROLE, hãy mở khóa trước: Binh"));
        verify(dao, never()).updateRoleAndStatus(anyLong(), anyString(), anyBoolean());
    }

    @Test
    void updateRoleAndStatus_unlockingOrKeepingLockedUserWithSameRole_shouldBeAllowed() {
        when(dao.findById(3L)).thenReturn(user(3L, "Binh", "USER", false));
        when(dao.findById(4L)).thenReturn(user(4L, "Chi", "USER", false));

        BoResult<Void> r = bo.updateRoleAndStatus(user(2L, "Admin B", "ADMIN", true),
                List.of(change(3L, "USER", true), change(4L, "USER", false)));

        assertTrue(r.isOk());
        verify(dao).updateRoleAndStatus(3L, "USER", true);
        verify(dao).updateRoleAndStatus(4L, "USER", false);
    }

    @Test
    void updateRoleAndStatus_normalAdminPromotingUserToAdmin_shouldBeRejected() {
        when(dao.findById(5L)).thenReturn(user(5L, "Dung", "USER", true));

        BoResult<Void> r = bo.updateRoleAndStatus(user(2L, "Admin B", "ADMIN", true),
                List.of(change(5L, "ADMIN", true)));

        assertFalse(r.isOk());
        assertTrue(r.getError().contains("chỉ ADMIN chính mới được cấp quyền ADMIN cho: Dung"));
        verify(dao, never()).updateRoleAndStatus(anyLong(), anyString(), anyBoolean());
    }

    @Test
    void updateRoleAndStatus_masterAdminPromotingUserToAdmin_shouldBeAllowed() {
        when(dao.findById(5L)).thenReturn(user(5L, "Dung", "USER", true));

        BoResult<Void> r = bo.updateRoleAndStatus(user(10000000L, "Master", "ADMIN", true),
                List.of(change(5L, "ADMIN", true)));

        assertTrue(r.isOk());
        verify(dao).updateRoleAndStatus(5L, "ADMIN", true);
    }

    @Test
    void updateRoleAndStatus_anyViolation_shouldSaveNothingEvenForValidRows() {
        when(dao.findById(1L)).thenReturn(user(1L, "Admin A", "ADMIN", true));
        when(dao.findById(6L)).thenReturn(user(6L, "Em", "USER", true));

        BoResult<Void> r = bo.updateRoleAndStatus(user(10000000L, "Master", "ADMIN", true),
                List.of(change(6L, "USER", false), change(1L, "ADMIN", false)));

        assertFalse(r.isOk());
        verify(dao, never()).updateRoleAndStatus(anyLong(), anyString(), anyBoolean());
    }

    @Test
    void updateRoleAndStatus_severalKindsOfViolation_shouldListAllSeparatedBySemicolon() {
        when(dao.findById(1L)).thenReturn(user(1L, "Admin A", "ADMIN", true));
        when(dao.findById(3L)).thenReturn(user(3L, "Binh", "USER", false));
        when(dao.findById(5L)).thenReturn(user(5L, "Dung", "USER", true));

        BoResult<Void> r = bo.updateRoleAndStatus(user(2L, "Admin B", "ADMIN", true),
                List.of(change(1L, "ADMIN", false), change(3L, "ADMIN", false), change(5L, "ADMIN", true)));

        String error = r.getError();
        assertTrue(error.contains("Admin A"));
        assertTrue(error.contains("Binh"));
        assertTrue(error.contains("Dung"));
        assertEquals(2, error.split("; ", -1).length - 1);
    }

    @Test
    void masterAdmin_isOnlyTheConfiguredId() {
        assertTrue(MasterAdmin.is(user(10000000L, "Master", "ADMIN", true)));
        assertFalse(MasterAdmin.is(user(2L, "Admin B", "ADMIN", true)));
        assertFalse(MasterAdmin.is(null));
        assertFalse(MasterAdmin.is(new User()));
    }

    // ------------------------------------------------------------------ search + phan trang

    @Test
    void toLastLoginBefore_shouldMapFilterCodesToTimestamps() {
        LocalDateTime now = LocalDateTime.of(2026, 10, 7, 12, 0);

        assertEquals(now.minusDays(1), UserBOImpl.toLastLoginBefore("1d", now));
        assertEquals(now.minusWeeks(1), UserBOImpl.toLastLoginBefore("1w", now));
        assertEquals(now.minusMonths(1), UserBOImpl.toLastLoginBefore("1m", now));
        assertEquals(now.minusMonths(3), UserBOImpl.toLastLoginBefore("1q", now));
        assertEquals(now.minusYears(1), UserBOImpl.toLastLoginBefore("1y", now));
        assertNull(UserBOImpl.toLastLoginBefore("never", now));
        assertNull(UserBOImpl.toLastLoginBefore("xyz", now));
        assertNull(UserBOImpl.toLastLoginBefore(null, now));
    }

    @Test
    void search_neverLoggedInFilter_shouldPassFlagAndComputeTotalPages() {
        List<User> page = new ArrayList<>();
        page.add(user(1L, "An", "USER", true));
        when(dao.search("abc", null, true, 2, 20)).thenReturn(page);
        when(dao.count("abc", null, true)).thenReturn(45L);

        UserBO.UserPage result = bo.search("abc", "never", 2);

        assertSame(page, result.getUsers());
        assertEquals(45L, result.getTotal());
        assertEquals(3, result.getTotalPages());
        assertEquals("never", result.getNoLoginFor());
    }

    @Test
    void search_periodFilter_shouldUseTimestampAndKeepFilterCode() {
        when(dao.search(any(), any(LocalDateTime.class), eq(false), eq(1), eq(20))).thenReturn(new ArrayList<>());
        when(dao.count(any(), any(LocalDateTime.class), eq(false))).thenReturn(20L);

        UserBO.UserPage result = bo.search(null, "1w", 1);

        assertEquals("1w", result.getNoLoginFor());
        assertEquals(1, result.getTotalPages());
    }

    @Test
    void search_unknownFilterCodeOrNull_shouldNormalizeToEmptyAndHaveNoPagesWhenNoUsers() {
        when(dao.count(any(), any(), eq(false))).thenReturn(0L);

        UserBO.UserPage unknown = bo.search("", "xyz", 1);
        UserBO.UserPage none = bo.search("", null, 1);

        assertEquals("", unknown.getNoLoginFor());
        assertEquals("", none.getNoLoginFor());
        assertEquals(0, unknown.getTotalPages());
    }

    @Test
    void pageSize_shouldBeTwenty() {
        assertEquals(20, UserBO.PAGE_SIZE);
    }
}
