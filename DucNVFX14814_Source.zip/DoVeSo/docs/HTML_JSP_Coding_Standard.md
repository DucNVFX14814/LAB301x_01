# HTML / JSP Coding Standard - Dự án Dò vé số

Quy ước này áp dụng cho các tập tin JSP, HTML, CSS trong dự án, tham khảo
Google HTML/CSS Style Guide.

## 1. Cấu trúc thư mục JSP

- `WEB-INF/views/<feature>/`: JSP không được truy cập trực tiếp qua URL,
  bắt buộc đi qua Servlet (bảo mật, tuân thủ mô hình MVC).
- `WEB-INF/views/common/`: các fragment dùng chung (header, footer, navbar).
- `assets/css`, `assets/js`, `assets/images`: tài nguyên tĩnh cho giao diện public.
- `assets/admin/`: tài nguyên riêng cho khu vực quản trị.

## 2. Quy tắc đặt tên

- Tên file JSP: chữ thường, phân cách bằng dấu gạch ngang. Ví dụ: `user-list.jsp`, `check-ticket.jsp`.
- id/class trong HTML: `kebab-case`. Ví dụ: `id="main-nav"`, `class="btn-primary"`.
- Không đặt id trùng nhau trong cùng 1 trang.

## 3. Định dạng mã nguồn

- Thụt lề 4 khoảng trắng.
- Thẻ HTML luôn đóng đúng cặp, thuộc tính đặt trong dấu ngoặc kép `"..."`.
- Luôn khai báo `<meta charset="UTF-8">` và `contentType="text/html;charset=UTF-8"` ở đầu JSP.
- Sử dụng JSTL (`<c:forEach>`, `<c:if>`, `<c:choose>`) thay vì scriptlet `<% %>` để tách biệt logic hiển thị.

## 4. Bootstrap & Responsive

- Sử dụng lưới (grid) `container`, `row`, `col-*` của Bootstrap thay vì tự viết CSS căn chỉnh.
- Ưu tiên class có sẵn của Bootstrap (`btn`, `form-control`, `table`, `alert`...) trước khi viết CSS riêng.
- Kiểm tra hiển thị tối thiểu ở 2 kích thước: desktop (≥992px) và mobile (≤576px).

## 5. Khả năng truy cập & SEO cơ bản

- Mỗi ảnh có thuộc tính `alt` mô tả nội dung.
- Mỗi trang có `<title>` mô tả rõ chức năng của trang.
- Label của form luôn gắn với input tương ứng (`<label>` + `name`/`id`).
