# Java Coding Standard - Dự án Dò vé số

Quy ước này được rút gọn, áp dụng cho toàn bộ mã nguồn Java trong dự án,
tham khảo Oracle Java Code Conventions và Google Java Style Guide.

## 1. Đặt tên (Naming)

| Thành phần | Quy tắc | Ví dụ |
|---|---|---|
| Package | chữ thường, không dấu gạch dưới | `com.doveso.controller` |
| Class / Interface | PascalCase, danh từ | `UserDAO`, `LotteryTicket` |
| Method | camelCase, động từ | `findByEmail()`, `insertTicket()` |
| Biến, tham số | camelCase | `fullName`, `ticketNumber` |
| Hằng số (static final) | UPPER_SNAKE_CASE | `PAGE_SIZE`, `STATUS_PUBLISH` |
| Servlet | Hậu tố `Servlet` | `LoginServlet`, `RegisterServlet` |
| DAO | Hậu tố `DAO` / `DAOImpl` | `UserDAO`, `UserDAOImpl` |

## 2. Tổ chức package

- `model`: các entity ánh xạ bảng CSDL, chỉ chứa field + getter/setter.
- `dao`, `dao.impl`: tầng truy xuất dữ liệu, tách interface và implementation.
- `controller.<feature>`: Servlet xử lý request, nhóm theo tính năng (auth, admin, user, lottery).
- `filter`: Servlet Filter (xác thực, phân quyền, encoding).
- `util`: lớp tiện ích dùng chung (kết nối DB, mã hoá mật khẩu, validate).

## 3. Định dạng mã nguồn

- Thụt lề 4 khoảng trắng (không dùng Tab).
- Dấu `{` mở cùng dòng với khai báo (K&R style).
- Độ dài mỗi dòng không quá 120 ký tự.
- Mỗi class/method public quan trọng có comment mô tả (Javadoc `/** ... */`),
  ghi rõ Use case liên quan (ví dụ: `// UC01: Đăng ký tài khoản`).

## 4. Quy tắc lập trình

- Luôn dùng `PreparedStatement`, không nối chuỗi SQL trực tiếp (tránh SQL Injection).
- Luôn đóng `Connection`/`Statement`/`ResultSet` bằng `try-with-resources`.
- Không hard-code thông tin kết nối CSDL trong code — đọc từ `db.properties`.
- Mật khẩu luôn được mã hoá bằng `PasswordUtil` (BCrypt) trước khi lưu.
- Validate dữ liệu đầu vào ở tầng Controller trước khi gọi DAO.
- Không để lộ exception gốc (stack trace) ra giao diện người dùng.

## 5. Comment & tài liệu

- Mỗi Servlet ghi rõ Use case (mã UC) mà nó xử lý, và HTTP method (GET/POST) tương ứng bước nào trong đặc tả.
- Class Util/DAO có đoạn mô tả ngắn ở đầu file nêu mục đích sử dụng.
